function Pinterpolate();

% this is a simple m.file which serves as a tutorial for polynomial interpolation.
% save it as whatever you want, and then run it at the matlab command script
% just by typing out its name (say, "Pinterpolate")

% Pick something good for the nodes...
% try different vectors.
% they do not have to be equispaced.
nodes=-4:.5:4;
%nodes=[-4 -3.9 -3.75 -3.5 -3 -2 -1 0 1 2 3 3.5 3.75 3.9 4];

% Try different stuff here too...
% feel free to experiment and fiddle with your own methods and functions.
p=p_interp(nodes,@f,1000);

% below are all the functions necessary for the m-file to work.
% you may want to modify some/all of them to be more efficient and nice.

function output = p_interp(nodes,f,M)

	% this function takes in several inputs
	% nodes = nodes for polynomial interpolation
	% (N+1)x(1) vector
	% f = function (handle)
	% should be a function of one variable
	% M = number of points to graph
	%
	% this function outputs the polynomial interpolant to f at the desired nodes
	% note that the output is given in 'reverse order' for use in the matlab polynomial class
	
	% First we set up the right hand side
	% you can change f to be whatever you want...
	% try some different stuff.
	for index=1:length(nodes)
        fvals(index)=feval(f,nodes(index));
	end;
	
	% Then we compute the basis
	% you may wish to write your own function which can produce the basis
	% used in divided differences (see jonathan goodmans notes for this)
	basis = simple_bas(nodes);
	
	% Then we find the coefficients for the interpolant in terms of the basis
	% you could redo this function using the divided difference formula
	% (instead of just inverting a large (N+1)x(N+1) matrix).
	coef = bas2coef(nodes,basis,fvals);
	
	% Then we construct the polynomial interpolant in terms of the standard basis (for output)
	output=0;
	for index=1:length(nodes)
        output = output + coef(index)*basis(index,:);
	end;
	
	% finally, we go ahead and graph the entire thing
	xvals=min(nodes):(max(nodes)-min(nodes))/M:max(nodes);
	for index=1:length(xvals);yvals(index)=feval(f,xvals(index));end;
	pvals=polyval(output,xvals);
	figure(1);clf;
        subplot(2,1,1);hold on;
	plot(xvals,yvals,'r-',xvals,pvals,'b-');
	plot(nodes,fvals,'b*');
	axis([xvals(1) xvals(end) min(0,min(yvals)-1) max(yvals)+1])
	title('function in red, interpolant in blue, nodes at *');
	xlabel('x');
	ylabel('function value');
        subplot(2,1,2);hold on;
	plot(xvals,yvals-pvals,'g+');
	title('error in polynomial interpolation');
	xlabel('x');
	ylabel('error');
	hold off;
    
function output = simple_bas(nodes)
        
        % this function takes an input of nodes, which is a (N+1)x(1) vector
	% this function returns a matrix for the basis.
	% each row of the output corresponds to the polynomial coefficients for a basis element.
	% note that these are in 'reverse order' for use with matlabs polynomial class
	% note that the basis elements produded are simple x^n
        output=eye(length(nodes));

function output = dd_bas(nodes)

	% this function takes an input of nodes, which is a (N+1)x(1) vector
	% this function returns a matrix for the basis.
	% each row of the output corresponds to the polynomial coefficients for a basis element.
	% note that these are in 'reverse order' for use with matlabs polynomial class
	% note that the basis elements produded are those for the divided difference scheme
	
	% First we make sure that we have something to do
	if length(nodes)<2
        warning('you don''t have enough nodes');
        output = [0 1];
        return;
	end;
	% Then we write out the first basis element
	L{1}=[1];
	% Then the second
	L{2}=[1 -nodes(1)];
	% Then the third, and so forth
	for index=3:length(nodes)
        L{index}=conv(L{index-1},[1 -nodes(index-1)]);
	end;
	% Finally, we compress the whole thing into a single matrix
	output=zeros(length(nodes),length(nodes));
	for index=1:length(nodes)
        output(index,(length(nodes)-index+1):length(nodes))=L{index};
	end;

function output = bas2coef(nodes,basis,fvals);

	% This function takes several inputs
	% nodes = nodes for polynomial interpolation.
	% (N+1)x(1) vector.
	% basis = set of standard polynomial coefficients for basis functions.
	%         in form of a matrix 
	%         jth basis function is polyval(basis(j,:),x)
	%         (N+1)x(N+1) matrix
	% fvals = function values for polynomial interpolation.
	% (N+1)x(1) vector.
	%
	% output = weights for polynomial interpolant of (nodes,fvals).
	% (N+1)x(1) vector.
	
	% First we ensure that both nodes and fvals are column vectors;
	nodes=nodes(:);fvals=fvals(:);
	
	% Then we initialize the matrix B
	B=[];
	for index=1:length(nodes)
        % Now at each step we evaluate some more elements of B
        B=[B polyval(basis(index,:),nodes)];
	end;
	
	% And finally we return the coefficients of the polynomial interpolant.
	% Of course, these coefficients are still in terms of the basis
	output = B\fvals;
   
function output=f(x);
    % you can set this to be whatever you want...
    % try testing out different values for alpha
    alpha = 1/10;
    output = 1/(x^2 + alpha); 
