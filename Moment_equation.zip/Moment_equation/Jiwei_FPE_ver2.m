function [x,u1,uI1] = Jiwei_FPE_ver2(N,mY,D,TMAX,dt);

%%
%N = [128 128]; mY = [0.54 0.55]; D = [0.*N(1) 0.0006*N(2) 0.018; 0.0006*N(1) 0.00133*N(2) 0.018]; TMAX = 10000, dt = 0.01; Jiwei_FPE_ver2(N,mY,D,TMAX,dt);


format long;

% TMAX=500;
% M=5000;dt=TMAX/M;
nx=1024;

xStart = -1; xEnd = - xStart; 
xlength= xEnd - xStart;
dx=xlength/nx;
x=xStart:dx:xEnd;
J_source_ind = nx/2+1;
xbin = (x(1:end-1)+x(2:end))/2;

% figure;

% M = TMAX/dt;
% t=0:dt:TMAX;
NIMM=nx+1; LIMM=1;
A=speye(NIMM);  %% three extra imtermediate points
B = A;
right=zeros(NIMM,1);
s=right;
gL = 0.05; VE = 14/3; VI = -2/3; VR =0; VL =0; VT =1.0;
%% this is the code for Jin Shi and Hao Wu and Xu Yang's 2008 CMS paper Example 1.
A0 = exp(-5000*(x-0.2).^2); 
u1=(A0')/(sum(A0));
source = u1;
uI1 = u1;

%%%%%%%%%%%%%%%%%%
%coeM is the coefficients of Stiff Matrix
%%%%%%%%%%%%%%%%%%
NI = N(1); NE = N(2);

if isempty(mY); mY = [1.8 2.4]; end;
mIY = mY(1); mEY = mY(2);

% DQR are coupling strengths from R to Q;
if isempty(D); D = [0.25 0.30 0.05 ; 0.55 0.50 0.05 ]; end;
DII = D(1,1); DIE = D(1,2); DIY = D(1,3); DEI = D(2,1); DEE = D(2,2); DEY = D(2,3);

tagline = sprintf('N_%.3d_%.3d_mY_%.2d_%.2d_D_%.2d_%.2d_%.2d_%.2d_T%.3d_dt%.3d_VE%.3d_VI%.3d',...
    NI,NE,round(10000*mIY),round(10000*mEY),round(10000*DII),round(10000*DIE),round(10000*DEI),round(10000*DEE),round(TMAX/1024),round(dt*1000),round(10000*VE),round(10000*VI));
filename_base = sprintf('me3_%s',tagline); disp(filename_base);

D(:,1:2) = inv(diag(N))*D(:,1:2);
DII = D(1,1); DIE = D(1,2); DIY = D(1,3); DEI = D(2,1); DEE = D(2,2); DEY = D(2,3);

mE = 0; mI =0; 


% NI = 128;  NE = 128;
% mEY = 0.55; DEY = 0.018; DEE = 0.1/NE; DIE = 0.1/NE;
% mIY = 0.54; DIY = 0.018; DII = 0.1/NI; DEI = 0.1/NI;




DEE1 = DEE; DEI1 = DEI; DII1 = DII; DIE1 = DIE;

LEE_kick = get_L_kick(DEE1,x,VE); lEE_fire = 1-transpose(sum(LEE_kick,1)); lEE_undr = transpose(sum(LEE_kick,1));
LIE_kick = get_L_kick(DIE1,x,VE); lIE_fire = 1-transpose(sum(LIE_kick,1)); lIE_undr = transpose(sum(LIE_kick,1));

vk1 = VE + (VT-VE)*exp(2*DEE1); 
vIk1= VE + (VT-VE)*exp(DIE1); 
vT_idx = length(x); 
Ind_k1 = find(x>=vk1);k1_idx = Ind_k1(1)-1; if(Ind_k1>vT_idx); k1_idx = vT_idx;end
IndI_k1 = find(x>=vIk1);kI_idx = IndI_k1(1)-1; if(IndI_k1>vT_idx); kI_idx = vT_idx;end

% size(u1)
% size(lIE_undr)
% return;
DEE = exp(DEE) -1; DEY = exp(DEY) -1; DIE = exp(DIE) -1;
DII = exp(DII) -1; DIY = exp(DIY) -1; DEI = exp(DEI) -1;



coeM = zeros(3,1);
coeMI = zeros(3,1);




P_MFE = 0;

plot_flag=0; dt_record_flag=0; 
dtbin_record_flag=1; tbinsize = 1.0; dtperbin = floor(tbinsize/dt); tbinsize=dtperbin*dt;
iteration_max=dtperbin*TMAX/tbinsize; 

MFE_num=1; Lt_ra(1)=0; LE_ra(1)=0; LI_ra(1)=0;
t_sum=0; t_ra = zeros(iteration_max+1,1);
mE_ra = zeros(iteration_max+1,1);
mI_ra = zeros(iteration_max+1,1);

if dt_record_flag;
rE_ra = zeros(nbins,iteration_max);
rI_ra = zeros(nbins,iteration_max);
else;%if dt_record_flag;
rE_ra = [];
rI_ra = [];
end;%if dt_record_flag;
rEbin_ra = [];
rIbin_ra = [];

if dtbin_record_flag;
tbin_ra = zeros(iteration_max/dtperbin,1);
mEbin_ra = zeros(iteration_max/dtperbin,1);
mIbin_ra = zeros(iteration_max/dtperbin,1);
xEbin_ra = zeros(iteration_max/dtperbin,1);
xIbin_ra = zeros(iteration_max/dtperbin,1);
P_MFEbin_ra = zeros(iteration_max/dtperbin,1);
rEbin_ra = zeros(NIMM,iteration_max/dtperbin);
rIbin_ra = zeros(NIMM,iteration_max/dtperbin);
VEavgbin_ra = zeros(iteration_max/dtperbin,1);
VEstdbin_ra = zeros(iteration_max/dtperbin,1);
VIavgbin_ra = zeros(iteration_max/dtperbin,1);
VIstdbin_ra = zeros(iteration_max/dtperbin,1);
else;%if dtbin_record_flag;
tbin_ra = [];
mEbin_ra = [];
mIbin_ra = [];
xEbin_ra = [];
xIbin_ra = [];
P_MFEbin_ra = [];
rEbin_ra = [];
rIbin_ra = [];
VEavgbin_ra = []; 
VEstdbin_ra = [];
VIavgbin_ra = [];
VIstdbin_ra = [];
end;%;%if dtbin_record_flag;
sum_mE = 0; sum_mI = 0; counter_firing_step = 0; t_sum =0;

for iteration=0:iteration_max-1;
    t_ra(1+iteration) = t_sum;
% t_sum

[VEavg_ra(1+iteration),VEstd_ra(1+iteration)] = histstats(u1,x);
[VIavg_ra(1+iteration),VIstd_ra(1+iteration)] = histstats(uI1,x);
 if dt_record_flag; rE_ra(:,1+iteration) = u1; rI_ra(:,1+iteration) = uI1; end;
%  plot(x,u1,'r',x,uI1,'b'); drawnow;
 if dtbin_record_flag; 
dtbin_ij = 1 + floor(iteration/dtperbin);
tbin_ra(dtbin_ij) = tbin_ra(dtbin_ij) + dt*t_ra(1+iteration);
rEbin_ra(:,dtbin_ij) = rEbin_ra(:,dtbin_ij) + dt*u1; 
rIbin_ra(:,dtbin_ij) = rIbin_ra(:,dtbin_ij) + dt*uI1; 
VEavgbin_ra(dtbin_ij) = VEavgbin_ra(dtbin_ij) + dt*VEavg_ra(1+iteration);
VEstdbin_ra(dtbin_ij) = VEstdbin_ra(dtbin_ij) + dt*VEstd_ra(1+iteration);
VIavgbin_ra(dtbin_ij) = VIavgbin_ra(dtbin_ij) + dt*VIavg_ra(1+iteration);
VIstdbin_ra(dtbin_ij) = VIstdbin_ra(dtbin_ij) + dt*VIstd_ra(1+iteration);
end;% if dtbin_record_flag;    

if 1; (rand()>P_MFE);
MFE_flag=0;
for j=LIMM+1:NIMM-1
    
 gT = gL + mEY*DEY*(1-DEY^2) + NE*mE*DEE*(1-DEE^2) + NI*mI*DEI*(1-DEI^2);
 mu = (gL*VL + mEY*DEY*(1-DEY^2)*VE + NE*mE*DEE*(1-DEE^2)*VE + NI*mI*DEI*(1-DEI^2)*VI)/gT;
 gamma =  (mEY*DEY^3 + NE*mE*DEE^3 + NI*mI*DEI^3)/gT;                           
 sigma =  (mEY*DEY^2*(1+DEY)*(xbin-VE).^2 + NE*mE*DEE^2*(1+DEE)*(xbin-VE).^2+ NI*mI*DEI^2*(1+DEI)*(xbin-VI).^2)/gT;

     
 gTI = gL + mIY*DIY*(1-DIY^2) + NE*mE*DIE*(1-DIE^2) + NI*mI*DII*(1-DII^2) ;
 muI = (gL*VL + mIY*DIY*(1-DIY^2)*VE + NE*mE*DIE*(1-DIE^2)*VE + NI*mI*DII*(1-DII^2)*VI)/gTI;
 gammaI = (mIY*DIY^3 + NE*mE*DIE^3 + NI*mI*DII^3)/gTI;                           
 sigmaI =  (mIY*DIY^2*(1+DIY)*(xbin-VE).^2 + NE*mE*DIE^2*(1+DIE)*(xbin-VE).^2+ NI*mI*DII^2*(1+DII)*(xbin-VI).^2)/gTI;
 
 coeM(1) =  0.25*gT*dt*(xbin(j-1) -mu )/dx - 0.25*sigma(j-1)*dt*gT/dx^2 ;
coeM(3) =  - 0.25*(x(j) - mu)*dt*gT/dx - 0.25*sigma(j)*dt*gT/dx^2;
coeM(2) =  0.25*(xbin(j-1) - mu)*dt*gT/dx - 0.25*(xbin(j) - mu)*dt*gT/dx ...
    + 0.25*gT*sigma(j-1)*dt/dx^2 + 0.25*gT*sigma(j)*dt/dx^2;

coeMI(1) =  0.25*gTI*dt*(xbin(j-1) -muI )/dx - 0.25*sigmaI(j-1)*dt*gTI/dx^2 ;
coeMI(3) =  - 0.25*(x(j) - muI)*dt*gTI/dx - 0.25*sigmaI(j)*dt*gTI/dx^2;
coeMI(2) =  0.25*(xbin(j-1) - muI)*dt*gTI/dx - 0.25*(xbin(j) - muI)*dt*gTI/dx ...
    + 0.25*gTI*sigmaI(j-1)*dt/dx^2 + 0.25*gTI*sigmaI(j)*dt/dx^2;

%%%%%%%%%%%%%%%%%%  
        A(j,j-1)= coeM(1);
        A(j,j)  =1 + coeM(2) - 0.5*dt*gT*gamma;
        A(j,j+1)= coeM(3);
        
        B(j,j-1)= - coeM(1);
        B(j,j)  =  1 - coeM(2)+ 0.5*dt*gT*gamma;
        B(j,j+1)= - coeM(3);
        
        AI(j,j-1)= coeMI(1);
        AI(j,j)  =1 + coeMI(2) - 0.5*dt*gTI*gammaI;
        AI(j,j+1)= coeMI(3);
        
        BI(j,j-1)= - coeMI(1);
        BI(j,j)  =  1 - coeMI(2)+ 0.5*dt*gTI*gammaI;
        BI(j,j+1)= - coeMI(3);
end
    A(NIMM,NIMM)   = 1;  
    A(LIMM,LIMM)   = 1;   %-i*0.5/dx;
    
    B(NIMM,NIMM)   = 0;
    B(LIMM,LIMM)   = 0;   %-i*0.5/dx;
    

    AI(NIMM,NIMM)   = 1;  
    AI(LIMM,LIMM)   = 1;   %-i*0.5/dx;
    
    BI(NIMM,NIMM)   = 0;
    BI(LIMM,LIMM)   = 0;   %-i*0.5/dx;
    
    
    %%%%%%%%%%%%%%%%%%%% update E-population %%%%%%%%%%%%%%%%%%%%%
    s = u1;
    right = B*s;
    right(J_source_ind) =  right(J_source_ind) + mE/dx;
    s=A\right;
    u1=s;
%  mE = max(0,dt*gT*sigma(NIMM-1)*u1(NIMM-1)/dx/2);
mE =max(0, 0.5*gT*dt*(sigma(NIMM-1))*(4*u1(NIMM-1)-u1(NIMM-2))/dx/2);
% mE/dt/dx
mE_ra(1+iteration) = mE/dx/dt;
    
    %%%%%%%%%%%%%%%%%%%% update I-population %%%%%%%%%%%%%%%%%%%%%    
    sI = uI1;
    rightI = BI*sI;
    rightI(J_source_ind) =  rightI(J_source_ind) + mI/dx;
    sI=AI\rightI;
    uI1=sI;
uI1 = uI1/sum(uI1);    
 % mE = max(0,dt*gT*sigma(NIMM-1)*u1(NIMM-1)/dx/2);
mI =max(0, 0.5*gTI*dt*(sigmaI(NIMM-1))*(4*uI1(NIMM-1)-uI1(NIMM-2))/dx/2);
mI_ra(1+iteration) = mI/dx/dt;
u1 = u1/sum(u1);
%% Note that: if we nomalize u by u/sum(u); mE = mE/dx; if u/sum(u)/dx; mE = mE;%% 
% P_MFE = NE*mE/dx*(1 - dot(lEE_undr,u1(1:end-1)).^(NE-1)  * dot(lIE_undr,uI1(1:end-1)).^(NI));

 mkpn1 = sum(u1(k1_idx:vT_idx));
 mklnI = sum(uI1(kI_idx:vT_idx));
% q = (1.0 - mkpn1)^(NE-1) * (1-mklnI)^NI;
 q = (1.0 - mkpn1)^(NE-1);
        local_pevent =  NE*mE/dx*(1.0-q);
       P_MFE = local_pevent;
  

P_MFE_ra(1+iteration) = P_MFE/dt;
else;
   MFE_flag=1;
MFE_num = MFE_num+1;
VE_sample = transpose(getsamples(x,u1,NE)); 
VI_sample = transpose(getsamples(x,uI1,NI));


[LE, LI, ll_target,sp_order,E_fired,I_fired,VE_pre,VI_pre,VEpos,VIpos] = ...
                Micro_solver_MFE_from_IFMODEL(VE_sample,VI_sample,DEE1,DIE1,DEI1,DII1,14/3, -2/3);
            Lt_ra(MFE_num) = dt*iteration; LE_ra(MFE_num) = length(E_fired); LI_ra(MFE_num) = length(I_fired);
          
Lt_ra(MFE_num) = dt*iteration; LE_ra(MFE_num) = length(E_fired); LI_ra(MFE_num) = length(I_fired);
%             fprintf(fid,'%16.4e    %16.0e     %16.0e   %16.0e     %16.0e\n', t_sum,0,0,length(E_fired),length(I_fired));
disp(sprintf('resolving MFE %d at time %f, P_MFE %f, LE %d LI %d ',MFE_num,Lt_ra(MFE_num),P_MFE/dt,LE_ra(MFE_num),LI_ra(MFE_num)));
% VEpos(E_fired)=VR; VIpos(I_fired)=VR;
u1 = transpose(histc(VEpos,x));  u1 = u1/sum(u1);
uI1 = transpose(histc(VIpos,x));  uI1 = uI1/sum(uI1);
% gamma_E = dot(lEE_undr,rE).^(NE-1);
mE =0; mI =0;
P_MFE =0 ;
P_MFE_ra(1+iteration) = P_MFE/dt;

end




if dtbin_record_flag; 
dtbin_ij = 1 + floor(iteration/dtperbin);
mEbin_ra(dtbin_ij) = mEbin_ra(dtbin_ij) + (1-MFE_flag)*mE_ra(1+iteration)*NE*dt + MFE_flag*LE_ra(MFE_num);
mIbin_ra(dtbin_ij) = mIbin_ra(dtbin_ij) + (1-MFE_flag)*mI_ra(1+iteration)*NI*dt + MFE_flag*LI_ra(MFE_num);
xEbin_ra(dtbin_ij) = xEbin_ra(dtbin_ij) + (1-MFE_flag)*psample(mE_ra(1+iteration)*NE*dt) + MFE_flag*LE_ra(MFE_num);
xIbin_ra(dtbin_ij) = xIbin_ra(dtbin_ij) + (1-MFE_flag)*psample(mI_ra(1+iteration)*NI*dt) + MFE_flag*LI_ra(MFE_num);
P_MFEbin_ra(dtbin_ij) = P_MFEbin_ra(dtbin_ij) + P_MFE_ra(1+iteration)*dt;
end;% if dtbin_record_flag;
    
plot(x,u1,'r',x,uI1,'b'); drawnow; 
t_sum = t_sum+dt;
end


plot_flag=0;
nsec_to_plot=1.0;
if plot_flag & dtbin_record_flag;
figure;
tij=max(1,(TMAX-1024*nsec_to_plot)/tbinsize):TMAX/tbinsize;
[rtmp,ctmp] = size(rEbin_ra); j_source = (rtmp+1)/2;
subplot(5,1,1);imagesc(rEbin_ra(end:-1:j_source,tij)*sparse(1:length(tij),1:length(tij),1./sum(rEbin_ra(end:-1:j_source,tij),1)),[0 4/1024]); ylabel('VE');
set(gca,'YTick',[1 j_source]);set(gca,'YTickLabel',{'VT','VR'});
[rtmp,ctmp] = size(rIbin_ra); j_source = (rtmp+1)/2;
subplot(5,1,2);imagesc(rIbin_ra(end:-1:j_source,tij)*sparse(1:length(tij),1:length(tij),1./sum(rIbin_ra(end:-1:j_source,tij),1)),[0 4/1024]); ylabel('VI');
set(gca,'YTick',[1 j_source]);set(gca,'YTickLabel',{'VT','VR'});
subplot(5,1,3);
hold on;
l=stairs(tbin_ra(tij),VEavgbin_ra(tij),'r-'); set(l,'LineWidth',2);
l=stairs(tbin_ra(tij),VEavgbin_ra(tij)+VEstdbin_ra(tij),'r:'); set(l,'LineWidth',1);
l=stairs(tbin_ra(tij),VEavgbin_ra(tij)-VEstdbin_ra(tij),'r:'); set(l,'LineWidth',1);
l=stairs(tbin_ra(tij),VIavgbin_ra(tij),'b-'); set(l,'LineWidth',2);
l=stairs(tbin_ra(tij),VIavgbin_ra(tij)+VIstdbin_ra(tij),'b:'); set(l,'LineWidth',1);
l=stairs(tbin_ra(tij),VIavgbin_ra(tij)-VIstdbin_ra(tij),'b:'); set(l,'LineWidth',1);
xlim([min(tbin_ra(tij)) max(tbin_ra(tij))]);
ylim([VR VT]); ylabel('Vavg');
set(gca,'YTick',[0 1]);set(gca,'YTickLabel',{'VR','VT'});
hold off;
subplot(5,1,4); stairs(tbin_ra(tij),P_MFEbin_ra(tij),'g-'); xlim([min(tbin_ra(tij)) max(tbin_ra(tij))]); ylabel('P/dt');
subplot(5,1,5); hold on; stairs(tbin_ra(tij),xEbin_ra(tij),'r-'); stairs(tbin_ra(tij),xIbin_ra(tij),'b-'); xlim([min(tbin_ra(tij)) max(tbin_ra(tij))]); ylabel('#spk'); hold off; 
print('-depsc',sprintf('%s_FIG_A.eps',filename_base));
print('-djpeg',sprintf('%s_FIG_A.jpg',filename_base));
end;%if plot_flag & dtbin_record_flag;

plot_flag=0;
if plot_flag & dtbin_record_flag;
figure;
subplot(2,2,1); 
hold on;

rEtmp = mean(rEbin_ra,2);l=stairs(x,rEtmp,'r-'); set(l,'LineWidth',2);
rItmp = mean(rIbin_ra,2); l=stairs(x,rItmp,'b-'); set(l,'LineWidth',2);
% xlim([Vbins(j_source) Vbins(end)]); ylim([0 0.005]);
xlim([x(j_source) x(end)]); ylim([0 1.1*max(max(rEtmp),max(rItmp))]);
hold off;
subplot(2,2,2);
hold on;
hEtmp = hist(mEbin_ra,[1:1.5*NE]); l=plot(log2([1:1.5*NE]),log2(1+hEtmp),'r-'); set(l,'LineWidth',2);
hItmp = hist(mIbin_ra,[1:1.5*NI]); l=plot(log2([1:1.5*NI]),log2(1+hItmp),'b-'); set(l,'LineWidth',2);
%hEtmp = hist(mEbin_ra,[1:1.5*NE]); l=loglog(([1:1.5*NE]),(1+hEtmp),'r-'); set(l,'LineWidth',2);
%hItmp = hist(mIbin_ra,[1:1.5*NI]); l=loglog(([1:1.5*NI]),(1+hItmp),'b-'); set(l,'LineWidth',2);
hold off;
subplot(2,2,[3,4]);
h = spectrum.mtm; Fs = 1000*1/tbinsize; hpsd = psd(h,(VEavgbin_ra*NE + VIavgbin_ra*NI)/(NE+NI),'Fs',Fs); plot(hpsd);
print('-depsc',sprintf('%s_FIG_B.eps',filename_base));
print('-djpeg',sprintf('%s_FIG_B.jpg',filename_base));
end;%if plot_flag & dtbin_record_flag;


function [mra,sra,ora] = histstats(hra,Vbins);
% assumes each column of hra is a histogram with bin centers Vbins;
[rows,cols] = size(hra);
mra = zeros(1,cols);
sra = zeros(1,cols);
ora = zeros(1,cols);
for nc=1:cols;
hra(:,nc) = hra(:,nc)/sum(hra(:,nc));
[tmp,ora(1,nc)] = max(hra(:,nc)); 
end;%for nc=1:cols;
mra = (1:rows)*hra; 
sra = ((1:rows).^2)*hra; 
sra = sqrt(sra - mra.^2);
mra = interp1(1:rows,Vbins,mra);
sra = sra / rows * (Vbins(end)-Vbins(1));
ora = Vbins(ora);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function L_kick = get_L_kick(kick_val,Vedges,VD);
% get L_kick -- the kick term ;
TAU_V=20;VT=1;VR=0;
nbins = length(Vedges)-1; nbinp = nbins+1;
dV = (VT-(VR-VT))/nbins; egd = exp(kick_val);
row_ra=[];col_ra=[];val_ra=[];
for (j=1:nbins);
% bin edge j is at VR-VT + dV*(j-1); bin center j is at VR-VT + dV*(j-0.5) ;
% the edge index of V is j = (V-(VR-VT))/dV + 1 ;
% the edge center of V is j = (V-(VR-VT))/dV + 0.5 ;
% bin j with center Vbin(j) has edges [Vedges(j),Vedges(j+1)] ;
% over a timestep of length dt the mass in [Vpre Vpos] is kicked to lie in bin j, where ;
Vpre = VD + (Vedges(j)-VD)*egd;
Vpos = VD + (Vedges(j+1)-VD)*egd;
% The interval [Vpre Vpos] correponds to edges ;
jpre = (Vpre - (VR-VT))/dV + 1;
jpos = (Vpos - (VR-VT))/dV + 1;
% The interval [Vpre Vpos] sits within edge indices ;
jmin = floor(jpre);
jmax = ceil(jpos);
% and bin indices ;
bmin = jmin;
bmax = jmax-1;
% because kicks do not compress, it is possible that jmax-jmin==1 and bmax==bmin. ;
bvec = transpose(bmin:bmax);
if length(bvec)>1;
% The weights associated with jmin and jmax are ;
wmin = (jmin+1)-jpre;
wmax = jpos-(jmax-1);
wvec = [wmin;ones(length(bvec)-2,1);wmax];
rvec = j*ones(length(bvec),1);
elseif length(bvec)==1;
% The weights associated with jmin and jmax are ;
wvec = [1];
rvec = j*ones(length(bvec),1);
end;%if length(bvec)>1;
vij = find(bvec>0 & bvec<=nbins);
row_ra = [row_ra;rvec(vij)];
col_ra = [col_ra;bvec(vij)];
val_ra = [val_ra;wvec(vij)];
end;%for (j=1:nbins);
L_kick = sparse(row_ra,col_ra,val_ra,nbins,nbins);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function output = getsamples(Vedges,rho,Nsamples)
rho = [0;rho(:)]/sum(rho);
L = length(rho);
F = cumsum(rho);
[Fv,Fi,Fj] = unique(F,'first');
output = interp1(F(Fi),Vedges(Fi),rand(Nsamples,1));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function output = psample(ldt);
% draws an event count from a Poisson process with rate lambda over time dt;
if ldt>5; output = max(0,round(ldt + sqrt(ldt)*randn())); 
else; 
kra = 0:14;
pra = [-1 , cumsum((ldt.^kra).*exp(-ldt)./factorial(kra)) , 2];
output = max(find(~(min(rand(),pra(end-1))<=pra)))-1;
end;% if ldt>7;
