function j = Solve_rate_equation_moment4_Matlab_CODE_Jiwei_ver2(N,mY,D,TMAX,dt)
WIN_USE = 0;if WIN_USE,catalog_str = '\\';else,catalog_str = '/';end
format long; MFE_COMPUT_USED = 1;PLOT_or_NOT =0; density_plot_or_not = 1;
NE = N(2);NI = N(1); vL =0; gL=0.05;
Final_time = TMAX;

SEE = D(2,2);SEI = D(2,1);SIE = D(1,2); SII = D(1,1); etaE = mY(2); fE = D(2,3);etaI = mY(1);fI = D(1,3); 
D_tranformed = D;
D_tranformed(:,1:2) = inv(diag(N))*D(:,1:2);

tagline = sprintf('N_%.3d_%.3d_mY_%.2d_%.2d_D_%.2d_%.2d_%.2d_%.2d_T%.3d_dt%.3d',NI,NE,round(10*etaI),round(10*etaE),round(100*SII),round(100*SIE),round(100*SEI),round(100*SEE),round(TMAX/1024),round(dt*1000));
filename_base = sprintf('fm5_%s',tagline);

V_start = -1; V_end = 1; N_divide =1000; V = linspace(V_start,V_end,N_divide); h = V(2) - V(1);V = V';
step = 0; First_firing_num_neruons = 2; P1_used = 1;
mE = 0.0; mI = 0;
counter = 1; t =0;
vT_idx = length(V); vT = 1.0; VR =0;
vk1 = back_kick_constant(vT,SEE/NE); vk2 = back_kick_constant(vT,2*SEE/NE);
vIk1 = back_kick_constant(vT,SIE/NI);
Ind_k1 = find(V>=vk1);k1_idx = Ind_k1(1); if(Ind_k1>vT_idx); k1_idx = vT_idx;end
Ind_k2 = find(V>=vk2);k2_idx = Ind_k2(1); if(Ind_k2>vT_idx); k2_idx = vT_idx;end
IndI_k1 = find(V>=vIk1);kI_idx = IndI_k1(1); if(IndI_k1>vT_idx); kI_idx = vT_idx;end

%%% Now I need give a guess of the initial values of diffent moments to evolve the ODE

var1 = (5/3/250.0)^2;
%% To define some index, it is easy to find some index for V>=VT and and the index for v = VR in the coming code
source = exp(-(V+0.0).^2/var1/2.0)/sqrt(2.0*pi*var1);source = source/(h*sum(source));
vbarE = (V(2)-V(1))*sum(V.*source);wbarE = (V(2)-V(1))*sum(V.^2 .*source);vbar3E = (V(2)-V(1))*sum(V.^3 .*source);vbar4E = (V(2)-V(1))*sum(V.^4 .*source);
vbarI = vbarE; wbarI = wbarE; vbar3I = vbar3E; vbar4I = vbar4E;
% hold all; plot(V,source),hold on
[VEs,VIs] = VQs(fE,fI,etaE,etaI,SEE,SIE,SEI,SII,0,0,vL,gL);
[DE,DI]   = DEDI(fE,fI,etaE,etaI,SEE,SIE,SEI,SII,0,0,NE,NI,gL);
[PEq,sumE ]= rho_EQ(VEs,DE,V);
[PIq,sumI] = rho_EQ(VIs,DI,V);
gammaE = [1,vbarE,wbarE,vbar3E,vbar4E];
gammaI = [1,vbarI,wbarI,vbar3I,vbar4I];
fiE = gammaE';fiI = gammaI';
moment2 = 1; options = optimset('TolFun',1e-9,'GradObj','on');
if moment2
F = fiE(2:3);FI = fiI(2:3);
else
F = fiE(2:end)*0;FI = fiI(2:end)*0;
end

if moment2 
    La0 = gammaE(1:3)';
    LaI0 = gammaI(1:3)';
else
     La0 = gammaE(1:end)';
     LaI0 = gammaI(1:end)';
end


nbins = 1025; nbinp = nbins+1; dV = (vT-(VR-vT))/nbins; Vedges = linspace(VR-vT,vT,nbinp); Vedges = Vedges';Vbins = (Vedges(1:end-1)+Vedges(2:end))/2; 
j_source = (nbins+1)/2; rho_source = zeros(nbins,1); rho_source(j_source)=1; 
 

N=length(La0);
fin=zeros(length(V),N); 
fin(:,1)=ones(size(V)); % fi0(x)=1
fin_s=zeros(length(Vbins),N); 
fin_s(:,1)=ones(size(Vbins)); % fi0(x)=1


 for n=2:N
      fin(:,n)=V.*fin(:,n-1);
      fin_s(:,n) = Vbins.*fin_s(:,n-1);
 end


g1 = 1:1;
for j = 1:length(g1);
     [La1] = fsolve(@(La)optfun(F,V,La,PEq,fin,g1(j)),La0,optimset('Display','off'));
     [LaI1] = fsolve(@(LaII)optfun(FI,V,LaII,PIq,fin,g1(j)),LaI0,optimset('Display','off'));
   La0 = real(La1);
   LaI0 = real(LaI1);
end
times = 10000; sum_mE = 0; sum_mI = 0; counter_firing_step = 0;
catalog_head1 = 'MFE10_event';
mkdir(catalog_head1);
var_fn = ['Exp_MFE_','NE_',num2str(NE),'_NI_',num2str(NI),'_SEE_',num2str(times*SEE),'_SIE_',num2str(times*SIE),'_SEI_',num2str(times*SEI),'_SII_',num2str(times*SII),...
    '_S_',num2str((times*fE)),'_R_',num2str((times*etaE)),'_S_ln_',num2str((times*fI)),'_R_ln_',num2str((times*etaI)),'N_',num2str((N_divide)),'dt_',num2str((dt*times)),'_T_',num2str(Final_time),'moment2_used', num2str(moment2),'_FFnum_',num2str(First_firing_num_neruons),'_P1_used_',num2str(P1_used)];
filename_rec =  [catalog_head1,catalog_str,var_fn,'.txt'];
fid = fopen(filename_rec, 'wt');

var_fn1 = ['Exp_moments_','_SEE_',num2str(times*SEE),'_SIE_',num2str(times*SIE),'_SEI_',num2str(times*SEI),'_SII_',num2str(times*SII),...
    '_S_',num2str((times*fE)),'_R_',num2str((times*etaE)),'_S_ln_',num2str((times*fI)),'_R_ln_',num2str((times*etaI)),'N_',num2str((N_divide)),'dt_',num2str((dt*times)),'_T_',num2str(Final_time),'moment2_used', num2str(moment2),'_FFnum_',num2str(First_firing_num_neruons),'_P1_used_',num2str(P1_used)];
filename_rec1 =  [catalog_head1,catalog_str,var_fn1,'.txt'];
fid1 = fopen(filename_rec1, 'wt');
var_fn2 = ['Exp_density_','_SEE_',num2str(times*SEE),'_SIE_',num2str(times*SIE),'_SEI_',num2str(times*SEI),'_SII_',num2str(times*SII),...
    '_S_',num2str((times*fE)),'_R_',num2str((times*etaE)),'_S_ln_',num2str((times*fI)),'_R_ln_',num2str((times*etaI)),'N_',num2str((N_divide)),'dt_',num2str((dt*times)),'_T_',num2str(Final_time),'moment2_used', num2str(moment2),'_FFnum_',num2str(First_firing_num_neruons),'_P1_used_',num2str(P1_used)];

density_record_counter = 0;



plot_flag=0; dt_record_flag=0; 
dtbin_record_flag=1; tbinsize = 1.0; dtperbin = floor(tbinsize/dt); tbinsize=dtperbin*dt;
iteration_max=dtperbin*TMAX/tbinsize; 
MFE_num=1; Lt_ra(1)=0; LE_ra(1)=0; LI_ra(1)=0;
t_sum=0; t_ra = zeros(iteration_max+1,1);
mE_ra = zeros(iteration_max+1,1);
mI_ra = zeros(iteration_max+1,1);

if dt_record_flag;
rE_ra = zeros(nbins,iteration_max);
rI_ra = zeros(nbins,iteration_max);
else;%if dt_record_flag;
rE_ra = [];
rI_ra = [];
end;%if dt_record_flag;

if dtbin_record_flag;
tbin_ra = zeros(iteration_max/dtperbin,1);
mEbin_ra = zeros(iteration_max/dtperbin,1);
mIbin_ra = zeros(iteration_max/dtperbin,1);
xEbin_ra = zeros(iteration_max/dtperbin,1);
xIbin_ra = zeros(iteration_max/dtperbin,1);
P_MFEbin_ra = zeros(iteration_max/dtperbin,1);
rEbin_ra = zeros(nbins,iteration_max/dtperbin);
rIbin_ra = zeros(nbins,iteration_max/dtperbin);
VEavgbin_ra = zeros(iteration_max/dtperbin,1);
VEstdbin_ra = zeros(iteration_max/dtperbin,1);
VIavgbin_ra = zeros(iteration_max/dtperbin,1);
VIstdbin_ra = zeros(iteration_max/dtperbin,1);
else;%if dtbin_record_flag;
tbin_ra = [];
mEbin_ra = [];
mIbin_ra = [];
xEbin_ra = [];
xIbin_ra = [];
P_MFEbin_ra = [];
rEbin_ra = [];
rIbin_ra = [];
VEavgbin_ra = []; 
VEstdbin_ra = [];
VIavgbin_ra = [];
VIstdbin_ra = [];
end;%;%if dtbin_record_flag;

rE = Vbins*0;rI = Vbins*0; 

for iteration=0:iteration_max-1;
 MFE_flag = 0;   
t_ra(1+iteration) = t_sum;
t_sum

%[VEavg_ra(1+iteration),VEstd_ra(1+iteration)] = histstats(rE,Vbins);
%[VIavg_ra(1+iteration),VIstd_ra(1+iteration)] = histstats(rI,Vbins);
VIavg_ra(1+iteration) = vbarI;VIstd_ra(1+iteration) = sqrt(wbarI -vbarI^2);
VEavg_ra(1+iteration) = vbarE;VEstd_ra(1+iteration) = sqrt(wbarE - vbarE^2);
if dt_record_flag; rE_ra(:,1+iteration) = rE; rI_ra(:,1+iteration) = rI; end;
if dtbin_record_flag; 
dtbin_ij = 1 + floor(iteration/dtperbin);
tbin_ra(dtbin_ij) = tbin_ra(dtbin_ij) + dt*t_ra(1+iteration);
rEbin_ra(:,dtbin_ij) = rEbin_ra(:,dtbin_ij) + dt*rE; 
rIbin_ra(:,dtbin_ij) = rIbin_ra(:,dtbin_ij) + dt*rI; 
VEavgbin_ra(dtbin_ij) = VEavgbin_ra(dtbin_ij) + dt*VEavg_ra(1+iteration);
VEstdbin_ra(dtbin_ij) = VEstdbin_ra(dtbin_ij) + dt*VEstd_ra(1+iteration);
VIavgbin_ra(dtbin_ij) = VIavgbin_ra(dtbin_ij) + dt*VIavg_ra(1+iteration);
VIstdbin_ra(dtbin_ij) = VIstdbin_ra(dtbin_ij) + dt*VIstd_ra(1+iteration);
end;% if dtbin_record_flag;


    [VEs,VIs] = VQs(fE,fI,etaE,etaI,SEE,SIE,SEI,SII,mE,mI,vL,gL);
    [DE,DI] = DEDI(fE,fI,etaE,etaI,SEE,SIE,SEI,SII,mE,mI,NE,NI,gL); %% here DE is the DE^2 in the note
    
    [vbarE,vbarI,wbarE,wbarI,vbar3E,vbar3I,vbar4E,vbar4I] = ...
        solveVbarWbar4(dt,vbarE, vbarI, wbarE, wbarI,vbar3E, vbar3I,vbar4E, vbar4I,VEs,VIs,DE, DI,mE,mI,gL);    

fiE = [1,vbarE,wbarE,vbar3E,vbar4E]';
fiI = [1,vbarI,wbarI,vbar3I,vbar4I]';
[PEq,sumE ]= rho_EQ(VEs,DE,V);
[PIq,sumI] = rho_EQ(VIs,DI,V);
if moment2
F = fiE(2:3);FI = fiI(2:3);
else
F = fiE(2:end);FI = fiI(2:end);
end

     [La1] = fminsearch(@(La)optfun(F,V,La,PEq,fin,1),La0,options);
     [LaI1] = fminsearch(@(LaII)optfun(FI,V,LaII,PIq,fin,1),LaI0,options);
     La0 = real(La1);   LaI0 = real(LaI1);
     
     
     
     

 RvE = PEq.*exp(fin(:,1:N)*La1); % Calculate p(x)
 RvI = PIq.*exp(fin(:,1:N)*LaI1); % Calculate p(x)

 RvE = RvE/((V(2)-V(1))*sum(RvE));
 RvI = RvI/((V(2)-V(1))*sum(RvI));


mE = gL*sqrt(DE) *exp(sum(La1))/sumE/2;
mI = gL*sqrt(DI) *exp(sum(LaI1))/sumI/2;
    
    if step >5;
         t, mE,mI
        step = 0;
        if PLOT_or_NOT
        figure(1)
        subplot(211)
        plot(V(1:5:end),RvE(1:5:end),'mo');
        subplot(212)
        plot(V(1:5:end),RvI(1:5:end),'b*');
        drawnow;
        end
    end
    t = dt*counter;
    counter = counter + 1; step = step +1;
    
    
    
 mI_ra(1+iteration) = mI; mE_ra(1+iteration) = mE;

 p_single = mE*dt; 
        mkpn1 = (V(2) - V(1))*sum(RvE(k1_idx:vT_idx));
        mklnI = (V(2) - V(1))*sum(RvE(kI_idx:vT_idx));
        q = (1.0 - mkpn1)^(NE-1) .*mklnI.^NI;
        local_pevent =  NE*p_single*(1.0-q);
  P_MFE_ra(1+iteration) = local_pevent;
    
  P_MFE = local_pevent*dt;
  [PEq_s,sumE_s ]= rho_EQ(VEs,DE,Vbins);
[PIq_s,sumI_s] = rho_EQ(VIs,DI,Vbins);
rE = PEq_s.*exp(fin_s(:,1:N)*La1); % Calculate p(x)
rI = PIq_s.*exp(fin_s(:,1:N)*LaI1); % Calculate p(x)
rE = rE/sum(rE)*(Vbins(2) - Vbins(1)) ;
rI = rI/sum(rI)*(Vbins(2) - Vbins(1)) ;

    if (MFE_COMPUT_USED) %% it is a swich to open the following code %%
        %%%%%%%%%%%%%%%%%%%%%% detect MFEs
        %% we randomly decide to actually carry through with an MFE with probability local_pevent %%
        local_pevent_d = rand(1);
        if(local_pevent_d<local_pevent)
MFE_flag=1;
MFE_num = MFE_num+1;
VE = transpose(getsamples(Vedges,rE,NE)); VE(1:2) = vT;
VI = transpose(getsamples(Vedges,rI,NI));
[E_fired,I_fired,VEpos,VIpos] = getMFE_ifdyn(0,VE,VI,D_tranformed);
Lt_ra(MFE_num) = dt*iteration; LE_ra(MFE_num) = length(E_fired); LI_ra(MFE_num) = length(I_fired);
            fprintf(fid,'%16.4e    %16.0e     %16.0e   %16.0e     %16.0e\n', t_sum,0,0,length(E_fired),length(I_fired));
disp(sprintf('resolving MFE %d at time %f, P_MFE %f, LE %d LI %d ',MFE_num,Lt_ra(MFE_num),P_MFE/dt,LE_ra(MFE_num),LI_ra(MFE_num)));
VEpos(E_fired)=VR; VIpos(I_fired)=VR;
rE = transpose(histc(VEpos,Vedges)); rE = rE(1:end-1); rE = rE/(sum(rE)*(Vbins(2)-Vbins(1)));
rI = transpose(histc(VIpos,Vedges)); rI = rI(1:end-1); rI = rI/(sum(rI)*(Vbins(2)-Vbins(1)));

% % % % % [vbarE,wbarE,vbar3E,vbar4E] = histstats_Jiwei(rE,Vbins) 
% % % % % [vbarI,wbarI,vbar3I,vbar4I] = histstats_Jiwei(rI,Vbins) 
% % % % % pause();
V1 = Vbins; V2 = V1.*Vbins; V3 = V2.*Vbins; V4 = V3.*Vbins;
vbarE = sum(V1.*rE)*(Vbins(2)-Vbins(1));
wbarE = sum(V2 .*rE)*(Vbins(2)-Vbins(1));
vbar3E = sum(V3 .*rE)*(Vbins(2)-Vbins(1));
vbar4E = sum(V4 .*rE)*(Vbins(2)-Vbins(1));

vbarI = sum(V1.*rI)*(Vbins(2)-Vbins(1));
wbarI = sum(V2 .*rI)*(Vbins(2)-Vbins(1));
vbar3I = sum(V3 .*rI)*(Vbins(2)-Vbins(1));
vbar4I = sum(V4 .*rI)*(Vbins(2)-Vbins(1));
LE = length(E_fired); LI = length(I_fired);
            
%  [vbarE,vbarI,wbarE,wbarI,vbar3E,vbar3I,vbar4E,vbar4I] = ...
%                bra_wrapper_event_master_Eq(RvE,RvI,V,SEE*LE/NE,SIE*LE/NE,SEI*LI/NE,SII*LI/NI, V_start,V_end,h,source,LE,LI,NE,NI);
           

            
         fprintf(fid,'%16.4e    %16.4e     %16.4e   %16.4e     %16.4e\n', t,0,0,LE,LI);

            mI =0; mE=0;
            gammaE = [1,vbarE,wbarE,vbar3E,vbar4E];
            gammaI = [1,vbarI,wbarI,vbar3I,vbar4I];
             [VEs,VIs] = VQs(fE,fI,etaE,etaI,SEE,SIE,SEI,SII,mE,mI,vL,gL);
             [DE,DI] = DEDI(fE,fI,etaE,etaI,SEE,SIE,SEI,SII,mE,mI,NE,NI,gL); %% here DE is the DE^2 in the note
    
fiE = abs([1,vbarE,wbarE,vbar3E,vbar4E]');
fiI = abs([1,vbarI,wbarI,vbar3I,vbar4I]');

[PEq,sumE ]= rho_EQ(VEs,DE,V);
[PIq,sumI] = rho_EQ(VIs,DI,V);
if moment2
F = fiE(2:3);FI = fiI(2:3);
else
F = fiE(2:end);FI = fiI(2:end);
end

if moment2 
    La0 = 0*gammaE(1:3)';
    LaI0 = 0*gammaI(1:3)';
else
     La0 = 0*gammaE(1:end)';
     LaI0 = 0*gammaI(1:end)';
end

% % [La1] = fsolve(@(La)optfun(F,V,La,PEq,fin,1),La0,optimset('Display','off'));
% %      [LaI1] = fsolve(@(LaII)optfun(FI,V,LaII,PIq,fin,1),LaI0,optimset('Display','off'));

     [La1] = fminsearch(@(La)optfun(F,V,La,PEq,fin,1),La0,options);
     [LaI1] = fminsearch(@(LaII)optfun(FI,V,LaII,PIq,fin,1),LaI0,options);
%   g1 = 0:0.005:1;
% 
% for j = 1:length(g1);
%      [La1] = fminsearch(@(La)optfun(F,V,La,PEq,fin,g1(j)),La0,options);
%      [LaI1] = fminsearch(@(LaII)optfun(FI,V,LaII,PIq,fin,g1(j)),LaI0,options);
%    La0 = real(La1);
%    LaI0 = real(LaI1);
% end

% [La1] = fminsearch(@(La)optfun(F,V,La,PEq,fin,1),La0,options);
%  [LaI1] = fminsearch(@(LaII)optfun(FI,V,LaII,PIq,fin,1),LaI0,options);

     
   La0 = real(La1);
   LaI0 = real(LaI1);

        end %% end of if((local_pevent_d = rand(1))<local_event) %%
    end %%  end of if (MFE_COMPUT_USED) %%
   
if dtbin_record_flag; 
dtbin_ij = 1 + floor(iteration/dtperbin);
mEbin_ra(dtbin_ij) = mEbin_ra(dtbin_ij) + (1-MFE_flag)*mE_ra(1+iteration)*NE*dt + MFE_flag*LE_ra(MFE_num);
mIbin_ra(dtbin_ij) = mIbin_ra(dtbin_ij) + (1-MFE_flag)*mI_ra(1+iteration)*NI*dt + MFE_flag*LI_ra(MFE_num);
xEbin_ra(dtbin_ij) = xEbin_ra(dtbin_ij) + (1-MFE_flag)*psample(mE_ra(1+iteration)*NE*dt) + MFE_flag*LE_ra(MFE_num);
xIbin_ra(dtbin_ij) = xIbin_ra(dtbin_ij) + (1-MFE_flag)*psample(mI_ra(1+iteration)*NI*dt) + MFE_flag*LI_ra(MFE_num);
P_MFEbin_ra(dtbin_ij) = P_MFEbin_ra(dtbin_ij) + P_MFE_ra(1+iteration)*dt;
end;% if dtbin_record_flag;

if plot_flag;
subplot(2,2,1); hold on; if mod(iteration,512)==0; plot(Vbins,rE,'r-',Vbins,rI,'b-'); end; hold off;
end;%if plot_flag;

t_sum = t_sum+dt;
    
    
    
    
    counter_firing_step = 1+counter_firing_step;
    sum_mE = mE + sum_mE;sum_mI = mI + sum_mI;
    
    if(counter_firing_step*dt >= 1.0)
        if density_plot_or_not
        filename_rec2 =  [catalog_head1,catalog_str,var_fn2,'_',num2str(density_record_counter),'.txt'];
fid2 = fopen(filename_rec2, 'wt');

    lnv = length(V);
    for i = 1:5:lnv
        fprintf(fid2,'%16.5e    %16.5e    %16.5e\n', V(i), RvE(i), RvI(i));
    end
    fclose(fid2);
    density_record_counter = density_record_counter + 1;
        end
        mE_pn1 = sum_mE/counter_firing_step;
        mI_ln1 = sum_mI/counter_firing_step;
        fprintf(fid,'%16.4e    %16.4e     %16.4e   %16.0e     %16.0e\n', t, mE_pn1,mI_ln1,0,0);
        fprintf(fid1,'%16.4e    %16.4e     %16.4e   %16.4e     %16.4e    %16.4e    %16.4e     %16.4e   %16.4e\n', t, vbarE,wbarE,vbar3E,vbar4E,vbarI,wbarI,vbar3I,vbar4I);
        sum_mE = 0; sum_mI = 0.0; counter_firing_step = 0;
    end 
    
    
    
    
    
end
  
fclose(fid);
fclose(fid1);


if plot_flag;
xlim([Vedges(1) Vedges(end)]);
subplot(2,2,2); plot(Vbins,rE,'r.-',Vbins,rI,'b.-');
subplot(2,2,[3 4]); plot(t_ra,mE_ra,'r.-',t_ra,mI_ra,'b.-',t_ra,P_MFE_ra,'g.-');
%if plot_flag; print('-depsc',sprintf('%s_FIG_A.eps',filename_base)); end;
end;%if plot_flag;

plot_flag=0;
if plot_flag;
figure;
plot(Vbins,rE,'r-',Vbins,rI,'b-');
xlim([Vedges(j_source) Vedges(end)]);
%if plot_flag; print('-depsc',sprintf('%s_FIG_B.eps',filename_base)); end;
end;%if plot_flag;

plot_flag=0;
if plot_flag & dt_record_flag;
[rtmp,ctmp] = size(rE_ra); j_source = (rtmp+1)/2;
subplot(4,1,1);imagesc(rE_ra(end:-1:j_source,:)*sparse(1:ctmp,1:ctmp,1./sum(rE_ra,1)),[0 4/1024]);
[rtmp,ctmp] = size(rI_ra); j_source = (rtmp+1)/2;
subplot(4,1,2);imagesc(rI_ra(end:-1:j_source,:)*sparse(1:ctmp,1:ctmp,1./sum(rI_ra,1)),[0 4/1024]);
subplot(4,1,3); plot(t_ra,P_MFE_ra,'g-'); xlim([min(t_ra) max(t_ra)]);
subplot(4,1,4); 
hold on; 
plot(t_ra,mE_ra,'r-',t_ra,mI_ra,'b-');
l = line([Lt_ra;Lt_ra],[zeros(size(LE_ra));LE_ra]/NE); set(l,'LineWidth',1,'Color',[1 0 0]);
l = line([Lt_ra;Lt_ra],[zeros(size(LI_ra));LI_ra]/NI); set(l,'LineWidth',3,'Color',[0 0 1]);
xlim([min(t_ra) max(t_ra)]);
hold off;
end;%if plot_flag & dt_record_flag;

plot_flag=1;
nsec_to_plot=1;
if plot_flag & dtbin_record_flag;
figure;
tij=max(1,(TMAX-1024*nsec_to_plot)/tbinsize):TMAX/tbinsize;
[rtmp,ctmp] = size(rEbin_ra); j_source = (rtmp+1)/2;
subplot(5,1,1);imagesc(rEbin_ra(end:-1:j_source,tij)*sparse(1:length(tij),1:length(tij),1./sum(rEbin_ra(end:-1:j_source,tij),1)),[0 4/1024]); ylabel('VE');
set(gca,'YTick',[1 j_source]);set(gca,'YTickLabel',{'VT','VR'});
[rtmp,ctmp] = size(rIbin_ra); j_source = (rtmp+1)/2;
subplot(5,1,2);imagesc(rIbin_ra(end:-1:j_source,tij)*sparse(1:length(tij),1:length(tij),1./sum(rIbin_ra(end:-1:j_source,tij),1)),[0 4/1024]); ylabel('VI');
set(gca,'YTick',[1 j_source]);set(gca,'YTickLabel',{'VT','VR'});
subplot(5,1,3);
hold on;
l=stairs(tbin_ra(tij),VEavgbin_ra(tij),'r-'); set(l,'LineWidth',2);
l=stairs(tbin_ra(tij),VEavgbin_ra(tij)+VEstdbin_ra(tij),'r:'); set(l,'LineWidth',1);
l=stairs(tbin_ra(tij),VEavgbin_ra(tij)-VEstdbin_ra(tij),'r:'); set(l,'LineWidth',1);
l=stairs(tbin_ra(tij),VIavgbin_ra(tij),'b-'); set(l,'LineWidth',2);
l=stairs(tbin_ra(tij),VIavgbin_ra(tij)+VIstdbin_ra(tij),'b:'); set(l,'LineWidth',1);
l=stairs(tbin_ra(tij),VIavgbin_ra(tij)-VIstdbin_ra(tij),'b:'); set(l,'LineWidth',1);
xlim([min(tbin_ra(tij)) max(tbin_ra(tij))]);
ylim([VR vT]); ylabel('Vavg');
set(gca,'YTick',[0 1]);set(gca,'YTickLabel',{'VR','VT'});
hold off;
subplot(5,1,4); stairs(tbin_ra(tij),P_MFEbin_ra(tij),'g-'); xlim([min(tbin_ra(tij)) max(tbin_ra(tij))]); ylabel('P/dt');
subplot(5,1,5); hold on; stairs(tbin_ra(tij),xEbin_ra(tij),'r-'); stairs(tbin_ra(tij),xIbin_ra(tij),'b-'); xlim([min(tbin_ra(tij)) max(tbin_ra(tij))]); ylabel('#spk'); hold off; 
print('-depsc',sprintf('%s_JW_full_FIG_A.eps',filename_base));
print('-djpeg',sprintf('%s_JW_full_FIG_A.jpg',filename_base));
end;%if plot_flag & dtbin_record_flag;

plot_flag=1;
if plot_flag & dtbin_record_flag;
figure;
subplot(2,2,1); 
hold on;
rEtmp = mean(rEbin_ra,2); l=stairs(Vbins,rEtmp,'r-'); set(l,'LineWidth',2);
rItmp = mean(rIbin_ra,2); l=stairs(Vbins,rItmp,'b-'); set(l,'LineWidth',2);
xlim([Vbins(j_source) Vbins(end)]); %ylim([0 0.005]);
hold off;
subplot(2,2,2);
hold on;
hEtmp = hist(mEbin_ra,[1:1.5*NE]); l=plot(log2([1:1.5*NE]),log2(1+hEtmp),'r-'); set(l,'LineWidth',2);
hItmp = hist(mIbin_ra,[1:1.5*NI]); l=plot(log2([1:1.5*NI]),log2(1+hItmp),'b-'); set(l,'LineWidth',2);
%hEtmp = hist(mEbin_ra,[1:1.5*NE]); l=loglog(([1:1.5*NE]),(1+hEtmp),'r-'); set(l,'LineWidth',2);
%hItmp = hist(mIbin_ra,[1:1.5*NI]); l=loglog(([1:1.5*NI]),(1+hItmp),'b-'); set(l,'LineWidth',2);
hold off;
subplot(2,2,[3,4]);
h = spectrum.mtm; Fs = 1000*1/tbinsize; hpsd = psd(h,(VEavgbin_ra*NE + VIavgbin_ra*NI)/(NE+NI),'Fs',Fs); plot(hpsd);
print('-depsc',sprintf('%s_JW_full_FIG_B.eps',filename_base));
print('-djpeg',sprintf('%s_JW_full_FIG_B.jpg',filename_base));
end;%if plot_flag & dtbin_record_flag;

% save(sprintf('%s_data.mat',filename_base));



function output = getsamples(Vedges,rho,Nsamples)
rho = [0;rho(:)]/sum(rho);
L = length(rho);
F = cumsum(rho);
[Fv,Fi,Fj] = unique(F,'first');
output = interp1(F(Fi),Vedges(Fi),rand(Nsamples,1));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [m1,m2,m3,m4] = histstats_Jiwei(hra,Vbins);
m1 = trapz(Vbins, Vbins.*hra);
m2 = trapz(Vbins, Vbins.^2.*hra);
m3 = trapz(Vbins, Vbins.^3.*hra);
m4 = trapz(Vbins, Vbins.^4.*hra);



function [E_fired,I_fired,VE,VI,VEbar_min,VIbar_min] = getMFE_ifdyn(verbose,VE,VI,D);
% assumes all the voltages are distinct;
% we also *approximate* (not exactly) the maximum nonfiring voltages VQbar;
TAU_V=20;VT=1;VR=0;
NE = length(VE); NI = length(VI);
if (verbose); [VE_trn,VI_trn] = V_transform(VE,VI,D); end;
DII = D(1,1); DIE = D(1,2); DIY = D(1,3);
DEI = D(2,1); DEE = D(2,2); DEY = D(2,3);
if (verbose); disp(sprintf(' DII %0.2f DIE %0.2f DEI %0.2f DEE %0.2f',DII,DIE,DEI,DEE)); end;
[VE,VEj] = sort(VE); [VI,VIj] = sort(VI); [VEjs,VEr] = sort(VEj); [VIjs,VIr] = sort(VIj); 
VE_orig = VE; VI_orig = VI; VEbar=VT; VEtab=1; VIbar=VT; VItab=1;
I_fired = find(VI>=VT);
LI = length(I_fired);
I_remaining = find(VI<VT);
accumulated_DII=0; accumulated_DEI=0;
if LI>0;
if (verbose); disp(sprintf('LI %d, shifting VE',LI)); end;
VE = VE - DEI*LI; accumulated_DEI = accumulated_DEI + DEI*LI; VEbar(VEtab+1) = VEbar(VEtab) + DEI*LI; VEtab = VEtab+1;
if (verbose); disp(sprintf('LI %d, shifting VI',LI)); end;
VI(I_remaining) = VI(I_remaining) - DII*LI; accumulated_DII = accumulated_DII + DII*LI; VIbar(VItab+1) = VIbar(VItab) + DII*LI; VItab = VItab+1;
end;%if LI>0;
E_fired = find(VE>=VT);
LE = length(E_fired);
if (verbose); disp(sprintf('LE %d',LE)); end;
E_remaining = find(VE<VT);
total_V_to_add_to_E = DEE*LE; 
total_V_to_add_to_I = DIE*LE; 
if (verbose); disp(sprintf('')); end;
while (total_V_to_add_to_E>0 | total_V_to_add_to_I>0);
if (verbose); disp(sprintf('total_V_to_add_to_I %0.2f, I_remaining %d total_V_to_add_to_E %0.2f E_remaining %d',total_V_to_add_to_I,length(I_remaining),total_V_to_add_to_E,length(E_remaining))); end;
possible_E_spikes = find(VE(E_remaining)>=VT-total_V_to_add_to_E);
[max_E,ind_E] = max(VE(E_remaining));
possible_I_spikes = find(VI(I_remaining)>=VT-total_V_to_add_to_I);
[max_I,ind_I] = max(VI(I_remaining));
if (verbose); disp(sprintf('possible_E_spikes %d possible_I_spikes %d',length(possible_E_spikes),length(possible_I_spikes))); end;
if (isempty(possible_E_spikes) & isempty(possible_I_spikes)); 
  if (verbose); disp(sprintf('none can fire')); end;
  V_to_add_to_E = total_V_to_add_to_E; 
  V_to_add_to_I = total_V_to_add_to_I;
  if (verbose); disp(sprintf(' VtoI %0.2f VtoE %0.2f',V_to_add_to_I,V_to_add_to_E)); end;
  VE(E_remaining) = VE(E_remaining) + V_to_add_to_E; VEbar(VEtab+1) = VEbar(VEtab) - V_to_add_to_E; VEtab = VEtab+1;
  VI(I_remaining) = VI(I_remaining) + V_to_add_to_I; VIbar(VItab+1) = VIbar(VItab) - V_to_add_to_I; VItab = VItab+1;
  total_V_to_add_to_E = 0;
  total_V_to_add_to_I = 0;
elseif (~isempty(possible_E_spikes) & isempty(possible_I_spikes)); 
  if (verbose); disp(sprintf('only E can fire')); end;
  V_to_add_to_E = VT - max_E; 
  V_to_add_to_I = min(total_V_to_add_to_I,VT - max_E);
  if (verbose); disp(sprintf(' VtoI %0.2f VtoE %0.2f',V_to_add_to_I,V_to_add_to_E)); end;
  E_fired = [E_fired(:);ind_E]; E_remaining = setdiff(E_remaining,ind_E); LE = LE+1; if (verbose>1);hold on;; plot(VE_trn(ind_E),1-(LE+LI)/(NE+NI),'ro'); hold off; end;
  VE(E_remaining) = VE(E_remaining) + V_to_add_to_E; VEbar(VEtab+1) = VEbar(VEtab) - V_to_add_to_E; VEtab = VEtab+1;
  VI(I_remaining) = VI(I_remaining) + V_to_add_to_I; VIbar(VItab+1) = VIbar(VItab) - V_to_add_to_I; VItab = VItab+1;
  total_V_to_add_to_E = total_V_to_add_to_E - V_to_add_to_E + DEE; 
  total_V_to_add_to_I = total_V_to_add_to_I - V_to_add_to_I + DIE;
elseif (isempty(possible_E_spikes) & ~isempty(possible_I_spikes)); 
  if (verbose); disp(sprintf('only I can fire')); end;
  V_to_add_to_I = VT - max_I; 
  V_to_add_to_E = min(total_V_to_add_to_E,VT - max_I);
  if (verbose); disp(sprintf(' VtoI %0.2f VtoE %0.2f',V_to_add_to_I,V_to_add_to_E)); end;
  VE(E_remaining) = VE(E_remaining) - DEI + V_to_add_to_E; accumulated_DEI = accumulated_DEI + DEI; VEbar(VEtab+1) = VEbar(VEtab) - V_to_add_to_E; VEtab = VEtab+1; VEbar(VEtab+1) = VEbar(VEtab) + DEI; VEtab = VEtab+1;
  I_fired = [I_fired(:);ind_I]; I_remaining = setdiff(I_remaining,ind_I); LI=LI+1; if (verbose>1);hold on;; plot(VI_trn(ind_I),1-(LE+LI)/(NE+NI),'bo'); hold off; end;
  VI(I_remaining) = VI(I_remaining) - DII + V_to_add_to_I; accumulated_DII = accumulated_DII + DII; VIbar(VItab+1) = VIbar(VItab) - V_to_add_to_I; VItab = VItab+1; VIbar(VItab+1) = VIbar(VItab) + DII; VItab = VItab+1;
  total_V_to_add_to_E = total_V_to_add_to_E - V_to_add_to_E;
  total_V_to_add_to_I = total_V_to_add_to_I - V_to_add_to_I;
elseif (~isempty(possible_E_spikes) & ~isempty(possible_I_spikes)); 
% disp('We assume that E and I increase in voltage at a fixed rate');
% disp('this is tantamount to the impulse response of gE being a step function, with height proportional to DQE and constant width (e.g., 1)');
if ((VT-VI_orig(ind_I) + accumulated_DII)/DIE <= (VT-VE_orig(ind_E) + accumulated_DEI)/DEE);
  if (verbose); disp(sprintf('both E and I can fire, I closer')); end;
  V_to_add_to_I = VT - max_I; 
  V_to_add_to_E = min(total_V_to_add_to_E,VT - max_I);
  if (verbose); disp(sprintf(' VtoI %0.2f VtoE %0.2f',V_to_add_to_I,V_to_add_to_E)); end;
  VE(E_remaining) = VE(E_remaining) - DEI + V_to_add_to_E; accumulated_DEI = accumulated_DEI + DEI; VEbar(VEtab+1) = VEbar(VEtab) - V_to_add_to_E; VEtab = VEtab+1; VEbar(VEtab+1) = VEbar(VEtab) + DEI; VEtab = VEtab+1;
  I_fired = [I_fired(:);ind_I]; I_remaining = setdiff(I_remaining,ind_I); LI=LI+1; if (verbose>1);hold on;; plot(VI_trn(ind_I),1-(LE+LI)/(NE+NI),'bo'); hold off; end;
  VI(I_remaining) = VI(I_remaining) - DII + V_to_add_to_I; accumulated_DII = accumulated_DII + DII; VIbar(VItab+1) = VIbar(VItab) - V_to_add_to_I; VItab = VItab+1; VIbar(VItab+1) = VIbar(VItab) + DII; VItab = VItab+1;
  total_V_to_add_to_E = total_V_to_add_to_E - V_to_add_to_E;
  total_V_to_add_to_I = total_V_to_add_to_I - V_to_add_to_I;
elseif ((VT-VI_orig(ind_I) + accumulated_DII)/DIE >  (VT-VE_orig(ind_E) + accumulated_DEI)/DEE);
  if (verbose); disp(sprintf('both E and I can fire, E closer')); end;
  V_to_add_to_E = VT - max_E; 
  V_to_add_to_I = min(total_V_to_add_to_I,VT - max_E);
  if (verbose); disp(sprintf(' VtoI %0.2f VtoE %0.2f',V_to_add_to_I,V_to_add_to_E)); end;
  E_fired = [E_fired(:);ind_E]; E_remaining = setdiff(E_remaining,ind_E); LE = LE+1; if (verbose>1);hold on;; plot(VE_trn(ind_E),1-(LE+LI)/(NE+NI),'ro'); hold off; end;
  VE(E_remaining) = VE(E_remaining) + V_to_add_to_E; VEbar(VEtab+1) = VEbar(VEtab) - V_to_add_to_E; VEtab = VEtab+1;
  VI(I_remaining) = VI(I_remaining) + V_to_add_to_I; VIbar(VItab+1) = VIbar(VItab) - V_to_add_to_I; VItab = VItab+1;
  total_V_to_add_to_E = total_V_to_add_to_E - V_to_add_to_E + DEE; 
  total_V_to_add_to_I = total_V_to_add_to_I - V_to_add_to_I + DIE;
end;%if max_E<>max_I;
end;%if any possible spikes;
end;%while (total_V_to_add>0);
VE = reshape(VE,1,NE);
VI = reshape(VI,1,NI);
E_fired = reshape(E_fired,1,length(E_fired));
I_fired = reshape(I_fired,1,length(I_fired));
if (verbose); disp(sprintf(' LE %d, LI %d',LE,LI)); end;
E_fired = VEj(E_fired);
I_fired = VIj(I_fired);
VE = VE(VEr);
VI = VI(VIr);
VEbar_min = min([VT VEbar]);
VIbar_min = min([VT VIbar]);


function output = psample(ldt);
% draws an event count from a Poisson process with rate lambda over time dt;
if ldt>5; output = max(0,round(ldt + sqrt(ldt)*randn())); 
else; 
kra = 0:14;
pra = [-1 , cumsum((ldt.^kra).*exp(-ldt)./factorial(kra)) , 2];
output = max(find(~(min(rand(),pra(end-1))<=pra)))-1;
end;% if ldt>7;



function [VEs,VIs] = VQs(fE, fI,etaE,etaI, SEE, SIE, SEI,SII,mE,mI,vL,gL)
                  
%% Assume that vL = 0; gL = 0.005
% if (gL ==0)
%     warning('gL can not be 0 in VQs function');
% end
VEs = (vL*gL + etaE*fE + mE*SEE - mI*SEI)/gL;
VIs = (vL*gL + etaI*fI + mE*SIE - mI*SII)/gL;

function [DE,DI] = DEDI(fE, fI,etaE,etaI, SEE, SIE, SEI,SII,mE,mI,NE,NI,gL)
        
%% Assume that vL = 0; gL = 0.005
% if (NI ==0 | NE == 0)
%     warning('NI or NE can not be 0 in VQs function');
% end
DE = (etaE*fE^2 + mE*SEE^2/NE + mI*SEI^2/NI)/gL;
DI = (etaI*fI^2 + mE*SIE^2/NE + mI*SII^2/NI)/gL;



function [vbarE1,vbarI1,wbarE1,wbarI1,vbar3E1,vbar3I1,vbar4E1,vbar4I1] ...
        = solveVbarWbar4(dt,vbarE, vbarI, wbarE, wbarI,vbar3E, vbar3I,vbar4E, vbar4I,VEs,VIs,DE, DI,mE,mI,gL)
%% Here assume thatn vT =1; so the coefficient of mE and mI is 1, we do not multiply them ...
dtgL =dt*gL;
vbarE1 = vbarE + dtgL*(- mE/gL - (vbarE - VEs));
vbarI1 = vbarI + dtgL*(- mI/gL - (vbarI - VIs));

wbarE1 = wbarE + dtgL*(- mE/gL - 2.0*(wbarE - VEs*vbarE - 0.5*DE));
wbarI1 = wbarI + dtgL*(- mI/gL - 2.0*(wbarI - VIs*vbarI - 0.5*DI) );

vbar3E1 = vbar3E + dtgL*(- mE/gL - 3.0*(vbar3E - VEs*wbarE - DE*vbarE));
vbar3I1 = vbar3I + dtgL*(- mI/gL - 3.0*(vbar3I - VIs*wbarI - DI*vbarI));

vbar4E1 = vbar4E + dtgL*(- mE/gL - 4.0*(vbar4E - VEs*vbar3E - 1.5*DE*wbarE));
vbar4I1 = vbar4I + dtgL*(- mI/gL - 4.0*(vbar4I - VIs*vbar3I - 1.5*DI*wbarI));


function [Rv,sum_c] = rho_EQ(Vs,D,V)
%% here D = D^2, sigma = sigma^2;
Rv = V;
vT = 1; vR = 0;  indp = find(V>vR);
sqrtD = sqrt(D);
intovT = dawson((vT-Vs)/sqrtD)*exp((vT-Vs)^2/D);
intovSD = dawson(-Vs/sqrtD)*exp(Vs^2/D);

%% compute R with V>vR case:
Rv(indp) = - dawson((V(indp)-Vs)/sqrtD) ...
    + exp(-(V(indp) - Vs).^2/D)* intovT;

if (indp(1)>1)
    Rv(1:indp(1)-1) = exp(-(V(1:indp(1)-1) - Vs).^2/D)* (-intovSD + intovT);
end
indp = find(V<-2/3);
Rv(1:indp) = 0;
sum_c = (V(2)-V(1))*sum(Rv);
Rv = Rv/sum_c;


function [f,g] = optfun(mu,x,lambda0,PEq,fin,gamma)
  % optfun(MU,X,LAMBDA0)
 % This program calculates the Lagrange Multipliers of the ME
 % probability density functions p(x) from the knowledge of the
 % N moment contstraints in the form:
% E{x^n}=mu(n) n=0:N with mu(0)=1.
 %
 % MU is a table containing the constraints MU(n),n=1:N.
 % X is a table defining the range of the variation of x.
% LAMBDA0 is a table containing the first estimate of the LAMBDAs.
 % (This argument is optional.)
 % LAMBDA is a table containing the resulting Lagrange parameters.
 % P is a table containing the resulting pdf p(x).
 % ENTR is a table containing the entropy values at each
 % iteration.
 % f is the value of the function(lambda)
 % g is the gradiant of f
 
 mu=mu(:); mu=[1;mu]; % add mu(0)=1
 x=x(:);  % x axis
 dx=x(2)-x(1);
 lambda=lambda0(:);
 N=length(lambda);
%  fin=zeros(length(x),N); %
%  fin(:,1)=ones(size(x)); % fi0(x)=1
% 
%  for n=2:N
%       fin(:,n)=x.*fin(:,n-1);
%  end
%  p = power(PEq,gamma).*exp((fin(:,1:N)*lambda));  
 p = PEq.*exp((fin(:,1:N)*lambda));  
 
 f = dx*sum(p) - mu'*lambda;
  
 if nargout>1
 G=zeros(N,1); % Calculate Gn
 for n=1:N
  G(n) = trapz(x, fin(:,n).*p);
 end
 g=G(1:N) - mu; 
 end

 function [LE,LI,vbar,vE,vI,plot_hist] = Adi_getMFE_ifdyn(verbose,rho,rho_ln,v,vT_idx,NE,NI,NO_neu_fire_first,D);
% assumes all the voltages are distinct;
VT =1.0;
rho_E = rho(1:vT_idx);
rho_I = rho_ln(1:vT_idx);
volt = v(1:vT_idx);
fE=[0; cumsum(rho_E(1:end-1).*diff(volt))];
fI=[0; cumsum(rho_I(1:end-1).*diff(volt))];
fE(end)=1; fI(end)=1;
b= NO_neu_fire_first;
    u = rand(NE-b,1);
    VE = [interp1q(fE,volt,u); ones(b,1)*VT]; 
    u = rand(NI,1);
    VI = interp1q(fI,volt,u);
    VE=sort(VE);
    VI=sort(VI);


    
% [VE_bar,VI_bar] = V_transform(VE,VI,D);
DII = D(1); DIE = D(2); DEI = D(3); DEE = D(4);
% disp(sprintf(' DII %0.2f DIE %0.2f DEI %0.2f DEE %0.2f',DII,DIE,DEI,DEE));
VT=1;VR=0;
VE = sort(VE); VI = sort(VI);
VE_orig = VE; VI_orig = VI;
I_fired = find(VI>=VT);
LI = length(I_fired);
I_remaining = find(VI<VT);
accumulated_DII=0; accumulated_DEI=0;
if LI>0;
if (verbose); disp(sprintf('LI %d, shifting VE',LI)); end;
VE = VE - DEI*LI; accumulated_DEI = accumulated_DEI + DEI*LI;
if (verbose); disp(sprintf('LI %d, shifting VI',LI)); end;
VI(I_remaining) = VI(I_remaining) - DII*LI; accumulated_DII = accumulated_DII + DII*LI;
end;%if LI>0;
E_fired = find(VE>=VT);
LE = length(E_fired);
if (verbose); disp(sprintf('LE %d',LE)); end;
E_remaining = find(VE<VT);
total_V_to_add_to_E = DEE*LE; VbarE = DEE*LE;
total_V_to_add_to_I = DIE*LE; VbarI = DIE*LE;
if (verbose); disp(sprintf('')); end;
while (total_V_to_add_to_E>0 | total_V_to_add_to_I>0);
if (verbose); disp(sprintf('total_V_to_add_to_I %0.2f, I_remaining %d total_V_to_add_to_E %0.2f E_remaining %d',total_V_to_add_to_I,length(I_remaining),total_V_to_add_to_E,length(E_remaining))); end;
possible_E_spikes = find(VE(E_remaining)>=VT-total_V_to_add_to_E);
[max_E,ind_E] = max(VE(E_remaining));
possible_I_spikes = find(VI(I_remaining)>=VT-total_V_to_add_to_I);
[max_I,ind_I] = max(VI(I_remaining));
if (verbose); disp(sprintf('possible_E_spikes %d possible_I_spikes %d',length(possible_E_spikes),length(possible_I_spikes))); end;
if (isempty(possible_E_spikes) & isempty(possible_I_spikes)); 
  if (verbose); disp(sprintf('none can fire')); end;
  V_to_add_to_E = total_V_to_add_to_E;
  V_to_add_to_I = total_V_to_add_to_I;
  if (verbose); disp(sprintf(' VtoI %0.2f VtoE %0.2f',V_to_add_to_I,V_to_add_to_E)); end;
  VE(E_remaining) = VE(E_remaining) + V_to_add_to_E; 
  VI(I_remaining) = VI(I_remaining) + V_to_add_to_I;
  total_V_to_add_to_E = 0;
  total_V_to_add_to_I = 0;
elseif (~isempty(possible_E_spikes) & isempty(possible_I_spikes)); 
  if (verbose); disp(sprintf('only E can fire')); end;
  V_to_add_to_E = VT - max_E; 
  V_to_add_to_I = min(total_V_to_add_to_I,VT - max_E);
  if (verbose); disp(sprintf(' VtoI %0.2f VtoE %0.2f',V_to_add_to_I,V_to_add_to_E)); end;
  E_fired = [E_fired(:);ind_E]; E_remaining = setdiff(E_remaining,ind_E); LE = LE+1; if (verbose>1);hold on;; plot(VE_bar(ind_E),1-(LE+LI)/(NE+NI),'ro'); hold off; end;
  VE(E_remaining) = VE(E_remaining) + V_to_add_to_E; 
  VI(I_remaining) = VI(I_remaining) + V_to_add_to_I;
  total_V_to_add_to_E = total_V_to_add_to_E - V_to_add_to_E + DEE; VbarE = VbarE + DEE;
  total_V_to_add_to_I = total_V_to_add_to_I - V_to_add_to_I + DIE; VbarI = VbarI + DIE;
elseif (isempty(possible_E_spikes) & ~isempty(possible_I_spikes)); 
  if (verbose); disp(sprintf('only I can fire')); end;
  V_to_add_to_I = VT - max_I; 
  V_to_add_to_E = min(total_V_to_add_to_E,VT - max_I);
  if (verbose); disp(sprintf(' VtoI %0.2f VtoE %0.2f',V_to_add_to_I,V_to_add_to_E)); end;
  VE(E_remaining) = VE(E_remaining) - DEI + V_to_add_to_E; accumulated_DEI = accumulated_DEI + DEI;
  I_fired = [I_fired(:);ind_I]; I_remaining = setdiff(I_remaining,ind_I); LI=LI+1; if (verbose>1);hold on;; plot(VI_bar(ind_I),1-(LE+LI)/(NE+NI),'bo'); hold off; end;
  VI(I_remaining) = VI(I_remaining) - DII + V_to_add_to_I; accumulated_DII = accumulated_DII + DII;
  total_V_to_add_to_E = total_V_to_add_to_E - V_to_add_to_E;
  total_V_to_add_to_I = total_V_to_add_to_I - V_to_add_to_I;
elseif (~isempty(possible_E_spikes) & ~isempty(possible_I_spikes)); 
% disp('We assume that E and I increase in voltage at a fixed rate');
% disp('this is tantamount to the impulse response of gE being a step function, with height proportional to DQE and constant width (e.g., 1)');
if ((VT-VI_orig(ind_I) + accumulated_DII)/DIE <= (VT-VE_orig(ind_E) + accumulated_DEI)/DEE);
  if (verbose); disp(sprintf('both E and I can fire, I closer')); end;
  V_to_add_to_I = VT - max_I; 
  V_to_add_to_E = min(total_V_to_add_to_E,VT - max_I);
  if (verbose); disp(sprintf(' VtoI %0.2f VtoE %0.2f',V_to_add_to_I,V_to_add_to_E)); end;
  VE(E_remaining) = VE(E_remaining) - DEI + V_to_add_to_E; accumulated_DEI = accumulated_DEI + DEI;
  I_fired = [I_fired(:);ind_I]; I_remaining = setdiff(I_remaining,ind_I); LI=LI+1; if (verbose>1);hold on;; plot(VI_bar(ind_I),1-(LE+LI)/(NE+NI),'bo'); hold off; end;
  VI(I_remaining) = VI(I_remaining) - DII + V_to_add_to_I; accumulated_DII = accumulated_DII + DII;
  total_V_to_add_to_E = total_V_to_add_to_E - V_to_add_to_E;
  total_V_to_add_to_I = total_V_to_add_to_I - V_to_add_to_I;
elseif ((VT-VI_orig(ind_I) + accumulated_DII)/DIE >  (VT-VE_orig(ind_E) + accumulated_DEI)/DEE);
  if (verbose); disp(sprintf('both E and I can fire, E closer')); end;
  V_to_add_to_E = VT - max_E; 
  V_to_add_to_I = min(total_V_to_add_to_I,VT - max_E);
  if (verbose); disp(sprintf(' VtoI %0.2f VtoE %0.2f',V_to_add_to_I,V_to_add_to_E)); end;
  E_fired = [E_fired(:);ind_E]; E_remaining = setdiff(E_remaining,ind_E); LE = LE+1; if (verbose>1);hold on;; plot(VE_bar(ind_E),1-(LE+LI)/(NE+NI),'ro'); hold off; end;
  VE(E_remaining) = VE(E_remaining) + V_to_add_to_E; 
  VI(I_remaining) = VI(I_remaining) + V_to_add_to_I;
  total_V_to_add_to_E = total_V_to_add_to_E - V_to_add_to_E + DEE; VbarE = VbarE + DEE;
  total_V_to_add_to_I = total_V_to_add_to_I - V_to_add_to_I + DIE; VbarI = VbarI + DIE;
end;%if max_E<>max_I;
end;%if any possible spikes;
end;%while (total_V_to_add>0);
% if ~isempty(E_fired)
% VbarE =VT- VE_bar(E_fired(end));
% else
%     VbarE = 0;
% end
% if ~isempty(I_fired)
%     VbarI = VT-VI_bar(I_fired(end));
% else
%     VbarI =0;
% end
% vbar = max(VbarI,VbarE);
LE = length(E_fired);
LI = length(I_fired);
vE = VE(E_remaining);
vI = VI(I_remaining);

% plot_hist = 0;
% if LE>40;
% figure;
% nbins=64;hE = hist(VE,linspace(0,1,nbins));
% subplot(2,2,1);bE = bar(1:nbins,hE,1,'r');axis tight;axis on;set(bE,'LineStyle','none');
% title('Before, E-hist');
% set(gca,'XTickLabel',{' '});
% ylabel(['Histogram of voltage'])
% hE = hist(VI,linspace(0,1,nbins));
% subplot(2,2,3);bE = bar(1:nbins,hE,1);axis tight;axis on;set(bE,'LineStyle','none');
% title('Before, I-hist');
% set(gca,'XTickLabel',{' '});
% ylabel(['Histogram of voltage'])
% 
% 
% 
% 
% subplot(2,2,2);
% hE = hist(vE,linspace(0,1,nbins));bE = bar(1:nbins,hE,1,'r');axis tight;axis on;set(bE,'LineStyle','none');
% ti = ['Just after, E-hist, and ', num2str(LE), ' Ex neu firing'];
% title(ti);
% set(gca,'XTickLabel',{' '});
% hE = hist(vI,linspace(0,1,nbins));
% subplot(2,2,4);bE = bar(1:nbins,hE,1);axis tight;set(bE,'LineStyle','none');axis on;
% ti = ['Just after, I-hist, and ', num2str(LI), ' In neu firing'];
% title(ti);
% set(gca,'XTickLabel',{' '});
% plot_hist = 1;
% end

 

function [Rv,sum_c] = help_density_R(Vs,D,mu,sigma,lambda3,lambda4,V)
%% here D = D^2, sigma = sigma^2;
Rv = V;
vT = 1; vR = 0;  indp = find(V>vR);
if D == 0;D = 0.001;end;
if sigma == 0;sigma = 0.001;end;
sqrtD = sqrt(D);
intovT = dawson((vT-Vs)/sqrtD)*exp((vT-Vs)^2/D);
intovSD = dawson(-Vs/sqrtD)*exp(Vs^2/D);

%% compute R with V>vR case:
Rv(indp) = - exp(-(V(indp) - mu).^2/sigma + (V(indp) - Vs).^2/D - lambda3*V(indp).^3 -lambda4*V(indp).^4).*dawson((V(indp)-Vs)/sqrtD) ...
    + exp(-(V(indp) - mu).^2/sigma -lambda3*V(indp).^3-lambda4*V(indp).^4)* intovT;

if (indp(1)>1)
    Rv(1:indp(1)-1) = exp(-(V(1:indp(1)-1) - mu).^2/sigma - lambda3*V(1:indp(1)-1).^3 -lambda4*V(1:indp(1)-1).^4)* (-intovSD + intovT);
end
indp = find(V<-2/3);
Rv(1:indp) = 0;
sum_c = (V(2)-V(1))*sum(Rv);
Rv = Rv/sum_c;



function [lE, lI] = New_get_LELI_from_P11(rho,rho_ln,v,NE,NI,N_neuron_fire_first,S_EE,S_EI,S_IE,S_II,v_start,v_end);
vT =v_end;vI = v_start;
v_o = v;rho_o = rho;rho_ln_o = rho_ln;

tStart = 0; tEnd = 1; tStep = 0.005; aEstep = 0.005; aEstart = -1; aEend = 1;
t1 = tStart:tStep:tEnd; aE = aEstart:aEstep:aEend;
alpha = min(S_EI/S_EE,S_II/S_IE)*NI/NE; NESEE = 1./NE/S_EE; %% Note that alpha can not be zero. or there will be 
t = vT - v_o(end:-1:1); rho  = rho_o(end:-1:1); rho_ln = rho_ln_o(end:-1:1);

%% t_hat = S_EE/S_IE*t; rho_ln_hat(t_hat) = S_IE/S_EE * rho_ln(t_hat*S_IE/S_EE);
rho_ln_hat = rho_ln;

if S_EE > S_IE
    t_temp = S_IE/S_EE*t; rho_ln_hat = S_IE/S_EE*interp1(t,rho_ln,t_temp);    
elseif S_EE < S_IE
    vIplusvT = vT-vI;
    t_temp = S_IE/S_EE*t; aInd = find(t_temp<=vIplusvT);
    rho_ln_hat(aInd) = S_IE/S_EE*interp1(t,rho_ln,t_temp(aInd));
    rho_ln_hat(aInd(end)+1:end) = 0;
end

%% Now we get the CDF of rho_ln_hat
F_hat_ln = [0; cumsum(rho_ln_hat(1:end-1).*diff(t))]; 
%% if (S_II*S_EE/S_IE>S_EI); s_bar = s_j; t_bar = t + NI*(S_EI > S_II*S_EE/S_IE)*F_hat_ln(t);
rho_ln_bar = rho_ln_hat; rho_bar = rho;
if (S_II*S_EE/S_IE > S_EI);
    gt = t + NI*(S_II*S_EE/S_IE - S_EI) .* F_hat_ln;
    gt(1) = 0;
    gt_inverse = interp1(gt,t,t);
    rho_temp = interp1(t,rho_ln_hat,gt_inverse);
    g_prime = 1 + NI*(S_II*S_EE/S_IE - S_EI) .* interp1(t,rho_ln_hat,gt_inverse);
    rho_ln_bar = rho_temp ./ g_prime;
elseif (S_II*S_EE/S_IE < S_EI); 
    gt = t + NI*(S_II*S_EE/S_IE - S_EI) .* F_hat_ln;
    gt(1) = 0; l_gt = length(gt);
    for jj = 1:l_gt;
        if(gt(jj)>0)
            rho_bar(jj) = interp1(t,rho,gt(jj)) .* ...
                (1 + NI*(S_II*S_EE/S_IE - S_EI) * interp1(t,rho_ln_hat,t(jj)));
        elseif(gt(jj)<=0)
            rho_bar(jj) = 0;
        end
    end
end
% figure;
% subplot(2,1,1)
% plot(t,rho,'mo',t,rho_bar,'r')
% subplot(2,1,2)
% plot(t,rho_ln_hat,'mo',t,rho_ln_bar,'b')
% figure

ind = find(rho_bar<0); rho_bar(ind) = 0;
f = [0; cumsum(rho_bar(1:end-1).*diff(t))]; 
f_ln = [0; cumsum(rho_ln_bar(1:end-1).*diff(t))]; 

q1 = zeros(length(aE),length(t1));
density = zeros(length(aE),length(t1));
p1 = zeros(length(aE),length(t1));
t_length = length(t1);
a_length = length(aE);
integral_from_r_to_t = 0; gamma = (NE-N_neuron_fire_first)/NE; sqrtGamma = sqrt(gamma^2+alpha^2);
for it = 2:t_length;
    tt = t1(it);tr = (t1(it) + t1(it-1))/2.0;
    rIt = interp1(t,rho_ln_bar,tt);rEt = interp1(t,rho_bar,tt); %% rIt = rho_I(t);
    rIr = interp1(t,rho_ln_bar,tr);rEr = interp1(t,rho_bar,tr); %% rIr = rho_I(r);
    
    fIt = interp1(t,f_ln,tt);fEt = interp1(t,f,tt);     %% fIt = f_I(t)
    fIr = interp1(t,f_ln,tr);fEr = interp1(t,f,tr);     %% fIr = f_I(r)

for ia = 1:a_length; %% make note that here aEr and aIr are vector, but aEt and aIt are scalar numbers.
    aEt = aE(ia); aIt = constrained_surface(aEt,tt,fEt,fIt,NESEE,alpha,NE,N_neuron_fire_first);
    bEr = aE; bIr = constrained_surface(bEr,tr,fEr,fIr,NESEE,alpha,NE,N_neuron_fire_first);
        dbEr = bEr(2)-bEr(1); dbIr = bIr(2) - bIr(1);
    q0 = Comput_q0(rIt,rEt,fIt,fEt,aIt,aEt,alpha,NE,NI,NESEE,N_neuron_fire_first,sqrtGamma);
    g = Comput_g(rIt,rEt,rIr,rEr,fIt,fEt,fIr,fEr,alpha,NE,NI,aIt,aEt,bIr,bEr,NESEE,N_neuron_fire_first,sqrtGamma);
    integral_from_r_to_t = integral_from_r_to_t + sqrt(dbEr^2+dbIr^2)*(sum(g)-g(1)/2-g(end)/2); 
    q1(ia,it) = q0 - integral_from_r_to_t;
    q1(ia,it) = max(0,q1(ia,it));
    f_density = fDesity(fEt,fIt,aEt,aIt,NE,NI,N_neuron_fire_first);
    density(ia,it) = f_density;
    p1(ia,it) = q1(ia,it)*f_density; 
end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dx = aE(2)-aE(1);

for it = 1:length(t1);
ps(it) = sum(p1(:,it))*dx;
end

sum_val = sum(ps)*tStep;
ps = ps/sum_val;

ps = ps';
t1 = t1';
fE=[0; cumsum(ps(1:end-1).*diff(t1))];
fE(end) = 1;

% for ii = 1:N_sim;
    
vE = interp1q(fE,t1,rand(1,1));
ind1 = dsearchn(t1,vE);
ind2 = dsearchn(t,vE);

aE = aE';

aE_bar = ind1;
for it = 1:length(ind1);
    faE = p1(:,ind1(it));
    faE = faE/(sum(faE)*(aE(2)-aE(1)));
        
    cdf2 = [0; cumsum(faE(1:end-1).*diff(aE))];
    u = rand(1,1);
    aE_bar(it) = [interp1q(cdf2,aE,u)];
    if isnan(aE_bar(it));aE_bar(it) = 0; end
end

LaE = floor(aE_bar*NE); LE = floor(NE*f(ind2));
lE =max(LE + LaE,2); 
lI = floor(NI*f_ln(ind2));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [vbarE,vbarI,wbarE,wbarI,vbar3E,vbar3I,vbar4E,vbar4I] ...
    = bra_wrapper_event_master_Eq(rho1,rho1_ln,V,S_EE_tot,S_IE_tot,S_EI_tot,S_II_tot, V_start,V_end,h,source,LE,LI,NE,NI); %% SEE_tot = SEE*mfirngevent(1); it is same for others
%% kick both rho_pn and rho_ln by mfiringevent[1](pn_type) and then mfiringevent[2] (ln_type)
[M_Syn_Ex1 M_Syn_In1 ...
    M_Syn_Ex1_ln M_Syn_In1_ln] = get_EX_IN_kick_matrix_for_rate_equation(V,S_EE_tot,S_IE_tot,S_EI_tot,S_II_tot,V_start,V_end,1); %% SEE_tot = SEE*mfirngevent(1); it is same for others
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% This for PN %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if LE==NE
    rho_pn_out =  source;
else
    rho_Ex_pn = M_Syn_Ex1*rho1;
    mE_pn = h*sum(rho_Ex_pn);
    rho_In_pn = M_Syn_In1*rho_Ex_pn;
    rho_pn_out = rho_In_pn + max(0,1-mE_pn)*source;
    rho_pn_out = rho_pn_out/(h*sum(rho_pn_out));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% This for LN %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if LI==NI
    rho_ln_out = source;
else
    rho_Ex_ln = M_Syn_Ex1_ln*rho1_ln;
    mE_ln = h*sum(rho_Ex_ln);
    rho_In_ln = M_Syn_In1_ln*rho_Ex_ln;
    rho_ln_out = rho_In_ln + max(0,1-mE_ln)*source;
    rho_ln_out = rho_ln_out/(h*sum(rho_ln_out));
end

% figure(5);
%  subplot(211)
%         plot(V,rho_pn_out,'mo');
%         subplot(212)
%         plot(V,rho_ln_out,'b*');
% pause(2);
V2 = V.^2; V3 = V2.*V; V4 = V3.*V;

vbarE = h*sum(V.*rho_pn_out);
wbarE = h*sum(V2 .*rho_pn_out);
vbar3E = h*sum(V3 .*rho_pn_out);
vbar4E = h*sum(V4 .*rho_pn_out);

vbarI = h*sum(V.*rho_ln_out);
wbarI = h*sum(V2 .*rho_ln_out);
vbar3I = h*sum(V3 .*rho_ln_out);
vbar4I = h*sum(V4 .*rho_ln_out);

 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function output = back_kick_constant(xv,xS)
output = xv - xS;

function f_desity = fDesity(fI,fE,aI,aE,NE,NI,N_neuron_fire_first)
vE = fE*(1-fE);
vI = fI*(1-fI);

if(vE*vI>0)
    f_desity = sqrt((NE-N_neuron_fire_first)*NI/(vE*vI))/2/pi*exp(-0.5*((NE-N_neuron_fire_first)*aE.^2/vE + NI*aI.^2/vI )) ;
else
    f_desity = 0*aE;
end

function aI = constrained_surface(aE,t,fEt,fIt,NESEE,alpha,NE,N_neuron_fire_first)
gamma = (NE-N_neuron_fire_first)/NE;
if(alpha>0)
aI = (fEt*gamma - alpha*fIt - NESEE*t + N_neuron_fire_first/NE + aE*gamma)/alpha;
else
    aI = 0*aE;
end

function g = Comput_g(rIt,rEt,rIr,rEr,fIt,fEt,fIr,fEr,alpha,NE,NI,aI,aE,bI,bE,NESEE,N_neuron_fire_first,sqrtGamma)
q0 = Comput_q0(rIr,rEr,fIr,fEr,aI,aE,alpha,NE,NI,NESEE,N_neuron_fire_first,sqrtGamma);
mid = get_mid_part_integral(aE,aI,bE,bI,rIt,rEt,rIr,rEr,fIt,fEt,fIr,fEr,NI,NE,alpha,NESEE,N_neuron_fire_first,sqrtGamma);
joint_density = get_joint_density(fIt,fEt,fIr,fEr,bE,bI,aE,aI,NI,NE,N_neuron_fire_first);
g = q0.*mid.*joint_density;

function joint_density = get_joint_density(fIt,fEt,fIr,fEr,bE,bI,aE,aI,NI,NE,N_neuron_fire_first)
val1 = max(0,(fEt-fEr)*fEr);
val2 = max(0,(fIt-fIr)*fIr);
val3 = 0.5*(NE-N_neuron_fire_first)*(bE*fEt - aE*fIr).^2;
val4 = 0.5*NI*(bI*fIt - aI*fIr).^2;
val = sqrt((NE-N_neuron_fire_first)*NI);
if(val1*val2>0)
joint_density = val*0.5/pi*fEt*fIt/sqrt(val1*val2)*exp(-val3/val1) .* exp(-val4/val2);
else
    joint_density = 0*bE;
end

function mid = get_mid_part_integral(aE,aI,bE,bI,rIt,rEt,rIr,rEr,fIt,fEt,fIr,fEr,NI,NE,alpha,NESEE,N_neuron_fire_first,sqrtGamma);
%% Make a note that aE aI are numbers, but bE, and bI are vectors %%
%       lt = ll(rIt,rEt,NE,NI,alpha,N_neuron_fire_first);
      arhof = get_mid_part(aI-bI,aE-bE,rIt-rIr,rEt-rEr,fIt-fIr,fEt-fEr,alpha,NE,N_neuron_fire_first);
      vn_t = vn(rIt,rEt,alpha,NESEE,NE,N_neuron_fire_first,sqrtGamma);
      lt = sqrt(1.0+ vn_t^2/sqrtGamma^6);
      mid = lt*arhof/sqrtGamma - vn_t * lt;   
function q0 = Comput_q0(rI,rE,fI,fE,aI,aE,alpha,NE,NI,NESEE,N_neuron_fire_first,sqrtGamma)
%     lt = ll(rI,rE,NE,NI,alpha,N_neuron_fire_first);
    vn_t = vn(rI,rE,alpha,NESEE,NE,N_neuron_fire_first,sqrtGamma);
    arhof =  get_mid_part(aI,aE,rI,rE,fI,fE,alpha,NE,N_neuron_fire_first);
    lt = sqrt(1.0+ vn_t^2/sqrtGamma^6);
    q0 =  -lt*arhof/sqrtGamma + vn_t * lt;


function arhof = get_mid_part(aI,aE,rI,rE,fI,fE,alpha,NE,N_neuron_fire_first)
  arhof = alpha*rI/fI*aI - rE/fE*aE*(NE-N_neuron_fire_first)/NE; 

function out = vn(rI,rE,alpha,NESEE,NE,N_neuron_fire_first,sqrtGamma)
out = sqrtGamma*(alpha*rI - rE*(NE-N_neuron_fire_first)/NE + NESEE);

function out = ll(rI,rE,NE,NI,alpha,N_neuron_fire_first)
nnE2 = ((NE-N_neuron_fire_first)/NE)^2;
val = NI*rE*nnE2 + alpha^2* rI * (NE-N_neuron_fire_first);
val1 = alpha^2 * rE * NI + (NE-N_neuron_fire_first)*rI*nnE2;
if(val*val1>0)
out = sqrt((nnE2+alpha^2)*abs(rE.*rI*(NE-N_neuron_fire_first)*NI)./val./val1);
else
    out = 0;
end
