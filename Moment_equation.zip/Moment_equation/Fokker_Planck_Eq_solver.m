%% Support the paper: High-order BCs for Schrodinger Eq
format short;
%--------------------------------------%
% first we define the a_k and b_k      %
%--------------------------------------%
supt=200;
M=1000;nx=500;
xStart = -1; xEnd = - xStart; 
xlength= xEnd - xStart;
dx=xlength/nx;
x=xStart:dx:xEnd;
J_source_ind = nx/2+1;
xbin = (x(1:end-1)+x(2:end))/2;

% figure;
dt=supt/M;
t=0:dt:supt;
size(x)
NI=nx+1; LI=1;
A=speye(NI);  %% three extra imtermediate points
B = A;
right=zeros(NI,1);
s=right;

%% this is the code for Jin Shi and Hao Wu and Xu Yang's 2008 CMS paper Example 1.
A0 = exp(-5000*(x).^2); 
u0=A0/(sum(A0));
source = u0;
u1 = u0;
u=u0;
%%%%%%%%%%%%%%%%%%
%coeM is the coefficients of Stiff Matrix
%%%%%%%%%%%%%%%%%%
mE = 0; NE = 128; mEY = 0.55; DEY = 0.018; DEE = 0.000;
gL = 0.05; VE = 14/3; VI = -2/3; VR =0; VL =0;
s1 = exp(DEE) -1; s3 = exp(DEY) -1;

coeM = zeros(3,1);
coeBR = zeros(3,1);
coeBL = zeros(3,1);

for nt=2:M+1
    if mod(nt,20)==1
        t(nt-1)
    end


for j=LI+1:NI-1
    
 gT = gL + mEY*s3*(1-s3^2) + NE*mE*s1*(1-s1^2);
 mu = (gL*VL + mEY*s3*(1-s3^2)*VE + NE*mE*s1*(1-s1^2)*VE)/gT;
 gamma = (mEY*s3^3 + NE*mE*s1^3)/gT;                           
 sigma =  (mEY*s3^2*(1+s3)*(xbin-VE).^2 + NE*mE*s1^2*(1+s1)*(xbin-VE).^2)/gT;
 sigmaprime =  2*(mEY*s3^2*(1+s3)*(xbin-VE) + NE*mE*s1^2*(1+s1)*(xbin-VE))/gT;
        
coeM(1) =  0.25*gT*dt*(xbin(j-1) -mu )/dx - 0.25*sigma(j-1)*dt*gT/dx^2 ;
coeM(3) =  - 0.25*(x(j) - mu)*dt*gT/dx - 0.25*sigma(j)*dt*gT/dx^2;
coeM(2) =  0.25*(xbin(j-1) - mu)*dt*gT/dx - 0.25*(xbin(j) - mu)*dt*gT/dx ...
    + 0.25*gT*sigma(j-1)*dt/dx^2 + 0.25*gT*sigma(j)*dt/dx^2;
%%%%%%%%%%%%%%%%%%        
        A(j,j-1)= coeM(1);
        A(j,j)  =1 + coeM(2) - dt*0.5*gT*gamma;
        A(j,j+1)= coeM(3);
        
        B(j,j-1)= - coeM(1);
        B(j,j)  =  1 - coeM(2)+ dt*gT*0.5*gamma;
        B(j,j+1)= - coeM(3);
end

    A(NI,NI)   = 1;  
    A(LI,LI)   = 1;   %-i*0.5/dx;
    
    B(NI,NI)   = 0;
    B(LI,LI)   = 0;   %-i*0.5/dx;
    
    s = u0';
    

    right = B*s;
    right(J_source_ind) = right(J_source_ind) + mE/dx;
    s=A\right;
    for j=LI:NI
        u1(j)=s(j);
    end

 mE = max(0,dt*gT*sigma(NI-1)*u1(NI-1)/dx/2);

    u0=u1;
plot(x,u0); drawnow; 
end

% %    filename = ['Num_ABC_Eps2_',num2str(iveps),'time',num2str(supt),'M_',num2str(M),'N_',num2str(N),'_nx_',num2str(nx),'k0_',num2str(k0),'xlength_',num2str(xlength),'.txt'];
% %                 fid1 = fopen(filename, 'wt');
% %                 for ii = 1:length(u0)
% %                     fprintf(fid1,'%16.15e    %16.15e    %16.15e\n', x(ii), real(u0(ii)), imag(u0(ii)));
% %                 end
% %                 fclose(fid1);

%                 plot(x(1:8:end),abs(u0(1:8:end)),'o');hold on;
