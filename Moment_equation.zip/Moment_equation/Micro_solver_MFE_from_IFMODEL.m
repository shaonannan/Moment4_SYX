function [LE, LI, ll_target, sp_order,E_fired,I_fired,VE_pre,VI_pre,VE_pos,VI_pos] = ...
    Micro_solver_MFE_from_IFMODEL(V_PN,V_LN,S_EE,S_IE,S_EI,S_II,VEX,VIN);

L_VPN = length(V_PN);
L_VLN = length(V_LN);

a = 1; while(a);aa = sort(ceil(L_VPN*rand(1,1))); a = find(aa<=0);end
V_PN(aa) = 1.2;

VE = V_PN; VI = V_LN;
[VE,VEj] = sort(VE); [VI,VIj] = sort(VI); [VEjs,VEr] = sort(VEj); [VIjs,VIr] = sort(VIj); 
% VE(end) =1.2;
%% here we assume that at least 4 neurons fire  %% neron index, voltage, gE,gI,spike_tage,type (0 ln, 1 pn), micro_time %%
PN = zeros(L_VPN,7); PN(:,2) = VE; 
LN = zeros(L_VLN,7); LN(:,2) = VI;
[LE, LI, ll_target,sp_order,VE_pos,VI_pos] = ...
    neuronarrayevolve_microtime(LN,PN, S_EE, S_IE, S_EI, S_II,VEX,VIN);

VE_pre = [VE_pos,ones(1,LE)]; VI_pre = [VI_pos,ones(1,LI)];
VE_pos = [VE_pos,zeros(1,LE)]; VI_pos = [VI_pos,zeros(1,LI)];

VE_pre = VE_pre(VEr); VI_pre = VI_pre(VIr);
VE_pos = VE_pos(VEr); VI_pos = VI_pos(VIr);
E_fired = VEj(length(VE)-LE+1:length(VE));
I_fired = VIj(length(VI)-LI+1:length(VI));


end