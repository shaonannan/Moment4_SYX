function f = density_volt_dep_100213();
format long;
NE = 128; NI = 128;
DEE = 0.1/NE; DIE = 0.1/NE; DEI = 0.1/NI; DII  = 0.1/NI;
mEY = 0.55; mIY = 0.54; DEY = 0.018; DIY = 0.018; 
mE = 0.1; mI = 0.1; gL = 0.05; vE = 14/3; vI = -2/3; vL =0; vT =1.0; vR =0;
nbinp = 20000;
v = linspace(-vT,vT,nbinp);
mY = [mIY, mEY]; N = [NI,NE]; D = [DII,DIE,DIY;DEI,DEE,DEY];
TD = Tanslate_S_to_s(D);
[gTI,gTE] = get_gT(N,mY,TD,mE,mI,gL);

[muI,muE] = get_mu(N,mY,TD,mE,mI,vE,vI,gTE,gTI,gL,vL);
[abcI,abcE] = get_coeff_sigma(N,mY,TD,mE,mI,vE,vI,gTE,gTI);

%  figure(1);hold on; plot(v,abcI(1)*v.^2 + abcI(2)*v + abcI(3),'o')
%  return;

[gammaI,gammaE] = get_gamma(N,mY,TD,mE,mI,gTE,gTI);
tic
[rhoE,rhoI] = get_density(v,abcE,abcI,muE,muI,vR,vT,gammaI,gammaE);
toc% plot(v,rhoE)

% function [rhoE,rhoI] = get_density(v,abcE,abcI,muE,muI,vR,vT)
function [rhoE,rhoI] = get_density(v,abcE,abcI,muE,muI,vR,vT,gammaI,gammaE)
aE = abcE(1);bE = abcE(2); cE = abcE(3);
aI = abcI(1);bI = abcI(2); cI = abcI(3);

coe = 0;
aEver = 1/aE;  coe1 = (2*bE)/aE +4*muE;
aIver = 1/aI; coeI1 = (2*bI)/aI + 4*muI;
VE = 14/3;
% plot(v, power((aE*v.^2+bE*v+cE)/(aE*v(1).^2+bE*v(1)+cE),aEver));
%  plot(v, power((aE*v.^2+bE*v+cE)/(aE*v(1).^2+bE*v(1)+cE),aEver).*exp(coe1./(2*aE*v+bE) - coe1./(2*aE*v(1) +bE))./(aE*v.^2+bE*v+cE) );
% ylabel('\alpha arctan(\beta (v))'); xlabel('v');

% pause();

ind = find(v<vR); 
J0= ind(end);

rhoE = v*0; rhoI = rhoE;

% % % % % % % % % % % for jj = J0:length(v)
% % % % % % % % % % % rhoE(jj) = quad(@(x)sfn(x,coe1,coe,aE,bE,cE,aEver,v(jj)),v(jj),vT);
% % % % % % % % % % % end
% % % % % % % % % % % 
% % % % % % % % % % % 
% % % % % % % % % % % 
% % % % % % % % % % % for jj = 1:J0-1
% % % % % % % % % % % rhoE(jj) = quad(@(x)sfn(x,coe1,coe,aE,bE,cE,aEver,v(jj)),v(J0-1),vT);
% % % % % % % % % % % end
% % % % % % % % % % % % val = quad(@(x)sfn(x,coe1,coe,aE,bE,cE,aEver,v(J0-1)),v(J0-1),vT);
% % % % % % % % % % % % rhoE(1:J0-1) = val;
% % % % % % % % % % % 
% % % % % % % % % % % 
% % % % % % % % % % % rhoE = rhoE/(sum(rhoE));
% % % % % % % % % % % 
% % % % % % % % % % % figure(5); hold on; plot(v,rhoE,'r','linewidth',2)
% % % % % % % % % % % rhoI = rhoE;

K = 20; a =0; c =1;
 [L,l] = mateleg(K);L=L(1:K,1:K);
 Lv = makeleg(K);Lv=Lv(1:K,2:K+1);
 [lv,ln] = legintmat(K,a,c);
 

for jj=1:length(ln)
    %         fvals(index)=feval(@f,ln(index));
%         fvals(jj) = quad(@(x)sfn(x,coe1,coe,aE,bE,cE,aEver,ln(jj)),ln(jj),vT);
         fvals(jj) = quad(@(x)sfn(x,coe1,coe,aE,bE,cE,aEver,ln(jj),gammaE),ln(jj),vT);
    end;
    
    coefs = inv(transpose(L))*(fvals(:));
    p = (Lv'*coefs(:))';
%     pvals=polyval(p,(xvals-(c+a)/2)/((c-a)/2));
pvals01=polyval(p,(v(J0:end)-(v(J0)+v(end))/2)/((v(end)-v(J0))/2));

K = 20; a =-1; c =0;
 [L,l] = mateleg(K);L=L(1:K,1:K);
 Lv = makeleg(K);Lv=Lv(1:K,2:K+1);
 [lv,ln] = legintmat(K,a,c);
 

for jj=1:length(ln)
    %         fvals(index)=feval(@f,ln(index));
        fvals(jj) = quad(@(x)sfn(x,coe1,coe,aE,bE,cE,aEver,ln(jj),gammaE),vR,vT);
    end;
    
    coefs = inv(transpose(L))*(fvals(:));
    p = (Lv'*coefs(:))';
%     pvals=polyval(p,(xvals-(c+a)/2)/((c-a)/2));
pvals00=polyval(p,(v(1:J0-1)-(v(1)+v(J0-1))/2)/((v(J0-1)-v(1))/2));
pvals = [pvals00,pvals01];


%     for index=1:length(xvals);
%         yvals(index)=feval(@f,xvals(index));
%     end;
pvals = pvals/sum(pvals);
%     figure(1);clf;hold on;
    figure(1);hold on;
%     plot(xvals,yvals,'r-');
% plot(v,rhoE,'r','linewidth',2)
%     plot(xvals,pvals,'b-');
plot(v,pvals,'g-');
    
%     plot(ln,fvals,'bx');
%     plot(ln,0,'bx');
    xlabel('x');
    ylabel('function value');
    title('function in red, polynomial in blue, nodes at *');
    hold off;
    disp('the calculated integral of your function is');
    transpose(lv(:)) * fvals(:), 

rhoE = pvals; rhoI = rhoE;
function [gammaI,gammaE] = get_gamma(N,mY,D,mE,mI,gTE,gTI)
%%%% D = [DII,DIE,DIY;DEI,DEE,DEY];
NI = N(1); NE = N(2);
mIY = mY(1); mEY = mY(2);
DII = D(1,1); DIE = D(1,2); DIY = D(1,3); DEI = D(2,1); DEE = D(2,2); DEY = D(2,3);

gammaI = (mIY*DIY^3 + NE*mE*DIE^3 + NI*mI*DII^3)/gTI;
gammaE =  (mEY*DEY^3 + NE*mE*DEE^3 + NI*mI*DEI^3)/gTE;                           

% function val = sfn(v,coe1,coe,aE,bE,cE,aEver,v0);
% if coe < 10^(-6)
% val = power((aE*v.^2+bE*v+cE)/(aE*v0^2+bE*v0+cE),aEver) .* exp(-coe1./(2.0*aE*v0+bE) + coe1./((2*aE*v + bE))) ./(aE*v.^2+bE*v+cE);
% else
% val = power(aE*v.^2+bE*v+cE,aEver-1).*exp(-coe1*atan((2*aE*v + bE)/coe));
% end

function val = sfn(v,coe1,coe,aE,bE,cE,aEver,v0,gamma);
% if coe < 10^(-10)
val = exp(gamma*(1-v)).*power((aE*v.^2+bE*v+cE)/(aE*v0^2+bE*v0+cE),aEver) .* exp(-coe1./(2.0*aE*v0+bE) + coe1./((2*aE*v + bE))) ./(aE*v.^2+bE*v+cE);
% else
% val = exp(gamma*(1-v)).*power((aE*v.^2+bE*v+cE)/(aE*v0^2+bE*v0+cE),aEver) .* exp(-coe1*atan((2*aE*v + bE)/coe) + coe1*atan((2*aE*v0 + bE)/coe))./(aE*v.^2+bE*v+cE);
% end


function [muI,muE] = get_mu(N,mY,TD,mE,mI,vE,vI,gTE,gTI,gL,vL)
%%%% D = [DII,DIE,DIY;DEI,DEE,DEY];
muI = gL*vL + mY(1)*TD(1,3)*(1.0 - TD(1,3)^2)*vE + mE*N(2)*TD(1,2)*(1.0 - TD(1,2)^2)*vE + mI*N(1)*TD(1,1)*(1.0 - TD(1,1)^2)*vI;
muE = gL*vL + mY(2)*TD(2,3)*(1.0 - TD(2,3)^2)*vE + mE*N(2)*TD(2,2)*(1.0-TD(2,2)^2)*vE + mI*N(1)*TD(2,1)*(1.0-TD(2,1)^2)*vI;
muI = muI/gTI; muE = muE/gTE;

function [gTI,gTE] = get_gT(N,mY,TD,mE,mI,gL)
%%%% D = [DII,DIE,DIY;DEI,DEE,DEY];

gTI = gL + mY(1)*TD(1,3)*(1.0-TD(1,3)^2) + mE*N(2)*TD(1,2)*(1.0-TD(1,2)^2) + mI*N(1)*TD(1,1)*(1.0-TD(1,1)^2);
gTE = gL + mY(2)*TD(2,3)*(1.0-TD(2,3)^2) + mE*N(2)*TD(2,2)*(1.0-TD(2,2)^2) + mI*N(1)*TD(2,1)*(1.0-TD(2,1)^2);

function [abcI,abcE] = get_coeff_sigma(N,mY,TD,mE,mI,vE,vI,gTE,gTI)
%%%% D = [DII,DIE,DIY;DEI,DEE,DEY];
aI = mY(1)*TD(1,3)^2*(1.0 + TD(1,3)) + mE*N(2)*TD(1,2)^2 *(1.0 + TD(1,2)) + mI*N(1)*TD(1,1)^2*(1.0 + TD(1,1));
bI = -2.0*mY(1)*TD(1,3)^2*(1.0+TD(1,3))*vE - 2.0*mE*N(2)*TD(1,2)^2*(1.0+TD(1,2))*vE - 2.0*mI*N(1)*TD(1,1)^2*(1.0+TD(1,1))*vI;
cI =  mY(1)*TD(1,3)^2*(1.0+TD(1,3))*vE^2 + mE*N(2)*TD(1,2)^2*(1.0+TD(1,2))*vE^2 + mI*N(1)*TD(1,1)^2*(1.0+TD(1,1))*vI^2;
abcI = [aI,bI,cI]/gTI;

aE = mY(2)*TD(2,3)^2*(1.0+TD(2,3)) + mE*N(2)*TD(2,2)*TD(2,2)*(1.0+TD(2,2)) + mI*N(1)*TD(2,1)^2*(1.0+TD(2,1));
bE = -2.0*mY(2)*TD(2,3)^2*(1.0+TD(2,3))*vE - 2.0*mE*N(2)*TD(2,2)^2*(1.0+TD(2,2))*vE - 2.0*mI*N(1)*TD(2,1)^2*(1.0+TD(2,1))*vI;
cE =  mY(2)*TD(2,3)^2*(1.0+TD(2,3))*vE^2 + mE*N(2)*TD(2,2)^2*(1.0+TD(2,2))*vE^2 + mI*N(1)*TD(2,1)^2*(1.0+TD(2,1))*vI^2;
abcE = [aE,bE,cE]/gTE;


function D1 = Tanslate_S_to_s(D);
%%%% D = [DII,DIE,DIY;DEI,DEE,DEY];
D = abs(D);
D1 = [exp(D(1,1))-1,exp(D(1,2))-1,exp(D(1,3))-1;exp(D(2,1))-1,exp(D(2,2))-1,exp(D(2,3))-1];



function Legpoly_vec = makeleg(K);
	% This function generates a matrix Legpoly_vec
	% such that Legpoly_vec(k,:) is the coefficients of the kth legendre polynomial
	% Warning: the coefficients are listed in "polynomial order" for use in matlab poly class
	
	L{1}=[1];
	L{2}=[1 0];
	for index=1:K-1
        L{index+2} = ((2*index+1)*conv([1 0],L{index+1}) - index*[0 0 L{index}])/(index+1);
	end;
	Legpoly_vec=zeros(K+1);
	for index=1:K+1
        Legpoly_vec(index,:)=[zeros(1,K+1-index) L{index}];
	end;

function [L,l] = mateleg(K)
	
	% L = matrix whose components L(j,k) are jth Legendre polynomial evaluated at kth legendre node
	% l = vector of legendre nodes
	
	Legpoly_vec = makeleg(K);
	l=roots(Legpoly_vec(K+1,:));l=sort(transpose(l(:)));
	for index1=1:K
        for index2=1:K
            L(index1,index2) = polyval(Legpoly_vec(index1,:),l(index2));
        end;
	end;

function [leg_vector,leg_nodes] = legintmat(K,a,c)

	% This function calculates the weights (leg_vector) and nodes (leg_nodes)
	% for legendre integration of degree K on interval [a,c]
	
	Legpoly_vec = makeleg(K);
	Legpoly_int = zeros(1,K);
	for index=1:K
        tempoly = polyint(Legpoly_vec(index,:));
        Legpoly_int(index) = polyval(tempoly,1)-polyval(tempoly,-1);
	end;
	[L,l]=mateleg(K);
	L_inv = L\eye(K);
	leg_vector = ((c-a)/2) * Legpoly_int*transpose(L_inv);
	leg_nodes = l*(c-a)/2 + (c+a)/2;

function [T,t] = matetsch(K)

	% K = number of tschebyscheff polynomials to construct
	% T = matrix of values T(i,j) = Ti(tj)
	% where Ti = ith tschebyscheff polynomial,
	% tj = jth root of TK
	
	t=cos((2*K-2*[1:K]+1)*pi/(2*K));
	T(1,:)=linspace(1,1,length(t));
	T(2,:)=t;
	for j1=2:K
      for j2=1:length(t)
        T(j1+1,j2)=2*t(j2)*T(j1,j2)-T(j1-1,j2);
      end;
	end;

function Tschpoly_vec = maketsch(K);
	% this function produces a matrix such that
	% Tschpoly_vec(k,:) = coefficients of the kth tschebyscheff polynomial
	% Warning: The coefficients are listed in "polynomial order" for use as matlab poly class
	
	Tschpoly{1}=[1];
	Tschpoly{2}=[1 0];
	for index=1:K+1-2
        Tschpoly{index+2} = conv([2 0],Tschpoly{index+1}) - [0 0 Tschpoly{index}];
	end;
	Tschpoly_vec=zeros(K+1);
	for index=1:K+1
        Tschpoly_vec(index,K+1-index+1:K+1)=Tschpoly{index};
	end;

function [tsch_vector,tsch_nodes] = tschintmat(K,a,c)

	% This function establishes the tschebysheff nodes of integration as well as the corresponding integration vector 
	% for degree K tschebysheff interpolation/integration on the interval [a,c]
	
	tsch_nodes=cos((2*K-2*[1:K]+1)*pi/(2*K));
	T(1,:)=linspace(1,1,K);
	T(2,:)=tsch_nodes;
	for j1=2:K-1
      for j2=1:K
        T(j1+1,j2)=2*tsch_nodes(j2)*T(j1,j2)-T(j1-1,j2);
      end;
	end;
	T_int = ~isint((1:K)./2)./((1:K).*((1:K)-2));T_int(2)=0;
	T_eye=2*eye(K); T_eye(1,1)=1;
	tsch_vector = ((a-c)/K)*T_int*T_eye*T;
	tsch_nodes = (c-a)/2 * tsch_nodes + (c+a)/2;
    
    
function output = polyint(input)
	
	% this function finds the indefinite integral of a polynomial
	
        input=transpose(input(:));
	for index=1:length(input);
        output(index) = input(index)/(length(input)-index+1);
	end;
	output = [output 0];
    
function output = isint(input)
    
    % this is just a lame function that tests whether or not the input is an integer
    
	output = floor(input)==input;

function output = f(x);

    % This can be whatever you want it to be...
    
    alpha = 1/10; sigma = 2;
    output = 1/(x^2 + alpha); 
%     output = 1/(x^2 + alpha) + sin(2*pi*x) + cos(4*pi*x)*(1/sqrt(2*pi)/sigma)*exp(-(x)^2/(2*sigma.^2));
    % output = atan(x);
