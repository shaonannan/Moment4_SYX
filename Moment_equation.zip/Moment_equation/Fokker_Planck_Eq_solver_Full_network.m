format long;

figure;
supt=150;
M=3000;nx=500;
xStart = -1; xEnd = - xStart; 
xlength= xEnd - xStart;
dx=xlength/nx;
x=xStart:dx:xEnd;
J_source_ind = nx/2+1;
xbin = (x(1:end-1)+x(2:end))/2;

% figure;
dt=supt/M;
t=0:dt:supt;
NIMM=nx+1; LI=1;
A=speye(NIMM);  %% three extra imtermediate points
B = A;
right=zeros(NIMM,1);
s=right;

%% this is the code for Jin Shi and Hao Wu and Xu Yang's 2008 CMS paper Example 1.
A0 = exp(-5000*(x-0.2).^2); 
u1=(A0')/(sum(A0));
source = u1;
uI1 = u1;

%%%%%%%%%%%%%%%%%%
%coeM is the coefficients of Stiff Matrix
%%%%%%%%%%%%%%%%%%
mE = 0; mI =0; NI = 128;  NE = 128;
mEY = 0.55; DEY = 0.018; DEE = 0.1/NE; DIE = 0.1/NE;
mIY = 0.54; DIY = 0.018; DII = 0.1/NI; DEI = 0.1/NI;
gL = 0.05; VE = 14/3; VI = -2/3; VR =0; VL =0;
DEE = exp(DEE) -1; DEY = exp(DEY) -1; DIE = exp(DIE) -1;
DII = exp(DII) -1; DIY = exp(DIY) -1; DEI = exp(DEI) -1;

coeM = zeros(3,1);
coeMI = zeros(3,1);





for nt=2:M+1
    if mod(nt,20)==1
        t(nt-1)
    end


for j=LI+1:NIMM-1
    
 gT = gL + mEY*DEY*(1-DEY^2) + NE*mE*DEE*(1-DEE^2) + NI*mI*DEI*(1-DEI^2);
 mu = (gL*VL + mEY*DEY*(1-DEY^2)*VE + NE*mE*DEE*(1-DEE^2)*VE + NI*mI*DEI*(1-DEI^2)*VI)/gT;
 gamma =  (mEY*DEY^3 + NE*mE*DEE^3 + NI*mI*DEI^3)/gT;                           
 sigma =  (mEY*DEY^2*(1+DEY)*(xbin-VE).^2 + NE*mE*DEE^2*(1+DEE)*(xbin-VE).^2+ NI*mI*DEI^2*(1+DEI)*(xbin-VI).^2)/gT;

     
 gTI = gL + mIY*DIY*(1-DIY^2) + NE*mE*DIE*(1-DIE^2) + NI*mI*DII*(1-DII^2) ;
 muI = (gL*VL + mIY*DIY*(1-DIY^2)*VE + NE*mE*DIE*(1-DIE^2)*VE + NI*mI*DII*(1-DII^2)*VI)/gTI;
 gammaI = (mIY*DIY^3 + NE*mE*DIE^3 + NI*mI*DII^3)/gTI;                           
 sigmaI =  (mIY*DIY^2*(1+DIY)*(xbin-VE).^2 + NE*mE*DIE^2*(1+DIE)*(xbin-VE).^2+ NI*mI*DII^2*(1+DII)*(xbin-VI).^2)/gTI;
 
 coeM(1) =  0.25*gT*dt*(xbin(j-1) -mu )/dx - 0.25*sigma(j-1)*dt*gT/dx^2 ;
coeM(3) =  - 0.25*(x(j) - mu)*dt*gT/dx - 0.25*sigma(j)*dt*gT/dx^2;
coeM(2) =  0.25*(xbin(j-1) - mu)*dt*gT/dx - 0.25*(xbin(j) - mu)*dt*gT/dx ...
    + 0.25*gT*sigma(j-1)*dt/dx^2 + 0.25*gT*sigma(j)*dt/dx^2;

coeMI(1) =  0.25*gTI*dt*(xbin(j-1) -muI )/dx - 0.25*sigmaI(j-1)*dt*gTI/dx^2 ;
coeMI(3) =  - 0.25*(x(j) - muI)*dt*gTI/dx - 0.25*sigmaI(j)*dt*gTI/dx^2;
coeMI(2) =  0.25*(xbin(j-1) - muI)*dt*gTI/dx - 0.25*(xbin(j) - muI)*dt*gTI/dx ...
    + 0.25*gTI*sigmaI(j-1)*dt/dx^2 + 0.25*gTI*sigmaI(j)*dt/dx^2;

%%%%%%%%%%%%%%%%%%  
        A(j,j-1)= coeM(1);
        A(j,j)  =1 + coeM(2) - 0.5*dt*gT*gamma;
        A(j,j+1)= coeM(3);
        
        B(j,j-1)= - coeM(1);
        B(j,j)  =  1 - coeM(2)+ 0.5*dt*gT*gamma;
        B(j,j+1)= - coeM(3);
        
        AI(j,j-1)= coeMI(1);
        AI(j,j)  =1 + coeMI(2) - 0.5*dt*gTI*gammaI;
        AI(j,j+1)= coeMI(3);
        
        BI(j,j-1)= - coeMI(1);
        BI(j,j)  =  1 - coeMI(2)+ 0.5*dt*gTI*gammaI;
        BI(j,j+1)= - coeMI(3);
end
    A(NIMM,NIMM)   = 1;  
    A(LI,LI)   = 1;   %-i*0.5/dx;
    
    B(NIMM,NIMM)   = 0;
    B(LI,LI)   = 0;   %-i*0.5/dx;
    

    AI(NIMM,NIMM)   = 1;  
    AI(LI,LI)   = 1;   %-i*0.5/dx;
    
    BI(NIMM,NIMM)   = 0;
    BI(LI,LI)   = 0;   %-i*0.5/dx;
    
    
    %%%%%%%%%%%%%%%%%%%% update E-population %%%%%%%%%%%%%%%%%%%%%
    s = u1;
    right = B*s;
    right(J_source_ind) =  right(J_source_ind) + mE/dx;
    s=A\right;
    u1=s;
 % mE = max(0,dt*gT*sigma(NIMM-1)*u1(NIMM-1)/dx/2);
mE =max(0, 0.5*gT*dt*(sigma(NIMM-1))*(4*u1(NIMM-1)-u1(NIMM-2))/dx/2);

    u1 = u1/sum(u1);
    %%%%%%%%%%%%%%%%%%%% update I-population %%%%%%%%%%%%%%%%%%%%%    
    sI = uI1;
    rightI = BI*sI;
    rightI(J_source_ind) =  rightI(J_source_ind) + mI/dx;
    sI=AI\rightI;
    uI1=sI;
 % mE = max(0,dt*gT*sigma(NIMM-1)*u1(NIMM-1)/dx/2);
mI =max(0, 0.5*gTI*dt*(sigmaI(NIMM-1))*(4*uI1(NIMM-1)-uI1(NIMM-2))/dx/2);

    uI1 = uI1/sum(uI1);    
    
plot(x,u1,'r',x,uI1,'b'); drawnow; 
end
