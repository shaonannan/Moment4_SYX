function [nbins,dV,Vedges,Vbins,t_ra,mE_ra,mI_ra,P_MFE_ra,rE_ra,rI_ra,Lt_ra,LE_ra,LI_ra,tbin_ra,mEbin_ra,mIbin_ra,xEbin_ra,xIbin_ra,P_MFEbin_ra,rEbin_ra,rIbin_ra,...
    VEavgbin_ra,VEstdbin_ra,VIavgbin_ra,VIstdbin_ra] = Jiwei_if_vol_dep_ver1(N,mY,D,TMAX,dt,VIN,VEX);
WIN_USE = 0;
if WIN_USE
    catalog_str = '\\';
else
    catalog_str = '/';
end
% conditioned to not produce mfes during fB, with MFEs added as required. ;
% run with: ;
%{
  [nbins,dV,Vedges,Vbins,t_ra,mE_ra,mI_ra,P_MFE_ra,rE_ra,rI_ra,Lt_ra,LE_ra,LI_ra,tbin_ra,mEbin_ra,mIbin_ra,xEbin_ra,xIbin_ra,P_MFEbin_ra,rEbin_ra,rIbin_ra,VEavgbin_ra,VEstdbin_ra,VIavgbin_ra,VIstdbin_ra] = Jiwei_if_vol_dep_ver1([24 32]*1,[1.8 2.4],[0.25 0.30 0.05 ; 0.55 0.50 0.05],1024,0.01, -2/3, 14/3);
%}

TAU_V=20;VT=1;VR=0; % VIN = -2/3; VEX = 14/3; 
if isempty(TMAX); TMAX = 1024; end;
if isempty(dt); dt = 0.01; end;

if isempty(N); N = [24 32]*1; end;
NI = N(1); NE = N(2);

if isempty(mY); mY = [1.8 2.4]; end;
mIY = mY(1); mEY = mY(2); NmIY = NI*mIY; NmEY = NE*mEY;

% DQR are coupling strengths from R to Q;
if isempty(D); D = [0.25 0.30 0.05 ; 0.55 0.50 0.05 ]; end;
DII = D(1,1); DIE = D(1,2); DIY = D(1,3); DEI = D(2,1); DEE = D(2,2); DEY = D(2,3);
% tagline = sprintf('N_%.3d_%.3d_mY_%.2d_%.2d_D_%.2d_%.2d_%.2d_%.2d_T%.3d_dt%.3d',NI,NE,round(10*mIY),round(10*mEY),round(100*DII),round(100*DIE),round(100*DEI),round(100*DEE),round(TMAX/1024),round(dt*1000));
% tagline = sprintf('N_%.3d_%.3d_mY_%.2d_%.2d_D_%.2d_%.2d_%.2d_%.2d_T%.3d_dt%.3d',NI,NE,round(1000*mIY),round(1000*mEY),round(1000*DII),round(1000*DIE),round(1000*DEI),round(1000*DEE),round(TMAX/1024),round(dt*1000));
tagline = sprintf('N_%.3d_%.3d_mY_%.2d_%.2d_D_%.2d_%.2d_%.2d_%.2d_T%.3d_dt%.3d_VE%.3d_VI%.3d',...
    NI,NE,round(10000*mIY),round(10000*mEY),round(10000*DII),round(10000*DIE),round(10000*DEI),round(10000*DEE),round(TMAX/1024),round(dt*1000),round(10000*VEX),round(10000*VIN));

%% Rescale the coupling strength
D(:,1:2) = inv(diag(N))*D(:,1:2);
DII = D(1,1); DIE = D(1,2); DIY = D(1,3); DEI = D(2,1); DEE = D(2,2); DEY = D(2,3);

filename_base = sprintf('if4_%s',tagline);

%VE = tanh(+0.5+0.65*randn(NE,1)); VE = (VE+1)/2;
%VI = tanh(+0.1+0.45*randn(NI,1)); VI = (VI+1)/2;
VE = zeros(NE,1);
VI = zeros(NI,1);

RE = -log(rand())/NmEY; REj = 1+min(NE-1,max(0,floor(NE*rand())));
RI = -log(rand())/NmIY; RIj = 1+min(NI-1,max(0,floor(NI*rand())));

nbins = 1025; nbinp = nbins+1; dV = (VT-(VR-VT))/nbins; Vedges = linspace(VR-VT,VT,nbinp); Vbins = (Vedges(1:end-1)+Vedges(2:end))/2;
j_source = (nbins+1)/2; rho_source = zeros(nbins,1); rho_source(j_source)=1; 


dtbin_record_flag=1; tbinsize = 1.0; 
t_sum=0; 
t_ra = [];
mE_ra = [];
mI_ra = [];
dtbin_ra = zeros(TMAX/tbinsize,1);
tbin_ra = zeros(TMAX/tbinsize,1);
mEbin_ra = zeros(TMAX/tbinsize,1);
mIbin_ra = zeros(TMAX/tbinsize,1);
rE_ra = [];
rI_ra = [];
P_MFE_ra = [];
Lt_ra = [];
LE_ra = [];
LI_ra = [];

rEbin_ra = [];
rIbin_ra = [];

if dtbin_record_flag;
dtbin_ra = zeros(TMAX/tbinsize,1);
tbin_ra = zeros(TMAX/tbinsize,1);
mEbin_ra = zeros(TMAX/tbinsize,1);
mIbin_ra = zeros(TMAX/tbinsize,1);
xEbin_ra = zeros(TMAX/tbinsize,1);
xIbin_ra = zeros(TMAX/tbinsize,1);
P_MFEbin_ra = zeros(TMAX/tbinsize,1);
rEbin_ra = zeros(nbins,TMAX/tbinsize+1);
rIbin_ra = zeros(nbins,TMAX/tbinsize+1);
VEavgbin_ra = zeros(TMAX/tbinsize,1);
VEstdbin_ra = zeros(TMAX/tbinsize,1);
VIavgbin_ra = zeros(TMAX/tbinsize,1);
VIstdbin_ra = zeros(TMAX/tbinsize,1);
else;%if dtbin_record_flag;
dtbin_ra = [];
tbin_ra = [];
mEbin_ra = [];
mIbin_ra = [];
xEbin_ra = [];
xIbin_ra = [];
P_MFEbin_ra = [];
rEbin_ra = [];
rIbin_ra = [];
VEavgbin_ra = []; 
VEstdbin_ra = [];
VIavgbin_ra = [];
VIstdbin_ra = [];
end;%;%if dtbin_record_flag;


verbose=0;
dtmax=0.75; edt = exp(-dtmax/TAU_V);

plot_flag=0;
% if plot_flag; figure; hold on; end;
iteration=1; t_sum=0; dt_cur=0; T_rem=TMAX; dtbin_ij=1; dt_rem=tbinsize;
% var_fn = ['MFE_',filename_base,'.txt'];
% fid = fopen(var_fn, 'wt');
while (t_sum<TMAX);
    t_sum
if (T_rem<=RI & T_rem<=RE & T_rem<=dtmax);
  dt_cur = T_rem; RE = RE-T_rem; RI = RI-T_rem; t_sum=t_sum+dt_cur; T_rem = TMAX-dt_cur; 
  dt_rem = dt_rem-dt_cur; if dt_rem<0; dt_rem = dt_rem+tbinsize; dtbin_ij = dtbin_ij+1; end;%if dt_rem<0;
  VE = VE*edt; VI = VI*edt;
  Jiwei_if_ver4_helper;
elseif (dtmax<RI & dtmax<RE & dtmax<T_rem);
  dtmax = min(TMAX-t_sum,dtmax);
  dt_cur = dtmax; RE = RE-dtmax; RI = RI-dtmax;t_sum=t_sum+dt_cur; T_rem = TMAX-dt_cur;
  dt_rem = dt_rem-dt_cur; if dt_rem<0; dt_rem = dt_rem+tbinsize; dtbin_ij = dtbin_ij+1; end;%if dt_rem<0;
  VE = VE*edt; VI = VI*edt;
  Jiwei_if_ver4_helper;
elseif (RI<RE & RI<dtmax & RI<T_rem);
  if (verbose); disp(sprintf('ij %d, RI<RE; dtmax %f RI %f RE %f',iteration,dtmax,RI,RE)); end;
  dt_cur = RI; RE = RE-RI;t_sum=t_sum+dt_cur; T_rem = TMAX-dt_cur;
  dt_rem = dt_rem-dt_cur; if dt_rem<0; dt_rem = dt_rem+tbinsize; dtbin_ij = dtbin_ij+1; end;%if dt_rem<0;
  VE = VE*exp(-RI/TAU_V); VI = VI*exp(-RI/TAU_V);
  Jiwei_if_ver4_helper;
%   VI(RIj) = VI(RIj) + DIY;
  VI(RIj) = VEX + (VI(RIj) -VEX)*exp(-DIY);
  if (VI(RIj)>=VT);
%     [E_fired,I_fired,VEpos,VIpos] = getMFE_ifdyn(0,VE,VI,D); 
  [E_fired,I_fired,VE_pre,VI_pre,VE_pos,VI_pos] = Micro_solver_MFE_from_IFMODEL(VE,VI,DEE,DIE,DEI,DII,VEX,VIN);
%                 fprintf(fid,'%16.4e    %16.0e     %16.0e\n', t_sum,length(E_fired),length(I_fired));
    if plot_flag & length(E_fired); subplot(2,1,1); hold on; plot(t_sum,E_fired,'r.'); drawnow;end; if plot_flag & length(I_fired); subplot(2,1,2); hold on; plot(t_sum,I_fired,'b.'); drawnow; end; 
%     if plot_flag & length(E_fired); figure(1); hold on; subplot(3,1,1); hold on; plot(t_sum,E_fired,'r.'); end; %if plot_flag & length(I_fired); subplot(2,1,2); hold on; plot(t_sum,I_fired,'b.'); end; 
    Lt_cur = t_sum; LE_cur = length(E_fired); LI_cur = length(I_fired); VE=VE_pre; VI = VI_pre;
    iteration=iteration+1; dt_cur=0;t_sum=t_sum+dt_cur; T_rem = TMAX-dt_cur;
    dt_rem = dt_rem-dt_cur; if dt_rem<0; dt_rem = dt_rem+tbinsize; dtbin_ij = dtbin_ij+1; end;%if dt_rem<0;
    Jiwei_if_ver4_helper;
    LE_cur = 0; LI_cur = 0; VE = VE_pos; VI = VI_pos;
  end;%if (VE(REj)>=VT);
  RI = -log(rand())/NmIY; RIj = 1+min(NI-1,max(0,floor(NI*rand())));
elseif (RE<RI & RE<dtmax & RE<T_rem);
  if (verbose); disp(sprintf('ij %d, RE<RI; dtmax %f RI %f RE %f',iteration,dtmax,RI,RE)); end;
  dt_cur = RE; RI = RI-RE;t_sum=t_sum+dt_cur; T_rem = TMAX-dt_cur;
  dt_rem = dt_rem-dt_cur; if dt_rem<0; dt_rem = dt_rem+tbinsize; dtbin_ij = dtbin_ij+1; end;%if dt_rem<0;
  VE = VE*exp(-RE/TAU_V); VI = VI*exp(-RE/TAU_V);
  Jiwei_if_ver4_helper;
%   VE(REj) = VE(REj) + DEY;
 VE(REj) = VEX + (VE(REj) - VEX)*exp(-DEY);
  if (VE(REj)>=VT);
%     [E_fired,I_fired,VEpos,VIpos] = getMFE_ifdyn(0,VE,VI,D);
%     [LE, LI, ll_target, sp_order] = Micro_solver_MFE_from_IFMODEL(VE,VI,DEE,DIE,DEI,DII);
    [E_fired,I_fired,VE_pre,VI_pre,VE_pos,VI_pos] = Micro_solver_MFE_from_IFMODEL(VE,VI,DEE,DIE,DEI,DII,VEX,VIN);
%                     fprintf(fid,'%16.4e    %16.0e     %16.0e\n', t_sum,length(E_fired),length(I_fired));
    if plot_flag & length(E_fired); subplot(2,1,1); hold on; plot(t_sum,E_fired,'r.'); drawnow; end; if plot_flag & length(I_fired); subplot(2,1,2); hold on; plot(t_sum,I_fired,'b.'); drawnow;end;
% if plot_flag & length(E_fired); figure(1); hold on; subplot(3,1,1); hold on; plot(t_sum,E_fired,'r.'); end; %if plot_flag & length(I_fired); subplot(2,1,2); hold on; plot(t_sum,I_fired,'b.'); end; 
    Lt_cur = t_sum; LE_cur = length(E_fired); LI_cur = length(I_fired); VE=VE_pre; VI=VI_pre;
    iteration=iteration+1; dt_cur=0;t_sum=t_sum+dt_cur; T_rem = TMAX-dt_cur;
    dt_rem = dt_rem-dt_cur; if dt_rem<0; dt_rem = dt_rem+tbinsize; dtbin_ij = dtbin_ij+1; end;%if dt_rem<0;
    Jiwei_if_ver4_helper;
    LE_cur = 0; LI_cur = 0;  VE = VE_pos; VI = VI_pos;
  end;%if (VE(REj)>=VT);
  RE = -log(rand())/NmEY; REj = 1+min(NE-1,max(0,floor(NE*rand())));
elseif (RI==RE & RI<dtmax & RI<T_rem);
  if (verbose); disp(sprintf('ij %d, RE==RI; dtmax %f RI %f RE %f',iteration,dtmax,RI,RE)); end;
  dt_cur = RI;t_sum=t_sum+dt_cur; T_rem = TMAX-dt_cur;
  dt_rem = dt_rem-dt_cur; if dt_rem<0; dt_rem = dt_rem+tbinsize; dtbin_ij = dtbin_ij+1; end;%if dt_rem<0;
  VE = VE*exp(-RI/TAU_V); VI = VI*exp(-RI/TAU_V);
  Jiwei_if_ver4_helper;
%   VI(RIj) = VI(RIj) + DIY;
%   VE(REj) = VE(REj) + DEY;
VE(REj) = VEX + (VE(REj) - VEX)*exp(-DEY);
VI(RIj) = VEX + (VI(RIj) -VEX)*exp(-DIY);
  if (VI(RIj)>=VT | VE(REj)>=VT);
%     [E_fired,I_fired,VEpos,VIpos] = getMFE_ifdyn(0,VE,VI,D); 
  [E_fired,I_fired,VE_pre,VI_pre,VE_pos,VI_pos] = Micro_solver_MFE_from_IFMODEL(VE,VI,DEE,DIE,DEI,DII,VEX,VIN);
%                 fprintf(fid,'%16.4e    %16.0e     %16.0e\n', t_sum,length(E_fired),length(I_fired));
    if plot_flag & length(E_fired); subplot(2,1,1); hold on; plot(t_sum,E_fired,'r.'); end; if plot_flag & length(I_fired); subplot(2,1,2); drawnow;hold on; plot(t_sum,I_fired,'b.'); drawnow;end;
if plot_flag & length(E_fired); figure(1); hold on; subplot(3,1,1); hold on; plot(t_sum,E_fired,'r.'); end; %if plot_flag & length(I_fired); subplot(2,1,2); hold on; plot(t_sum,I_fired,'b.'); end; 
    Lt_cur = t_sum; LE_cur = length(E_fired); LI_cur = length(I_fired);VE= VE_pre; VI=VI_pre;
    iteration=iteration+1; dt_cur=0;t_sum=t_sum+dt_cur; T_rem = TMAX-dt_cur;
    dt_rem = dt_rem-dt_cur; if dt_rem<0; dt_rem = dt_rem+tbinsize; dtbin_ij = dtbin_ij+1; end;%if dt_rem<0;
    Jiwei_if_ver4_helper;
   LE_cur = 0; LI_cur = 0;  VE = VE_pos; VI = VI_pos;
  end;%if (VE(REj)>=VT);
  RI = -log(rand())/NmIY; RIj = 1+min(NI-1,max(0,floor(NI*rand())));
  RE = -log(rand())/NmEY; REj = 1+min(NE-1,max(0,floor(NE*rand())));
end;%if; %choose dt;

iteration=iteration+1;
end;%while (t_sum<TMAX);
% fclose(fid);
% if plot_flag; figure(1); hold on; subplot(3,1,1); xlim([0 t_sum]); ylim([0,NE+1]); axis off; hold off; end;
% if plot_flag; subplot(2,1,2); xlim([0 t_sum]); ylim([0,NI+1]); hold off; end;
%if plot_flag; print('-depsc',sprintf('%s_FIG_A.eps',filename_base)); end;

tbin_ra = cumsum(dtbin_ra);
mEbin_ra = xEbin_ra; mIbin_ra = xIbin_ra;
nsec_to_plot=1.0;
plot_flag=1;

if plot_flag & dtbin_record_flag;
figure;    
% figure;
tij=max(1,(TMAX-1024*nsec_to_plot)/tbinsize):TMAX/tbinsize;
[rtmp,ctmp] = size(rEbin_ra); j_source = (rtmp+1)/2;
subplot(5,1,1);imagesc(rEbin_ra(end:-1:j_source,tij)*sparse(1:length(tij),1:length(tij),1./sum(rEbin_ra(end:-1:j_source,tij),1)),[0 4/1024]); ylabel('VE');
set(gca,'YTick',[1 j_source]);set(gca,'YTickLabel',{'VT','VR'});
[rtmp,ctmp] = size(rIbin_ra); j_source = (rtmp+1)/2;
subplot(5,1,2);imagesc(rIbin_ra(end:-1:j_source,tij)*sparse(1:length(tij),1:length(tij),1./sum(rIbin_ra(end:-1:j_source,tij),1)),[0 4/1024]); ylabel('VI');
set(gca,'YTick',[1 j_source]);set(gca,'YTickLabel',{'VT','VR'});
subplot(5,1,3);
hold on;
l=stairs(tbin_ra(tij),VEavgbin_ra(tij),'r-'); set(l,'LineWidth',2);
l=stairs(tbin_ra(tij),VEavgbin_ra(tij)+VEstdbin_ra(tij),'r:'); set(l,'LineWidth',1);
l=stairs(tbin_ra(tij),VEavgbin_ra(tij)-VEstdbin_ra(tij),'r:'); set(l,'LineWidth',1);
l=stairs(tbin_ra(tij),VIavgbin_ra(tij),'b-'); set(l,'LineWidth',2);
l=stairs(tbin_ra(tij),VIavgbin_ra(tij)+VIstdbin_ra(tij),'b:'); set(l,'LineWidth',1);
l=stairs(tbin_ra(tij),VIavgbin_ra(tij)-VIstdbin_ra(tij),'b:'); set(l,'LineWidth',1);
xlim([min(tbin_ra(tij)) max(tbin_ra(tij))]);
ylim([VR VT]); ylabel('Vavg');
set(gca,'YTick',[0 1]);set(gca,'YTickLabel',{'VR','VT'});
hold off;
subplot(5,1,4); stairs(tbin_ra(tij),P_MFEbin_ra(tij),'g-'); xlim([min(tbin_ra(tij)) max(tbin_ra(tij))]); ylabel('P/dt');
subplot(5,1,5); hold on; stairs(tbin_ra(tij),xEbin_ra(tij),'r-'); stairs(tbin_ra(tij),xIbin_ra(tij),'b-'); xlim([min(tbin_ra(tij)) max(tbin_ra(tij))]); ylabel('#spk'); hold off; 
print('-depsc',sprintf('%s_FIG_A.eps',filename_base));
print('-djpeg',sprintf('%s_FIG_A.jpg',filename_base));
end;%if plot_flag & dtbin_record_flag;

plot_flag=1;
if plot_flag & dtbin_record_flag;
figure;
subplot(2,2,1); 
hold on;
rEtmp = mean(rEbin_ra,2); l= stairs(Vbins,rEtmp,'r-'); set(l,'LineWidth',2);
rItmp = mean(rIbin_ra,2); l= stairs(Vbins,rItmp,'b-'); set(l,'LineWidth',2);
xlim([Vbins(j_source) Vbins(end)]); ylim([0 1.1*max(max(rEtmp),max(rItmp))]);
hold off;
subplot(2,2,2);
hold on;
hEtmp = hist(mEbin_ra,[1:1.5*NE]); l=plot(log2([1:1.5*NE]),log2(1+hEtmp),'r-'); set(l,'LineWidth',2);
hItmp = hist(mIbin_ra,[1:1.5*NI]); l=plot(log2([1:1.5*NI]),log2(1+hItmp),'b-'); set(l,'LineWidth',2);
%hEtmp = hist(mEbin_ra,[1:1.5*NE]); l=loglog(([1:1.5*NE]),(1+hEtmp),'r-'); set(l,'LineWidth',2);
%hItmp = hist(mIbin_ra,[1:1.5*NI]); l=loglog(([1:1.5*NI]),(1+hItmp),'b-'); set(l,'LineWidth',2);
hold off;
subplot(2,2,[3,4]);
h = spectrum.mtm; Fs = 1000*1/tbinsize; hpsd = psd(h,(VEavgbin_ra*NE + VIavgbin_ra*NI)/(NE+NI),'Fs',Fs); plot(hpsd);
print('-depsc',sprintf('%s_FIG_B.eps',filename_base));
print('-djpeg',sprintf('%s_FIG_B.jpg',filename_base));
end;%if plot_flag & dtbin_record_flag;

% save(sprintf('%s_data.mat',filename_base));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [E_fired,I_fired,VE_pre,VI_pre,VE_pos,VI_pos] = Micro_solver_MFE_from_IFMODEL(V_PN,V_LN,S_EE,S_IE,S_EI,S_II,VEX,VIN);
VE = V_PN; VI = V_LN;
[VE,VEj] = sort(VE); [VI,VIj] = sort(VI); [VEjs,VEr] = sort(VEj); [VIjs,VIr] = sort(VIj); 
L_VPN = length(VE);
L_VLN = length(VI);

%% here we assume that at least 4 neurons fire  %% neron index, voltage, gE,gI,spike_tage,type (0 ln, 1 pn), micro_time %%
PN = zeros(L_VPN,7); PN(:,2) = VE; 
LN = zeros(L_VLN,7); LN(:,2) = VI;
[LE, LI, ll_target,sp_order,VE_pos,VI_pos] = neuronarrayevolve_microtime(LN,PN, S_EE, S_IE, S_EI, S_II,VEX,VIN);

VE_pre = [VE_pos,ones(1,LE)]; VI_pre = [VI_pos,ones(1,LI)];
VE_pos = [VE_pos,zeros(1,LE)]; VI_pos = [VI_pos,zeros(1,LI)];

VE_pre = VE_pre(VEr); VI_pre = VI_pre(VIr);
VE_pos = VE_pos(VEr); VI_pos = VI_pos(VIr);
E_fired = VEj(length(VE)-LE+1:length(VE));
I_fired = VIj(length(VI)-LI+1:length(VI));



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [X_bar,Y_bar,Vmin,X_hat,Y_hat] = V_transform(X,Y,D);
TAU_V=20;VT=1;VR=0;
DII = D(1,1); DIE = D(1,2); DIY = D(1,3);
DEI = D(2,1); DEE = D(2,2); DEY = D(2,3);
X=sort(X(:));
Y=sort(Y(:));
NE = length(X); NI = length(Y);
X_hat = X; X_bar = X_hat;
Y_hat = VT - (VT - Y)*DEE/DIE; Y_bar = Y_hat;
if (DEI > DII*DEE/DIE);
for ni=NI:-1:1; 
ij = find(X_bar < Y_bar(ni));
X_bar(ij) = X_bar(ij) - max(0,DEI - DII*DEE/DIE);
end;%for ni=NI:-1:1; 
elseif (DEI < DII*DEE/DIE);
for ni=1:NI; Y_bar(ni) = Y_hat(ni) - max(0,DII*DEE/DIE - DEI)*length(find(Y_hat>Y_hat(ni))); end;%for ni=1:NI;
end;%if;
X_bar = reshape(X_bar,1,NE);
Y_bar = reshape(Y_bar,1,NI);
Vmin = VR + min(0,-NI*abs(DII*DEE/DIE - DEI));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [E_fired,I_fired,VE,VI] = getMFE_ifdyn(verbose,VE,VI,D);
% assumes all the voltages are distinct;
TAU_V=20;VT=1;VR=0;
NE = length(VE); NI = length(VI);
if (verbose); [VE_bar,VI_bar] = V_transform(VE,VI,D); end;
DII = D(1,1); DIE = D(1,2); DIY = D(1,3);
DEI = D(2,1); DEE = D(2,2); DEY = D(2,3);
if (verbose); disp(sprintf(' DII %0.2f DIE %0.2f DEI %0.2f DEE %0.2f',DII,DIE,DEI,DEE)); end;
[VE,VEj] = sort(VE); [VI,VIj] = sort(VI); [VEjs,VEr] = sort(VEj); [VIjs,VIr] = sort(VIj); 
VE_orig = VE; VI_orig = VI;
I_fired = find(VI>=VT);
LI = length(I_fired);
I_remaining = find(VI<VT);
accumulated_DII=0; accumulated_DEI=0;
if LI>0;
if (verbose); disp(sprintf('LI %d, shifting VE',LI)); end;
VE = VE - DEI*LI; accumulated_DEI = accumulated_DEI + DEI*LI;
if (verbose); disp(sprintf('LI %d, shifting VI',LI)); end;
VI(I_remaining) = VI(I_remaining) - DII*LI; accumulated_DII = accumulated_DII + DII*LI;
end;%if LI>0;
E_fired = find(VE>=VT);
LE = length(E_fired);
if (verbose); disp(sprintf('LE %d',LE)); end;
E_remaining = find(VE<VT);
total_V_to_add_to_E = DEE*LE; 
total_V_to_add_to_I = DIE*LE;
if (verbose); disp(sprintf('')); end;
while (total_V_to_add_to_E>0 | total_V_to_add_to_I>0);
if (verbose); disp(sprintf('total_V_to_add_to_I %0.2f, I_remaining %d total_V_to_add_to_E %0.2f E_remaining %d',total_V_to_add_to_I,length(I_remaining),total_V_to_add_to_E,length(E_remaining))); end;
% possible_E_spikes = find(VE(E_remaining)>=VT-total_V_to_add_to_E);
% [max_E,ind_E] = max(VE(E_remaining));
% possible_I_spikes = find(VI(I_remaining)>=VT-total_V_to_add_to_I);
% [max_I,ind_I] = max(VI(I_remaining));
possible_E_spikes = find(VE(E_remaining)>=VT-total_V_to_add_to_E);
[max_E,ind_E] = max(VE(E_remaining)); ind_E = E_remaining(ind_E);
possible_I_spikes = find(VI(I_remaining)>=VT-total_V_to_add_to_I);
[max_I,ind_I] = max(VI(I_remaining)); ind_I = I_remaining(ind_I);
if (verbose); disp(sprintf('possible_E_spikes %d possible_I_spikes %d',length(possible_E_spikes),length(possible_I_spikes))); end;
if (isempty(possible_E_spikes) & isempty(possible_I_spikes)); 
  if (verbose); disp(sprintf('none can fire')); end;
  V_to_add_to_E = total_V_to_add_to_E;
  V_to_add_to_I = total_V_to_add_to_I;
  if (verbose); disp(sprintf(' VtoI %0.2f VtoE %0.2f',V_to_add_to_I,V_to_add_to_E)); end;
  VE(E_remaining) = VE(E_remaining) + V_to_add_to_E; 
  VI(I_remaining) = VI(I_remaining) + V_to_add_to_I;
  total_V_to_add_to_E = 0;
  total_V_to_add_to_I = 0;
elseif (~isempty(possible_E_spikes) & isempty(possible_I_spikes)); 
  if (verbose); disp(sprintf('only E can fire')); end;
  V_to_add_to_E = VT - max_E; 
  V_to_add_to_I = min(total_V_to_add_to_I,VT - max_E);
  if (verbose); disp(sprintf(' VtoI %0.2f VtoE %0.2f',V_to_add_to_I,V_to_add_to_E)); end;
  E_fired = [E_fired(:);ind_E]; E_remaining = setdiff(E_remaining,ind_E); LE = LE+1; if (verbose>1);hold on;; plot(VE_bar(ind_E),1-(LE+LI)/(NE+NI),'ro'); hold off; end;
  VE(E_remaining) = VE(E_remaining) + V_to_add_to_E; 
  VI(I_remaining) = VI(I_remaining) + V_to_add_to_I;
  total_V_to_add_to_E = total_V_to_add_to_E - V_to_add_to_E + DEE; 
  total_V_to_add_to_I = total_V_to_add_to_I - V_to_add_to_I + DIE;
elseif (isempty(possible_E_spikes) & ~isempty(possible_I_spikes)); 
  if (verbose); disp(sprintf('only I can fire')); end;
  V_to_add_to_I = VT - max_I; 
  V_to_add_to_E = min(total_V_to_add_to_E,VT - max_I);
  if (verbose); disp(sprintf(' VtoI %0.2f VtoE %0.2f',V_to_add_to_I,V_to_add_to_E)); end;
  VE(E_remaining) = VE(E_remaining) - DEI + V_to_add_to_E; accumulated_DEI = accumulated_DEI + DEI;
  I_fired = [I_fired(:);ind_I]; I_remaining = setdiff(I_remaining,ind_I); LI=LI+1; if (verbose>1);hold on;; plot(VI_bar(ind_I),1-(LE+LI)/(NE+NI),'bo'); hold off; end;
  VI(I_remaining) = VI(I_remaining) - DII + V_to_add_to_I; accumulated_DII = accumulated_DII + DII;
  total_V_to_add_to_E = total_V_to_add_to_E - V_to_add_to_E;
  total_V_to_add_to_I = total_V_to_add_to_I - V_to_add_to_I;
elseif (~isempty(possible_E_spikes) & ~isempty(possible_I_spikes)); 
% disp('We assume that E and I increase in voltage at a fixed rate');
% disp('this is tantamount to the impulse response of gE being a step function, with height proportional to DQE and constant width (e.g., 1)');
if ((VT-VI_orig(ind_I) + accumulated_DII)/DIE <= (VT-VE_orig(ind_E) + accumulated_DEI)/DEE);
  if (verbose); disp(sprintf('both E and I can fire, I closer')); end;
  V_to_add_to_I = VT - max_I; 
  V_to_add_to_E = min(total_V_to_add_to_E,VT - max_I);
  if (verbose); disp(sprintf(' VtoI %0.2f VtoE %0.2f',V_to_add_to_I,V_to_add_to_E)); end;
  VE(E_remaining) = VE(E_remaining) - DEI + V_to_add_to_E; accumulated_DEI = accumulated_DEI + DEI;
  I_fired = [I_fired(:);ind_I]; I_remaining = setdiff(I_remaining,ind_I); LI=LI+1; if (verbose>1);hold on;; plot(VI_bar(ind_I),1-(LE+LI)/(NE+NI),'bo'); hold off; end;
  VI(I_remaining) = VI(I_remaining) - DII + V_to_add_to_I; accumulated_DII = accumulated_DII + DII;
  total_V_to_add_to_E = total_V_to_add_to_E - V_to_add_to_E;
  total_V_to_add_to_I = total_V_to_add_to_I - V_to_add_to_I;
elseif ((VT-VI_orig(ind_I) + accumulated_DII)/DIE >  (VT-VE_orig(ind_E) + accumulated_DEI)/DEE);
  if (verbose); disp(sprintf('both E and I can fire, E closer')); end;
  V_to_add_to_E = VT - max_E; 
  V_to_add_to_I = min(total_V_to_add_to_I,VT - max_E);
  if (verbose); disp(sprintf(' VtoI %0.2f VtoE %0.2f',V_to_add_to_I,V_to_add_to_E)); end;
  E_fired = [E_fired(:);ind_E]; E_remaining = setdiff(E_remaining,ind_E); LE = LE+1; if (verbose>1);hold on;; plot(VE_bar(ind_E),1-(LE+LI)/(NE+NI),'ro'); hold off; end;
  VE(E_remaining) = VE(E_remaining) + V_to_add_to_E; 
  VI(I_remaining) = VI(I_remaining) + V_to_add_to_I;
  total_V_to_add_to_E = total_V_to_add_to_E - V_to_add_to_E + DEE; 
  total_V_to_add_to_I = total_V_to_add_to_I - V_to_add_to_I + DIE;
end;%if max_E<>max_I;
end;%if any possible spikes;
end;%while (total_V_to_add>0);
VE = reshape(VE,1,NE);
VI = reshape(VI,1,NI);
E_fired = reshape(E_fired,1,length(E_fired));
I_fired = reshape(I_fired,1,length(I_fired));
if (verbose); disp(sprintf(' LE %d, LI %d',LE,LI)); end;
E_fired = VEj(E_fired);
I_fired = VIj(I_fired);
VE = VE(VEr);
VI = VI(VIr);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function plotcdf(V,C);
TAU_V=20;VT=1;VR=0;
hold on;
N = length(V);
V = sort([VR;V(:);VT]); V = V(:);
Y = linspace(0,1,N+1); Y = Y(:);
l = line([transpose(V(1:end-1));transpose(V(2:end))] , [transpose(Y(1:end)) ; transpose(Y(1:end))]); set(l,'Color',C);
l = line([transpose(V(2:end-1));transpose(V(2:end-1))] , [transpose(Y(1:end-1)) ; transpose(Y(2:end))]); set(l,'Color',C);
if N<=24;
l = plot(V(2:end-1),linspace(1/N,1,N),'o'); set(l,'Color',C);
l = plot(V(2:end-1),linspace(0/N,1-1/N,N),'o'); set(l,'Color',C);
end;%if N<=24;
hold off;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function p = staircase2(X,Y,D,Vlim,C);
% plots the cdf of X,Y,G as a staircase plot;
% D is organized as [DII DIE DEI DEE];
TAU_V=20;VT=1;VR=0;
DII = D(1,1); DIE = D(1,2); DIY = D(1,3);
DEI = D(2,1); DEE = D(2,2); DEY = D(2,3);
X = min(max(sort(X(:)),Vlim(1)),Vlim(2));
nx = length(X(:)); X = reshape(X,1,nx);
X_orig=X;
Y = min(max(sort(Y(:)),Vlim(1)),Vlim(2));
ny = length(Y); Y = reshape(Y,1,ny);
[X_bar,Y_bar,DVmin] = V_transform(X,Y,D);
Zx = [Vlim(1) transpose(reshape([X_bar;X_bar],2*nx,1)) Vlim(2) Vlim(2)];
Zy = [0 0 transpose(reshape([1:nx;1:nx]/nx,2*nx,1)) 0];
hold on; p = patch(Zx,Zy,C); set(p,'FaceColor','none','LineWidth',2,'LineStyle',':'); hold off;
Zx = [Vlim(1) transpose(reshape([Y_bar;Y_bar],2*ny,1)) Vlim(2) Vlim(2)];
Zy = [0 0 transpose(reshape([1:ny;1:ny]/ny,2*ny,1)) 0];
hold on; p = patch(Zx,Zy,C); set(p,'FaceColor','none','LineWidth',2,'LineStyle','--'); hold off;
Zv = [X_bar,Y_bar]; [Zv,Iz] = sort(Zv,'ascend');
Zj = [ones(1,nx)*-1/nx , ones(1,ny)*1/nx*min(DII*DEE/DIE,DEI)/DEE]; 
Zj = Zj(Iz);
Zs = cumsum(Zj(end:-1:1)); Zs = 1 + [Zs(end:-1:1)];
nz = length(Zs);
Zv = reshape(Zv(:),1,nz);
Zs = reshape(Zs(:),1,nz);
Zj = reshape(Zj(:),1,nz);
Zx = transpose(reshape([Zv;Zv],2*nz,1));
Zx = [Vlim(1) Vlim(1) Zx Vlim(2) Vlim(2)];
Zy = transpose(reshape([Zs;Zs],2*nz,1));
Zy = [0 Zy 1 1 0];
hold on; p = patch(Zx,Zy,C); set(p,'FaceColor','none','LineWidth',3); hold off;
axis([Vlim(1) Vlim(2) 0 max(max(Zs),1)]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function p = staircase(Z,Vlim,C);
% plots the cdf of Z as a staircase plot;
TAU_V=20;VT=1;VR=0;
Z = min(max(sort(Z),Vlim(1)),Vlim(2));
nz = length(Z);
Z = reshape(Z,1,nz);
Zx = transpose(reshape([Z;Z],2*nz,1));
Zx = [Vlim(1) Zx Vlim(2) Vlim(2)];
Zy = transpose(reshape([1:nz;1:nz]/nz,2*nz,1));
Zy = [0 0 Zy 0];
p = patch(Zx,Zy,C);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [fig1] = figpos()
set(0,'Units','pixels') ;
scnsize = get(0,'ScreenSize');
fig1 = figure;
position = get(fig1,'Position');
outerpos = get(fig1,'OuterPosition');
borders = outerpos - position;
edge = -borders(1)/2;
pos1 = [edge - 1800,  scnsize(4) * (2/3) - 500,  scnsize(3) - edge + 300,  scnsize(4) + 300];
set(fig1,'OuterPosition',pos1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function p=plotvarrho(dt_ra,V_ra,nbins);
% assumes t_ra is Nx1 and V_ra is NxM ;
TAU_V=20;VT=1;VR=0;
t_ra = cumsum(dt_ra);
[N,M] =  size(V_ra);
Vedges = [VR-(VT-VR)/10, linspace(VR,VT,nbins)];
Vh = histc(V_ra,Vedges,2);
for tij=1:N;
p=patch(repmat(t_ra(tij) - dt_ra(tij) + dt_ra(tij)*[0;1;1;0],1,nbins+1),[Vedges;Vedges;[Vedges(2:end) VT+0.1];[Vedges(2:end) VT+0.1]],Vh(tij,:)/max(Vh(tij,:)));
set(p,'LineStyle','none');
end;%for tij=1:N;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function l=plotvarrho_sum(dt_ra,V_ra,nbins);
% assumes t_ra is Nx1 and V_ra is NxM ;
TAU_V=20;VT=1;VR=0;
t_ra = cumsum(dt_ra);
[N,M] =  size(V_ra);
Vedges = [VR-(VT-VR)/10, linspace(VR,VT,nbins)];
Vbins = [0 , (Vedges(2:end-1)+Vedges(3:end))/2 , Vedges(end)];
Vh = histc(V_ra,Vedges,2);
varrho_sum = reshape(dt_ra,1,length(dt_ra))*Vh;
l=plot(Vbins,varrho_sum);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function data_update(LE_cur,LI_cur,Vbins,VE,VI,t_pos,TMAX,dt_cur,tbinsize,dtbin_ra,rEbin_ra,rIbin_ra,VEavgbin_ra,VEstdbin_ra,VIavgbin_ra,VIstdbin_ra,xEbin_ra,xIbin_ra);
% updates data structure, does not work as a function due to lack of handles;
if dt_cur==0;
dtbin_ij = 1+floor(t_pos/tbinsize); 
if (dtbin_ij <= TMAX/tbinsize);
xEbin_ra(dtbin_ij) = xEbin_ra(dtbin_ij) + LE_cur;
xIbin_ra(dtbin_ij) = xIbin_ra(dtbin_ij) + LI_cur;
end;%if (dtbin_ij <= TMAX/tbinsize);
else;%if dt_cur==0;
t_pre = t_pos-dt_cur;
dtbin_pre = floor(t_pre/tbinsize);
dtbin_pos = floor(t_pos/tbinsize);
if (dtbin_pre==dtbin_pos);
  dtbin_ij = 1+dtbin_pre;
  if (dtbin_ij <= TMAX/tbinsize);
  dtbin_ra(dtbin_ij) = dtbin_ra(dtbin_ij) + dt_cur; 
  rEbin_ra(:,dtbin_ij) = rEbin_ra(:,dtbin_ij) + dt_cur*transpose(hist(VE,Vbins)); 
  rIbin_ra(:,dtbin_ij) = rIbin_ra(:,dtbin_ij) + dt_cur*transpose(hist(VI,Vbins)); 
  VEavgbin_ra(dtbin_ij) = VEavgbin_ra(dtbin_ij) + dt_cur*mean(VE); 
  VEstdbin_ra(dtbin_ij) = VEstdbin_ra(dtbin_ij) + dt_cur*std(VE); 
  VIavgbin_ra(dtbin_ij) = VIavgbin_ra(dtbin_ij) + dt_cur*mean(VI); 
  VIstdbin_ra(dtbin_ij) = VIstdbin_ra(dtbin_ij) + dt_cur*std(VI);
  end;%if (dtbin_ij <= TMAX/tbinsize);
elseif (dtbin_pre<dtbin_pos);
  hE = transpose(hist(VE,Vbins)); hI = transpose(hist(VI,Vbins)); 
  vEavg = mean(VE); vEstd = std(VE); vIavg = mean(VI); vIstd = std(VI);
  dtbin_ij = 1+dtbin_pre; dt_pre = tbinsize*dtbin_pos - t_pre;
  if (dtbin_ij <= TMAX/tbinsize);
  dtbin_ra(dtbin_ij) = dtbin_ra(dtbin_ij) + dt_pre;
  rEbin_ra(:,dtbin_ij) = rEbin_ra(:,dtbin_ij) + dt_pre*hE;
  rIbin_ra(:,dtbin_ij) = rIbin_ra(:,dtbin_ij) + dt_pre*hI;
  VEavgbin_ra(dtbin_ij) = VEavgbin_ra(dtbin_ij) + dt_pre*vEavg;
  VEstdbin_ra(dtbin_ij) = VEstdbin_ra(dtbin_ij) + dt_pre*vEstd;
  VIavgbin_ra(dtbin_ij) = VIavgbin_ra(dtbin_ij) + dt_pre*vIavg;
  VIstdbin_ra(dtbin_ij) = VIstdbin_ra(dtbin_ij) + dt_pre*vIstd;
  end;%if (dtbin_ij <= TMAX/tbinsize);
  dtbin_ij = 1+dtbin_pos; dt_pos = t_pos - tbinsize*dtbin_pos;
  if (dtbin_ij <= TMAX/tbinsize);
  dtbin_ra(dtbin_ij) = dtbin_ra(dtbin_ij) + dt_pos; 
  rEbin_ra(:,dtbin_ij) = rEbin_ra(:,dtbin_ij) + dt_pos*hE;
  rIbin_ra(:,dtbin_ij) = rIbin_ra(:,dtbin_ij) + dt_pos*hI;
  VEavgbin_ra(dtbin_ij) = VEavgbin_ra(dtbin_ij) + dt_pos*vEavg;
  VEstdbin_ra(dtbin_ij) = VEstdbin_ra(dtbin_ij) + dt_pos*vEstd;
  VIavgbin_ra(dtbin_ij) = VIavgbin_ra(dtbin_ij) + dt_pos*vIavg;
  VIstdbin_ra(dtbin_ij) = VIstdbin_ra(dtbin_ij) + dt_pos*vIstd;
  end;%if (dtbin_ij <= TMAX/tbinsize);
end;% dtbin_pre vs dtbin_pos;
end;% else;%if dt_cur==0;