    function [LE, LI,ll_target, sp_order,V_NEW_PN,V_NEW_LN] = neuronarrayevolve_microtime(N_LN,N_PN, S_EE, S_IE, S_EI, S_II,VEX,VIN);
    %%N = zeros(7,1) neron index, voltage, gE,gI,spike_tage,type (0 ln, 1 pn),
    [ll_target, ll_firing] = first_check_firing(N_PN,N_LN);
%     size(ll_firing)
    t_micro = 0; LE = 0; LI =0; V_NEW_PN = zeros(0); V_NEW_LN = zeros(0);
    L_le = length(ll_firing);if(L_le);L_length = length(ll_firing(:,1));else;L_length = 0;end;
    sp_order = zeros(0); s_order_counter = 1;
    while(L_length > 0) %% it is for large while
        ind_f = L_length;
        while(ind_f > 0) %% %% it is for smaller while to update the neurons
            n0 = ll_firing(ind_f,:);
%             if(n0(6)>0); sp_order(s_order_counter,:) = [1,0]; s_order_counter = s_order_counter +1;else;sp_order(s_order_counter,:) = [0,1]; s_order_counter = s_order_counter +1; end
            if length(ll_target)>0;ind_t = length(ll_target(:,1));else;ind_t = 0;end;
            for it = 1:ind_t;
                n1 = ll_target(it,:);
                n = neuron_kick_microtime(n1, n0, S_EE, S_IE, S_EI, S_II);
                n(7) = t_micro;
                ll_target(it,:) = n;
            end;
            ind_f = ind_f - 1;
        end; %% end of while(L_length > 0) for smaller one

        [ll_firing,ll_target, nspikes , dt_micro] = micro_spiketime_guess(ll_target,VEX,VIN);
        %% In this function, we already remove the firing neuron from the ll_target; Thus the resulting ll_target only includes the no-firing neurons
        if(dt_micro < 0);
            %% do nothing %%
        else;
           if(length(ll_target));L_t = length(ll_target(:,1));else; L_t = 0;end;
            for lt = 1:L_t;n0 = ll_target(lt,:);ll_target(lt,:) = micro_neuronevolve(n0, dt_micro,VEX,VIN);end;
            if(dt_micro > 0);t_micro = t_micro + dt_micro;elseif(dt_micro<0);t_micro = -1;end;
        end;
        L_length = length(ll_firing);if(L_length);L_length = length(ll_firing(:,1));else;L_length = 0;end;

    end; %% end of while(L_length > 0) for larger one
    
    if(length(ll_target));L_t = length(ll_target(:,1));else;L_t = 0;end;
    for lt = 1:L_t;
        if(ll_target(lt,6) == 0);LI = LI + 1; V_NEW_LN(LI) = ll_target(lt,2);else; LE = LE + 1; V_NEW_PN(LE) = ll_target(lt,2);end;
    end;
    LI = length(N_LN(:,1)) - LI;
    LE = length(N_PN(:,1)) - LE;
    end %% end of neuronarrayevolve_microtime %%


    function [ll_target, ll_firing] = first_check_firing(N_PN,N_LN)
    ll_target = zeros(0);
    ll_firing = zeros(0); vT = 1.0;
    %%N_PN = zeros(length(V_PN),7);%% neron index, voltage, gE,gI,spike_tage,type (0 ln, 1 pn), micro_time %%
    ind_firing = 1; ind_target = 1;
    N_PN(:,6) = 1; N_LN(:,6) = 0;

    if(length(N_PN)); L_length = length(N_PN(:,1)); else; L_length = 0; end

    for jj = 1:L_length;
        N = N_PN(jj,:);
        if( N(2) >= vT);
            N(5) = 1;
            ll_firing(ind_firing,:) = N;
            ind_firing = ind_firing +1;
        else;
             N(5) = 0;
            ll_target(ind_target,:) = N;
            ind_target = ind_target +1;
        end;
    end

    if(length(N_LN)); L_length = length(N_LN(:,1));   else;  L_length = 0; end;
    for jj = 1:L_length;
        N = N_LN(jj,:);
        if( N(2) >= vT);
            N(5) = 1;
            ll_firing(ind_firing,:) = N;
            ind_firing = ind_firing +1;
        else;
            ll_target(ind_target,:) = N;
            ind_target = ind_target +1;
        end;
    end

    end

    function [micro_spike_flag, dt_crit] = micro_spiketime_guess_helper_0(N,VEX,VIN)
    %% N(7) neron index, voltage, gE,gI,spike_tage,type (0 ln, 1 pn), micro_time %%
    
    gE = N(3); gI = N(4); V = N(2); vT = 1.0; dt_crit = 0; 
    vE = VEX; vI = VIN; %%% vE = 14.0/3.0; vI = -2.0/3.0;
     micro_spike_flag = 0;
    if (V>= vT)
        dt_crit = 0; micro_spike_flag = 1;
    else  %% elseif (V<vT) %%
        if(gE<=0 && gI<=0)
            dt_crit = -1; micro_spike_flag = 0;
        elseif(gE>0 && gI<=0)
            V_infnty = vE + (V-vE)*exp(-gE);
            if(V_infnty <= vT)
                dt_crit = -1; micro_spike_flag = 0;
            else
                dt_crit = log(1.0/(1.0-1.0/gE*log((vE-V)/(vE-vT)))); micro_spike_flag = 1;
            end
        elseif(gE<=0 && gI>0)
            dt_crit = -1; micro_spike_flag = 0;
        elseif(gE>0 && gI>0)
            I_max = 0;  gamma = gE/gI; I1 = gI;
            VS = (gamma*vE + vI)/(1.0+gamma);
            V_max = VS + (V -VS)*exp(-(1.0+gamma)*(I1-I_max));
            if(V_max <=vT);           dt_crit = -1; micro_spike_flag = 0;
            else
                dt_crit = log(1.0/(1.0 + 1.0/gI/(1.0+gamma)*log((VS-vT)/(VS-V))));
                micro_spike_flag = 1;
            end %% end V_max>
        end
    end %% else (V<vT) %%
    end

    function [B_firing,B_target, nspikes , dt_crit_p] = micro_spiketime_guess(A_target,VEX,VIN) %%
    ll = 1; nspikes = 0; dt_crit_p = 0; B_firing = zeros(0); B_target = zeros(0);
    if(length(A_target));L_length = length(A_target(:,1));else;L_length = 0;end;
    micro_spike_flag_ra = zeros(0);dt_crit = zeros(0);
    while(L_length>0)
        N = A_target(ll,:); %% Get the informatiom of each neuron %% N(7) neron index, voltage, gE,gI,spike_flage,type (0 ln, 1 pn), micro_time %%
    %     if (N(5) == 0);
            [micro_spike_flag_ra(ll), dt_crit(ll)] = micro_spiketime_guess_helper_0(N,VEX,VIN);

            if(micro_spike_flag_ra(ll) == 1) %% means micro_spike_flag(ll) =1;
                nspikes = nspikes +1;
                if(nspikes == 1)
                    dt_crit_p = dt_crit(ll);
                else
                    dt_crit_p = min(dt_crit_p, dt_crit(ll));
                end
    %         elseif (micro_spike_flag_ra(ll) ~= 0 )
    %             micro_spike_flag_ra(ll) = 0; dt_crit(ll) = -1;
            end
    %     else %% N(5) !=0
    %         micro_spike_flag_ra(ll) = 0; dt_crit(ll) = -1;
    %         disp('Warning');
    %     end
        ll = ll +1;L_length = L_length -1;
    end %% end of while;

    if(length(A_target));L_length = length(A_target(:,1));else;L_length = 0;end;
    Global_tolerance  = 0.000000000001; ind_t = 1;ind_f = 1;
    for jj = 1:L_length
        if(micro_spike_flag_ra(jj) == 1)
            B_firing(ind_f,:) = A_target(jj,:);
            B_firing(ind_f,5) = 1;       ind_f = ind_f + 1;
        else
            if(dt_crit_p > 0 && abs(dt_crit(jj) - dt_crit_p) < Global_tolerance)
                B_firing(jj,:) = A_target(jj,:);
                B_firing(jj,5) = 1;
                micro_spike_flag_ra(jj) = 1;
                ind_f  = ind_f +1;
            end
        end
        if(micro_spike_flag_ra(jj) < 1) %%%% it is used to remove the firing neuron to get new B_target %%
            B_target(ind_t,:) = A_target(jj,:); ind_t = ind_t+1;
        end
    end

    end %% end of function mic..flag %%

    function n = neuron_kick_microtime(n_temp, s, sEE, sIE, sEI, sII )
    % % assume that: n(7) = [ neron index, voltage, gE,gI,spike_tage, type, micro_time ]
    n = n_temp;
    if(s(6) > 0) %% means pn neurons
        if(n(6) > 0);n(3) = n(3) + sEE;
        else
            n(3) = n(3) + sIE;
        end
    else%% else s(6) <=0
        if(n(6) > 0)
            n(4) = n(4) + sEI;
        else
            n(4) = n(4) + sII;
        end

    end

    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%% In this part we are devote to evolving the I&F model to counter
    %%%%% update the distribution of voltage density and obtain the number
    %%%%% of spiking neurons for LN population and PN population
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%% dv/dt = - gE (v-vE) - gI(v-vI)
    %%%% dgE/dt = - gE + sum(t-T_k)
    %%%% dgI/dt = - gI + sum(t-T_k)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%% Let r = gI/gE ang g = gE*exp(-t) and we have
    %%%% dv/dt = -g(1+r)(v-Vs)
    %%%% where Vs = (vE + r*vI)/(1+r);
    %%%% Since dv/dt = dv/dg * dg/dt, thus we have
    %%%% dv/dg = (1+r) (v-Vs), and its solution is
    %%%% v = (v0 - Vs) * exp((1+r)*gE(exp(-t) - 1)) + Vs
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%% vmax = Vs + (v0 - Vs) *exp(-(1+r)*gE)  when t --> infinity
    %%%% Tspike = t0 - log[ 1 + 1/(1+r)/gE * log((vT-Vs)/(v0-Vs))];
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Now we already know the information of V_LN, V_PN and assume the
    %%% following parameters are known
    %%% vE = 14/3; vI = -2/3; and at first, there is one PN- neuron to fire.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function   N_new = micro_neuronevolve(N, dt_micro,VEX,VIN)

    %% N(7) = [neronIndex, voltage, gE,gI,spike_tage,type (0 ln, 1 pn), micro_time] %%
    N_new = N;
    vE = VEX; vI = VIN;%%vE = 14.0/3.0; vI = -2.0/3.0;
    gE = N(3); gI = N(4); V_start = N(2);
    if (dt_micro<=0)
        if(gE<=0 && gI<=0)
            V = V_start;
        elseif(gE>0 && gI<=0)
            V = forward_kick(V_start,vE,gE);
        elseif(gE<=0 && gI>0)
            V = forward_kick(V_start,vI,gI);
        elseif(gE>0 && gI>0)
            gamma = gE/gI; I1 = gI; I2 = 0;
            VS = (gamma*vE + vI)/(1.0+gamma);
            V = VS + (V_start -VS)*exp(-(1.0+gamma)*(I1-I2));
        end
    %     N_new(3) = 0;N_new(4) = 0; N_new(2) = V;
    N_new(2) = V;
   
    else %% elseif (dt_micro>=0)%%
        if(gE<=0 && gI<=0);
            V = V_start;
        elseif(gE>0 && gI<=0);
            V = forward_kick(V_start,vE,gE*(1.0 - exp(-dt_micro)));
        elseif(gE<=0 && gI>0)
            V = forward_kick(V_start,vI,gI*(1.0 - exp(-dt_micro)));
        elseif(gE>0 && gI>0)
            gamma = gE/gI; I1 = gI; I2 = gI*exp(-dt_micro);
            VS = (gamma*vE + vI)/(1.0+gamma);
            V = VS + (V_start -VS)*exp(-(1.0+gamma)*(I1-I2));
        end
        e_val = exp(-dt_micro);
        N_new(3) = N(3) *e_val;N_new(4) = N(4)*e_val; N_new(2) = V;
    end

    end %% micro_neuronevolve()%%

    function output = forward_kick(xv,xvE,xS)
    output = xvE + (xv-xvE).*exp(-xS);
    end
