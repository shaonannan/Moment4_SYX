N = [128 128]; mY = [0.54 0.55]; D = [0.*N(1) 0.0006*N(2) 0.018; 0.0006*N(1) 0.0006*N(2) 0.018]; TMAX = 200, dt = 0.02; 


[x,u1,uI1]=Jiwei_FPE_ver2(N,mY,D,TMAX,dt);

[rE_me,rI_me,nbins_me,dV_me,Vedges_me,Vbins_me,t_ra_me,mE_ra_me,mI_ra_me,P_MFE_ra_me,rE_ra_me,rI_ra_me,Lt_ra_me,LE_ra_me,LI_ra_me,tbin_ra_me,mEbin_ra_me,mIbin_ra_me,xEbin_ra_me,...
    xIbin_ra_me,P_MFEbin_ra_me,rEbin_ra_me,rIbin_ra_me,VEavgbin_ra_me,VEstdbin_ra_me,VIavgbin_ra_me,VIstdbin_ra_me] ...
    = Jiwei_me_vol_dep_ver1(N,mY,D,TMAX,dt,14/3, -2/3);

[nbins,dV,Vedges,Vbins,t_ra,mE_ra,mI_ra,P_MFE_ra,rE_ra,rI_ra,Lt_ra,LE_ra,LI_ra,tbin_ra,mEbin_ra,mIbin_ra,xEbin_ra,xIbin_ra,P_MFEbin_ra,rEbin_ra,rIbin_ra,...
    VEavgbin_ra,VEstdbin_ra,VIavgbin_ra,VIstdbin_ra] = Jiwei_if_vol_dep_ver1(N,mY,D,5000,dt,-2/3,14/3);;

[v,rhoE,rhoI] = density_volt_dep_100213(N,mY,D,TMAX,dt);


figure;
subplot(221)
rEtmp = mean(rEbin_ra,2); l=stairs(Vbins(1:1:end),rEtmp(1:1:end),'r-'); set(l,'LineWidth',3);
hold on;
% rEtmp_me = mean(rEbin_ra_me,2); l=stairs(Vbins,rEtmp_me,'g--'); set(l,'LineWidth',2);
l=stairs(Vbins(1:1:end),rE_me(1:1:end),'g--'); set(l,'LineWidth',3);
legend('IF model','Master equation');
xlim([-0,1])
subplot(222)
hold on;
rItmp = mean(rIbin_ra,2); l=stairs(Vbins(1:1:end),rItmp(1:1:end),'r-'); set(l,'LineWidth',3);
% rItmp_me = mean(rIbin_ra_me,2); l=stairs(Vbins_me,rItmp_me,'g--'); set(l,'LineWidth',2);
l=stairs(Vbins(1:1:end),rI_me(1:1:end),'g--'); set(l,'LineWidth',3);
legend('IF model','Master equation')
xlim([-0,1])
subplot(223)
rEtmp = mean(rEbin_ra,2); l=stairs(Vbins(1:1:end),rEtmp(1:1:end),'r-'); set(l,'LineWidth',3);
hold on;
% l=stairs(x,u1,'b-'); set(l,'LineWidth',3);
l=stairs(v,rhoE,'b'); set(l,'LineWidth',3);
% legend('IF model','FP equation','Equilibrium solution')
legend('IF model','Equilibrium solution')
xlim([-0,1])
subplot(224)

rItmp = mean(rIbin_ra,2); l=stairs(Vbins(1:1:end),rItmp(1:1:end),'r-'); set(l,'LineWidth',3);
hold on;
% l=stairs(x,uI1,'b-'); set(l,'LineWidth',2);
l=stairs(v(1:1:end),rhoI(1:1:end),'b'); set(l,'LineWidth',3);
% legend('IF model','FP equation','Equilibrium solution')
legend('IF model','Equilibrium solution')
xlim([-0,1])