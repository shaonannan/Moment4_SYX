function [nbins,dV,Vedges,Vbins,t_ra,mE_ra,mI_ra,P_MFE_ra,rE_ra,rI_ra,Lt_ra,LE_ra,LI_ra,tbin_ra,mEbin_ra,mIbin_ra,xEbin_ra,...
    xIbin_ra,P_MFEbin_ra,rEbin_ra,rIbin_ra,VEavgbin_ra,VEstdbin_ra,VIavgbin_ra,VIstdbin_ra] ...
    = Moment4_vol_dep_ver1(Num_P,mY,D,TMAX,dt)

%{
 N = [128, 128]; mY = [0.54, 0.55]; D = [0*N(1), N(2)*0.0006,0.018;N(1)*0.0006,N(2)0.00144,0.018]; dt = 0.1; TMAX = 1000;
 Moment4_vol_dep_ver1(N,mY,D,TMAX,dt);
%}
format long;
WIN_USE = 0;if WIN_USE,catalog_str = '\\';else,catalog_str = '/';end
MFE_COMPUT_USED = 1;PLOT_or_NOT =0; record_MFE_or_not = 0;density_plot_or_not = 0;
NE = Num_P(2);NI = Num_P(1); vL =0; gL=0.05;vT = 1.0; VR =0; vE = 14/3;vI = -2/3;
DEE = D(2,2);DEI = D(2,1);DIE = D(1,2); DII = D(1,1); etaE = mY(2); fE = D(2,3);etaI = mY(1);fI = D(1,3);
D(:,1:2) = inv(diag(Num_P))*D(:,1:2);
tagline = sprintf('N_%.3d_%.3d_mY_%.2d_%.2d_D_%.2d_%.2d_%.2d_%.2d_%.2d_%.2d_T%.3d_dt%.3d',NI,NE,round(10*etaI),round(10*etaE),round(100*DII),round(100*DIE),round(100*DEI),round(100*DEE),round(100000*fE),round(100000*fI),round(TMAX/1024),round(dt*1000));
DEE = D(2,2);DEI = D(2,1);DIE = D(1,2); DII = D(1,1); etaE = mY(2); fE = D(2,3);etaI = mY(1);fI = D(1,3);

filename_base = sprintf('fm5_%s',tagline);
N_divide =2000; V_start = -1; V_end = 1;
V = linspace(V_start,V_end,N_divide); h = V(2) - V(1);V = V';
step = 0; 
mE = 0.0; mI = 0;
counter = 1; t =0;

vk1 = vE + (vT-vE)*exp(DEE);
vIk1= vE + (vT-vE)*exp(DIE);
vT_idx = length(V);
Ind_k1 = find(V>=vk1);k1_idx = Ind_k1(1); if(Ind_k1>vT_idx); k1_idx = vT_idx;end
IndI_k1 = find(V>=vIk1);kI_idx = IndI_k1(1); if(IndI_k1>vT_idx); kI_idx = vT_idx;end

TD = Tanslate_S_to_s(D);
[gTI,gTE] = get_gT(Num_P,mY,TD,mE,mI,gL);
[muI,muE] = get_mu(Num_P,mY,TD,mE,mI,vE,vI,gTE,gTI,gL,vL);
[abcI,abcE] = get_coeff_sigma(Num_P,mY,TD,mE,mI,vE,vI,gTE,gTI);
[FPgammaI,FPgammaE] = get_gamma(Num_P,mY,TD,mE,mI,gTE,gTI);
[PIq,PEq,sumI,sumE] = get_density(V',abcE,abcI,muE,muI,VR,vT,FPgammaI,FPgammaE);

%%% Now I need give a guess of the initial values of diffent moments to evolve the ODE
var1 = (1/100.0)^2;
%% To define some index, it is easy to find some index for V>=VT and and the index for v = VR in the coming code
source = exp(-(V+0.0).^2/var1/2.0)/sqrt(2.0*pi*var1);source = source/(h*sum(source));
vbarE = (V(2)-V(1))*sum(V.*source);wbarE = (V(2)-V(1))*sum(V.^2 .*source);vbar3E = (V(2)-V(1))*sum(V.^3 .*source);vbar4E = (V(2)-V(1))*sum(V.^4 .*source);
vbarI = vbarE; wbarI = wbarE; vbar3I = vbar3E; vbar4I = vbar4E;
% hold all; plot(V,source),hold on

gammaE = [1,vbarE,wbarE,vbar3E,vbar4E];
gammaI = [1,vbarI,wbarI,vbar3I,vbar4I];
fiE = gammaE';fiI = gammaI';
moment2 = 1; options = optimset('TolFun',1e-9,'GradObj','on');
if moment2
    F = fiE(2:3);FI = fiI(2:3);
else
    F = fiE(2:end)*0;FI = fiI(2:end)*0;
end

if moment2
    La0 = gammaE(1:3)';
    LaI0 = gammaI(1:3)';
else
    La0 = gammaE(1:end)';
    LaI0 = gammaI(1:end)';
end


nbins=1025; nbinp = nbins+1; dV = (vT-(VR-vT))/nbins; Vedges = linspace(VR-vT,vT,nbinp); Vedges = Vedges';Vbins = (Vedges(1:end-1)+Vedges(2:end))/2;
j_source = (nbins+1)/2; 
 V1 = Vbins; V2 = V1.*Vbins; V3 = V2.*Vbins; V4 = V3.*Vbins;

N=length(La0);
fin=zeros(length(V),N);
fin(:,1)=ones(size(V)); % fi0(x)=1
fin_s=zeros(length(Vbins),N);
fin_s(:,1)=ones(size(Vbins)); % fi0(x)=1


for n=2:N
    fin(:,n)=V.*fin(:,n-1);
    fin_s(:,n) = Vbins.*fin_s(:,n-1);
end

    [La1] = fsolve(@(La)optfun(F,V,La,PEq,fin,1),La0,optimset('Display','off'));
    [LaI1] = fsolve(@(LaII)optfun(FI,V,LaII,PIq,fin,1),LaI0,optimset('Display','off'));
    La0 = real(La1);
    LaI0 = real(LaI1);


times = 10000;  sum_mE = 0; sum_mI = 0; counter_firing_step = 0;    
if record_MFE_or_not

catalog_head1 = 'MFE10_event';
mkdir(catalog_head1);
var_fn = ['Exp_MFE_','NE_',num2str(NE),'_NI_',num2str(NI),'_DEE_',num2str(times*DEE),'_DIE_',num2str(times*DIE),'_DEI_',num2str(times*DEI),'_DII_',num2str(times*DII),...
    '_S_',num2str((times*fE)),'_R_',num2str((times*etaE)),'_S_ln_',num2str((times*fI)),'_R_ln_',num2str((times*etaI)),'N_',num2str((N_divide)),'dt_',num2str((dt*times)),'_T_',num2str(Final_time),'moment2_used', num2str(moment2),'_FFnum_',num2str(First_firing_num_neruons),'_P1_used_',num2str(P1_used)];
filename_rec =  [catalog_head1,catalog_str,var_fn,'.txt'];
fid = fopen(filename_rec, 'wt');

var_fn1 = ['Exp_moments_','_DEE_',num2str(times*DEE),'_DIE_',num2str(times*DIE),'_DEI_',num2str(times*DEI),'_DII_',num2str(times*DII),...
    '_S_',num2str((times*fE)),'_R_',num2str((times*etaE)),'_S_ln_',num2str((times*fI)),'_R_ln_',num2str((times*etaI)),'N_',num2str((N_divide)),'dt_',num2str((dt*times)),'_T_',num2str(Final_time),'moment2_used', num2str(moment2),'_FFnum_',num2str(First_firing_num_neruons),'_P1_used_',num2str(P1_used)];
filename_rec1 =  [catalog_head1,catalog_str,var_fn1,'.txt'];
fid1 = fopen(filename_rec1, 'wt');
var_fn2 = ['Exp_density_','_DEE_',num2str(times*DEE),'_DIE_',num2str(times*DIE),'_DEI_',num2str(times*DEI),'_DII_',num2str(times*DII),...
    '_S_',num2str((times*fE)),'_R_',num2str((times*etaE)),'_S_ln_',num2str((times*fI)),'_R_ln_',num2str((times*etaI)),'N_',num2str((N_divide)),'dt_',num2str((dt*times)),'_T_',num2str(Final_time),'moment2_used', num2str(moment2),'_FFnum_',num2str(First_firing_num_neruons),'_P1_used_',num2str(P1_used)];
end

plot_flag=0; dt_record_flag=0;
dtbin_record_flag=1; tbinsize = 1.0; dtperbin = floor(tbinsize/dt); tbinsize=dtperbin*dt;
iteration_max=dtperbin*TMAX/tbinsize;
MFE_num=1; Lt_ra(1)=0; LE_ra(1)=0; LI_ra(1)=0;
t_sum=0; t_ra = zeros(iteration_max+1,1);
mE_ra = zeros(iteration_max+1,1);
mI_ra = zeros(iteration_max+1,1);

if dt_record_flag;
    rE_ra = zeros(nbins,iteration_max);
    rI_ra = zeros(nbins,iteration_max);
else;%if dt_record_flag;
    rE_ra = [];
    rI_ra = [];
end;%if dt_record_flag;

if dtbin_record_flag;
    tbin_ra = zeros(iteration_max/dtperbin,1);
    mEbin_ra = zeros(iteration_max/dtperbin,1);
    mIbin_ra = zeros(iteration_max/dtperbin,1);
    xEbin_ra = zeros(iteration_max/dtperbin,1);
    xIbin_ra = zeros(iteration_max/dtperbin,1);
    P_MFEbin_ra = zeros(iteration_max/dtperbin,1);
    rEbin_ra = zeros(nbins,iteration_max/dtperbin);
    rIbin_ra = zeros(nbins,iteration_max/dtperbin);
    VEavgbin_ra = zeros(iteration_max/dtperbin,1);
    VEstdbin_ra = zeros(iteration_max/dtperbin,1);
    VIavgbin_ra = zeros(iteration_max/dtperbin,1);
    VIstdbin_ra = zeros(iteration_max/dtperbin,1);
else;%if dtbin_record_flag;
    tbin_ra = [];
    mEbin_ra = [];
    mIbin_ra = [];
    xEbin_ra = [];
    xIbin_ra = [];
    P_MFEbin_ra = [];
    rEbin_ra = [];
    rIbin_ra = [];
    VEavgbin_ra = [];
    VEstdbin_ra = [];
    VIavgbin_ra = [];
    VIstdbin_ra = [];
end;%;%if dtbin_record_flag;

rE = Vbins*0;rI = Vbins*0;

for iteration=0:iteration_max-1;
    MFE_flag = 0;
    t_ra(1+iteration) = t_sum;
    
    VIavg_ra(1+iteration) = vbarI;VIstd_ra(1+iteration) = sqrt(wbarI -vbarI^2);
    VEavg_ra(1+iteration) = vbarE;VEstd_ra(1+iteration) = sqrt(wbarE - vbarE^2);
    if dt_record_flag; rE_ra(:,1+iteration) = rE; rI_ra(:,1+iteration) = rI; end;
    if dtbin_record_flag;
        dtbin_ij = 1 + floor(iteration/dtperbin);
        tbin_ra(dtbin_ij) = tbin_ra(dtbin_ij) + dt*t_ra(1+iteration);
        rEbin_ra(:,dtbin_ij) = rEbin_ra(:,dtbin_ij) + dt*rE;
        rIbin_ra(:,dtbin_ij) = rIbin_ra(:,dtbin_ij) + dt*rI;
        VEavgbin_ra(dtbin_ij) = VEavgbin_ra(dtbin_ij) + dt*VEavg_ra(1+iteration);
        VEstdbin_ra(dtbin_ij) = VEstdbin_ra(dtbin_ij) + dt*VEstd_ra(1+iteration);
        VIavgbin_ra(dtbin_ij) = VIavgbin_ra(dtbin_ij) + dt*VIavg_ra(1+iteration);
        VIstdbin_ra(dtbin_ij) = VIstdbin_ra(dtbin_ij) + dt*VIstd_ra(1+iteration);
    end;% if dtbin_record_flag;
    
    
    [gTI,gTE] = get_gT(Num_P,mY,TD,mE,mI,gL);
    [muI,muE] = get_mu(Num_P,mY,TD,mE,mI,vE,vI,gTE,gTI,gL,vL);
    [abcI,abcE] = get_coeff_sigma(Num_P,mY,TD,mE,mI,vE,vI,gTE,gTI);
    [FPgammaI,FPgammaE] = get_gamma(Num_P,mY,TD,mE,mI,gTE,gTI);
    
    [vbarE,vbarI,wbarE,wbarI,vbar3E,vbar3I,vbar4E,vbar4I] = ...
        solveVbarWbar4_vol_dep(dt,vbarE, vbarI, wbarE, wbarI,vbar3E, vbar3I,vbar4E,vbar4I,muE,muI,abcE,abcI,mE,mI,FPgammaI,FPgammaE,gTI,gTE);
    
    fiE = [1,vbarE,wbarE,vbar3E,vbar4E]';
    fiI = [1,vbarI,wbarI,vbar3I,vbar4I]';
    [PIq,PEq,sumI,sumE] = get_density(V',abcE,abcI,muE,muI,VR,vT,FPgammaI,FPgammaE);
    
    if moment2
        F = fiE(2:3);FI = fiI(2:3);
    else
        F = fiE(2:end);FI = fiI(2:end);
    end
    
    [La1] = fminsearch(@(La)optfun(F,V,La,PEq,fin,1),La0,options);
    [LaI1] = fminsearch(@(LaII)optfun(FI,V,LaII,PIq,fin,1),LaI0,options);
    La0 = real(La1);   LaI0 = real(LaI1);
    
    
    RvE = PEq.*exp(fin(:,1:N)*La0); % Calculate p(x)
    RvI = PIq.*exp(fin(:,1:N)*LaI0); % Calculate p(x)
    
    RvE = RvE/((V(2)-V(1))*sum(RvE));
    RvI = RvI/((V(2)-V(1))*sum(RvI));
    
    
    %% This firing rate:
    mE = min(gTE*exp(sum(La1))/sumE/2,0.1);
    mI = min(gTI*exp(sum(LaI1))/sumI/2,0.1);
    
    if step >2000;
        t, mE,mI
        step = 0;
        if PLOT_or_NOT
            figure(1)
            subplot(211)
            plot(V(1:5:end),RvE(1:5:end),'mo');
            subplot(212)
            plot(V(1:5:end),RvI(1:5:end),'b*');
            drawnow;
        end
    end
    t = dt*counter;
    counter = counter + 1; step = step +1;
    mI_ra(1+iteration) = mI; mE_ra(1+iteration) = mE;
    p_single = mE*dt;
    mkpn1 = (V(2) - V(1))*sum(RvE(k1_idx:vT_idx));
    mklnI = (V(2) - V(1))*sum(RvE(kI_idx:vT_idx));

    q = (1.0 - mkpn1)^(NE-1) .* (1-mklnI).^NI;
    local_pevent =  NE*p_single*(1.0-q);
    
    P_MFE_ra(1+iteration) = local_pevent;
    P_MFE = local_pevent*dt;
  
%     [PIq_s,PEq_s,sumI_s,sumE_s] = get_density(Vbins',abcE,abcI,muE,muI,VR,vT,FPgammaI,FPgammaE);
%     rE = PEq_s.*exp(fin_s(:,1:N)*La1); % Calculate p(x)
%     rI = PIq_s.*exp(fin_s(:,1:N)*LaI1); % Calculate p(x)
%     rE = rE/sum(rE)*(Vbins(2) - Vbins(1)) ;
%     rI = rI/sum(rI)*(Vbins(2) - Vbins(1)) ;

rE = interp1(V,RvE,Vbins); rE(end) = 0;
rI = interp1(V,RvI,Vbins); rI(end) = 0;
rE = rE/sum(rE); rI = rI/sum(rI); 

    if (MFE_COMPUT_USED) 
        %%%%%%%%%%%%%%%%%%%%%% detect MFEs
        %% we randomly decide to actually carry through with an MFE with probability local_pevent %%
        local_pevent_d = rand(1);
        if(local_pevent_d<local_pevent)
            MFE_flag=1;
            MFE_num = MFE_num+1;

            VE_sample = transpose(getsamples(Vedges,rE,NE));
            VI_sample = transpose(getsamples(Vedges,rI,NI));
%             figure(10); subplot(211); hold on; plot(VE_sample,'r');subplot(212); hold on; plot(VI_sample,'b');drawnow;
            
            [LE, LI, ll_target,sp_order,E_fired,I_fired,VE_pre,VI_pre,VEpos,VIpos] = ...
                Micro_solver_MFE_from_IFMODEL(VE_sample,VI_sample,DEE,DIE,DEI,DII,vE, vI);
          
            Lt_ra(MFE_num) = dt*iteration; LE_ra(MFE_num) = length(E_fired); LI_ra(MFE_num) = length(I_fired);
            
            disp(sprintf('resolving MFE %d at time %f, P_MFE %f, LE %d LI %d ',MFE_num,Lt_ra(MFE_num),P_MFE/dt,LE_ra(MFE_num),LI_ra(MFE_num)));
             rE = transpose(histc(VEpos,Vedges)); rE = rE(1:end-1);
             rI = transpose(histc(VIpos,Vedges)); rI = rI(1:end-1); 
             
             if length(E_fired) > NE-3
                 rE = interp1(V,source,Vbins);
             end
             if length(I_fired) > NI-3
                 rI = interp1(V,source,Vbins);
             end
             rE = rE/(sum(rE)*(Vbins(2)-Vbins(1)));
             rI = rI/(sum(rI)*(Vbins(2)-Vbins(1)));
            
            vbarE = sum(V1.*rE)*(Vbins(2)-Vbins(1));
            wbarE = sum(V2 .*rE)*(Vbins(2)-Vbins(1));
            vbar3E = sum(V3 .*rE)*(Vbins(2)-Vbins(1));
            vbar4E = sum(V4 .*rE)*(Vbins(2)-Vbins(1));
            
            vbarI = sum(V1.*rI)*(Vbins(2)-Vbins(1));
            wbarI = sum(V2 .*rI)*(Vbins(2)-Vbins(1));
            vbar3I = sum(V3 .*rI)*(Vbins(2)-Vbins(1));
            vbar4I = sum(V4 .*rI)*(Vbins(2)-Vbins(1));
            rE = rE/sum(rE);
            rI = rI/sum(rI);
            
   if record_MFE_or_not         
            fprintf(fid,'%16.4e    %16.4e     %16.4e   %16.4e     %16.4e\n', t,0,0,LE,LI);
   end
            
            mI =0; mE=0;
%             gammaE = [1,vbarE,wbarE,vbar3E,vbar4E];
%             gammaI = [1,vbarI,wbarI,vbar3I,vbar4I];
%             [gTI,gTE] = get_gT(Num_P,mY,TD,mE,mI,gL);
%             [muI,muE] = get_mu(Num_P,mY,TD,mE,mI,vE,vI,gTE,gTI,gL,vL);
%             [abcI,abcE] = get_coeff_sigma(Num_P,mY,TD,mE,mI,vE,vI,gTE,gTI);
%             [FPgammaI,FPgammaE] = get_gamma(Num_P,mY,TD,mE,mI,gTE,gTI);
%             
%             fiE = abs([1,vbarE,wbarE,vbar3E,vbar4E]');
%             fiI = abs([1,vbarI,wbarI,vbar3I,vbar4I]');
%             [PIq,PEq,sumI,sumE] = get_density(V',abcE,abcI,muE,muI,VR,vT,FPgammaI,FPgammaE);

            if moment2
                F = fiE(2:3);FI = fiI(2:3);
            else
                F = fiE(2:end);FI = fiI(2:end);
            end
%             
%             if moment2
%                 La0 = 0*gammaE(1:3)';
%                 LaI0 = 0*gammaI(1:3)';
%             else
%                 La0 = 0*gammaE(1:end)';
%                 LaI0 = 0*gammaI(1:end)';
%             end
            
%             [La1] = fminsearch(@(La)optfun(F,V,La,PEq,fin,1),La0,options);
%             [LaI1] = fminsearch(@(LaII)optfun(FI,V,LaII,PIq,fin,1),LaI0,options);
%             
%             La0 = real(La1);
%             LaI0 = real(LaI1);
            
        end %% end of if((local_pevent_d = rand(1))<local_event) %%
    end %%  end of if (MFE_COMPUT_USED) %%
    
    if dtbin_record_flag;
        dtbin_ij = 1 + floor(iteration/dtperbin);
        mEbin_ra(dtbin_ij) = mEbin_ra(dtbin_ij) + (1-MFE_flag)*mE_ra(1+iteration)*NE*dt + MFE_flag*LE_ra(MFE_num);
        mIbin_ra(dtbin_ij) = mIbin_ra(dtbin_ij) + (1-MFE_flag)*mI_ra(1+iteration)*NI*dt + MFE_flag*LI_ra(MFE_num);
        xEbin_ra(dtbin_ij) = xEbin_ra(dtbin_ij) + (1-MFE_flag)*psample(mE_ra(1+iteration)*NE*dt) + MFE_flag*LE_ra(MFE_num);
        xIbin_ra(dtbin_ij) = xIbin_ra(dtbin_ij) + (1-MFE_flag)*psample(mI_ra(1+iteration)*NI*dt) + MFE_flag*LI_ra(MFE_num);
        P_MFEbin_ra(dtbin_ij) = P_MFEbin_ra(dtbin_ij) + P_MFE_ra(1+iteration)*dt;
    end;% if dtbin_record_flag;
    
    if plot_flag;
        subplot(2,2,1); hold on; if mod(iteration,512)==0; plot(Vbins,rE,'r-',Vbins,rI,'b-'); end; hold off;
    end;%if plot_flag;
    
    t_sum = t_sum+dt;
    
    counter_firing_step = 1+counter_firing_step;

    sum_mE = mE + sum_mE;sum_mI = mI + sum_mI;        
    
    if(counter_firing_step*dt >= 1.0)

        if density_plot_or_not
            filename_rec2 =  [catalog_head1,catalog_str,var_fn2,'_',num2str(density_record_counter),'.txt'];
            fid2 = fopen(filename_rec2, 'wt');
            
            lnv = length(V);
            for i = 1:5:lnv
                fprintf(fid2,'%16.5e    %16.5e    %16.5e\n', V(i), RvE(i), RvI(i));
            end
            fclose(fid2);
            density_record_counter = density_record_counter + 1;
        end
        if record_MFE_or_not        
            
        mE_pn1 = sum_mE/counter_firing_step;
        mI_ln1 = sum_mI/counter_firing_step;
        fprintf(fid,'%16.4e    %16.4e     %16.4e   %16.0e     %16.0e\n', t, mE_pn1,mI_ln1,0,0);
        fprintf(fid1,'%16.4e    %16.4e     %16.4e   %16.4e     %16.4e    %16.4e    %16.4e     %16.4e   %16.4e\n', t, vbarE,wbarE,vbar3E,vbar4E,vbarI,wbarI,vbar3I,vbar4I);
        sum_mE = 0; sum_mI = 0.0; counter_firing_step = 0;
        end

    end
end
if record_MFE_or_not
fclose(fid);
fclose(fid1);
end
figure(1);
subplot(211); hold on;
plot(V(1:2:end),PEq(1:2:end),'k');
subplot(212); hold on;
plot(V(1:2:end),PIq(1:2:end),'k');


if plot_flag;
    xlim([Vedges(1) Vedges(end)]);
    subplot(2,2,2); plot(Vbins,rE,'r.-',Vbins,rI,'b.-');
    subplot(2,2,[3 4]); plot(t_ra,mE_ra,'r.-',t_ra,mI_ra,'b.-',t_ra,P_MFE_ra,'g.-');
    %if plot_flag; print('-depsc',sprintf('%s_FIG_A.eps',filename_base)); end;
end;%if plot_flag;

plot_flag=0;
if plot_flag;
    figure;
    plot(Vbins,rE,'r-',Vbins,rI,'b-');
    xlim([Vedges(j_source) Vedges(end)]);
    %if plot_flag; print('-depsc',sprintf('%s_FIG_B.eps',filename_base)); end;
end;%if plot_flag;

plot_flag=0;
if plot_flag & dt_record_flag;
    [rtmp,ctmp] = size(rE_ra); j_source = (rtmp+1)/2;
    subplot(4,1,1);imagesc(rE_ra(end:-1:j_source,:)*sparse(1:ctmp,1:ctmp,1./sum(rE_ra,1)),[0 4/1024]);
    [rtmp,ctmp] = size(rI_ra); j_source = (rtmp+1)/2;
    subplot(4,1,2);imagesc(rI_ra(end:-1:j_source,:)*sparse(1:ctmp,1:ctmp,1./sum(rI_ra,1)),[0 4/1024]);
    subplot(4,1,3); plot(t_ra,P_MFE_ra,'g-'); xlim([min(t_ra) max(t_ra)]);
    subplot(4,1,4);
    hold on;
    plot(t_ra,mE_ra,'r-',t_ra,mI_ra,'b-');
    l = line([Lt_ra;Lt_ra],[zeros(size(LE_ra));LE_ra]/NE); set(l,'LineWidth',1,'Color',[1 0 0]);
    l = line([Lt_ra;Lt_ra],[zeros(size(LI_ra));LI_ra]/NI); set(l,'LineWidth',3,'Color',[0 0 1]);
    xlim([min(t_ra) max(t_ra)]);
    hold off;
end;%if plot_flag & dt_record_flag;

plot_flag=1;
nsec_to_plot=1;
if plot_flag & dtbin_record_flag;
    figure;
    tij=max(1,(TMAX-1024*nsec_to_plot)/tbinsize):TMAX/tbinsize;
    [rtmp,ctmp] = size(rEbin_ra); j_source = (rtmp+1)/2;
    subplot(5,1,1);imagesc(rEbin_ra(end:-1:j_source,tij)*sparse(1:length(tij),1:length(tij),1./sum(rEbin_ra(end:-1:j_source,tij),1)),[0 4/1024]); ylabel('VE');
    set(gca,'YTick',[1 j_source]);set(gca,'YTickLabel',{'VT','VR'});
    [rtmp,ctmp] = size(rIbin_ra); j_source = (rtmp+1)/2;
    subplot(5,1,2);imagesc(rIbin_ra(end:-1:j_source,tij)*sparse(1:length(tij),1:length(tij),1./sum(rIbin_ra(end:-1:j_source,tij),1)),[0 4/1024]); ylabel('VI');
    set(gca,'YTick',[1 j_source]);set(gca,'YTickLabel',{'VT','VR'});
    subplot(5,1,3);
    hold on;
    l=stairs(tbin_ra(tij),VEavgbin_ra(tij),'r-'); set(l,'LineWidth',2);
    l=stairs(tbin_ra(tij),VEavgbin_ra(tij)+VEstdbin_ra(tij),'r:'); set(l,'LineWidth',1);
    l=stairs(tbin_ra(tij),VEavgbin_ra(tij)-VEstdbin_ra(tij),'r:'); set(l,'LineWidth',1);
    l=stairs(tbin_ra(tij),VIavgbin_ra(tij),'b-'); set(l,'LineWidth',2);
    l=stairs(tbin_ra(tij),VIavgbin_ra(tij)+VIstdbin_ra(tij),'b:'); set(l,'LineWidth',1);
    l=stairs(tbin_ra(tij),VIavgbin_ra(tij)-VIstdbin_ra(tij),'b:'); set(l,'LineWidth',1);
    xlim([min(tbin_ra(tij)) max(tbin_ra(tij))]);
    ylim([VR vT]); ylabel('Vavg');
    set(gca,'YTick',[0 1]);set(gca,'YTickLabel',{'VR','VT'});
    hold off;
    subplot(5,1,4); stairs(tbin_ra(tij),P_MFEbin_ra(tij),'g-'); xlim([min(tbin_ra(tij)) max(tbin_ra(tij))]); ylabel('P/dt');
    subplot(5,1,5); hold on; stairs(tbin_ra(tij),xEbin_ra(tij),'r-'); stairs(tbin_ra(tij),xIbin_ra(tij),'b-'); xlim([min(tbin_ra(tij)) max(tbin_ra(tij))]); ylabel('#spk'); hold off;
    print('-depsc',sprintf('%s_JW_full_FIG_A.eps',filename_base));
    print('-djpeg',sprintf('%s_JW_full_FIG_A.jpg',filename_base));
end;%if plot_flag & dtbin_record_flag;

plot_flag=1;
if plot_flag & dtbin_record_flag;
    figure;
    subplot(2,2,1);
    hold on;
    rEtmp = mean(rEbin_ra,2); l=stairs(Vbins,rEtmp,'r-'); set(l,'LineWidth',2);
    rItmp = mean(rIbin_ra,2); l=stairs(Vbins,rItmp,'b-'); set(l,'LineWidth',2);
    xlim([Vbins(j_source) Vbins(end)]); %ylim([0 0.005]);
    hold off;
    subplot(2,2,2);
    hold on;
    hEtmp = hist(mEbin_ra,[1:1.5*NE]); l=plot(log2([1:1.5*NE]),log2(1+hEtmp),'r-'); set(l,'LineWidth',2);
    hItmp = hist(mIbin_ra,[1:1.5*NI]); l=plot(log2([1:1.5*NI]),log2(1+hItmp),'b-'); set(l,'LineWidth',2);
    %hEtmp = hist(mEbin_ra,[1:1.5*NE]); l=loglog(([1:1.5*NE]),(1+hEtmp),'r-'); set(l,'LineWidth',2);
    %hItmp = hist(mIbin_ra,[1:1.5*NI]); l=loglog(([1:1.5*NI]),(1+hItmp),'b-'); set(l,'LineWidth',2);
    hold off;
    subplot(2,2,[3,4]);
    h = spectrum.mtm; Fs = 1000*1/tbinsize; hpsd = psd(h,(VEavgbin_ra*NE + VIavgbin_ra*NI)/(NE+NI),'Fs',Fs); plot(hpsd);
    print('-depsc',sprintf('%s_JW_full_FIG_B.eps',filename_base));
    print('-djpeg',sprintf('%s_JW_full_FIG_B.jpg',filename_base));
end;%if plot_flag & dtbin_record_flag;

% save(sprintf('%s_data.mat',filename_base));



function output = getsamples(Vedges,rho,Nsamples)
rho = [0;rho(:)]/sum(rho);
L = length(rho);
F = cumsum(rho);
[Fv,Fi,Fj] = unique(F,'first');
output = interp1(F(Fi),Vedges(Fi),rand(Nsamples,1));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function output = psample(ldt);
% draws an event count from a Poisson process with rate lambda over time dt;
if ldt>5; output = max(0,round(ldt + sqrt(ldt)*randn()));
else;
    kra = 0:14;
    pra = [-1 , cumsum((ldt.^kra).*exp(-ldt)./factorial(kra)) , 2];
    output = max(find(~(min(rand(),pra(end-1))<=pra)))-1;
end;% if ldt>7;

function [vbarE1,vbarI1,wbarE1,wbarI1,vbar3E1,vbar3I1,vbar4E1,vbar4I1] ...
    = solveVbarWbar4_vol_dep(dt,vbarE, vbarI, wbarE, wbarI,vbar3E, vbar3I,vbar4E, vbar4I,muE,muI,abcE,abcI,mE,mI,FPgammaI,FPgammaE,gTI,gTE);
%% Here assume thatn vT =1; so the coefficient of mE and mI is 1, we do not multiply them ...
aE = abcE(1);bE = abcE(2); cE = abcE(3); VT =1;
aI = abcI(1);bI = abcI(2); cI = abcI(3);
dtgTE =dt*gTE;dtgTI =dt*gTI;
vbarE1 = vbarE + dtgTE*(- VT*mE/gTE - (1.0-aE-FPgammaE)*vbarE + muE + bE/2.0);
vbarI1 = vbarI + dtgTI*(- VT*mI/gTI - (1.0-aI-FPgammaI)*vbarI + muI + bI/2.0);

wbarE1 = wbarE + dtgTE*(- VT^2*mE/gTE - (2.0-3.0*aE-FPgammaE)*wbarE + 2.0*(muE+bE)*vbarE +cE);
wbarI1 = wbarI + dtgTI*(- VT^2*mI/gTI - (2.0-3.0*aI-FPgammaI)*wbarI + 2.0*(muI+bI)*vbarI +cI);

vbar3E1 = vbar3E + dtgTE*(- VT^3*mE/gTE - (3.0-6*aE-FPgammaE)*vbar3E + 3*(muE+1.5*bE)*wbarE + 3*cE*vbarE);
vbar3I1 = vbar3I + dtgTI*(- VT^3*mI/gTI - (3.0-6*aI-FPgammaI)*vbar3I + 3*(muI+1.5*bI)*wbarI + 3*cI*vbarI);

vbar4E1 = vbar4E + dtgTE*(- VT^4*mE/gTE - (4.0-10*aE-FPgammaE)*vbar4E +4*(muE+2*bE)*vbar3E + 6*cE*wbarE);
vbar4I1 = vbar4I + dtgTI*(- VT^4*mI/gTI - (4.0-10*aE-FPgammaI)*vbar4I +4*(muI+2*bI)*vbar3I + 6*cI*wbarI);






function [f,g] = optfun(mu,x,lambda0,PEq,fin,gamma)
% optfun(MU,X,LAMBDA0)
% This program calculates the Lagrange Multipliers of the ME
% probability density functions p(x) from the knowledge of the
% N moment contstraints in the form:
% E{x^n}=mu(n) n=0:N with mu(0)=1.
%
% MU is a table containing the constraints MU(n),n=1:N.
% X is a table defining the range of the variation of x.
% LAMBDA0 is a table containing the first estimate of the LAMBDAs.
% (This argument is optional.)
% LAMBDA is a table containing the resulting Lagrange parameters.
% P is a table containing the resulting pdf p(x).
% ENTR is a table containing the entropy values at each
% iteration.
% f is the value of the function(lambda)
% g is the gradiant of f

mu=mu(:); mu=[1;mu]; % add mu(0)=1
x=x(:);  % x axis
dx=x(2)-x(1);
lambda=lambda0(:);
N=length(lambda);
p = PEq.*exp((fin(:,1:N)*lambda));
f = dx*sum(p) - mu'*lambda;
if nargout>1
    G=zeros(N,1); % Calculate Gn
    for n=1:N
        G(n) = trapz(x, fin(:,n).*p);
    end
    g=G(1:N) - mu;
end

function [muI,muE] = get_mu(N,mY,TD,mE,mI,vE,vI,gTE,gTI,gL,vL)
%%%% D = [DII,DIE,DIY;DEI,DEE,DEY];
muI = gL*vL + mY(1)*TD(1,3)*(1.0 - TD(1,3)^2)*vE + mE*N(2)*TD(1,2)*(1.0 - TD(1,2)^2)*vE + mI*N(1)*TD(1,1)*(1.0 - TD(1,1)^2)*vI;
muE = gL*vL + mY(2)*TD(2,3)*(1.0 - TD(2,3)^2)*vE + mE*N(2)*TD(2,2)*(1.0 - TD(2,2)^2)*vE + mI*N(1)*TD(2,1)*(1.0 - TD(2,1)^2)*vI;
muI = muI/gTI; muE = muE/gTE;

function [gammaI,gammaE] = get_gamma(N,mY,D,mE,mI,gTE,gTI)
%%%% D = [DII,DIE,DIY;DEI,DEE,DEY];
NI = N(1); NE = N(2);
mIY = mY(1); mEY = mY(2);
DII = D(1,1); DIE = D(1,2); DIY = D(1,3); DEI = D(2,1); DEE = D(2,2); DEY = D(2,3);

gammaI = (mIY*DIY^3 + NE*mE*DIE^3 + NI*mI*DII^3)/gTI;
gammaE =  (mEY*DEY^3 + NE*mE*DEE^3 + NI*mI*DEI^3)/gTE;


function [gTI,gTE] = get_gT(N,mY,TD,mE,mI,gL)
%%%% D = [DII,DIE,DIY;DEI,DEE,DEY];
gTI = gL + mY(1)*TD(1,3)*(1.0-TD(1,3)^2) + mE*N(2)*TD(1,2)*(1.0-TD(1,2)^2) + mI*N(1)*TD(1,1)*(1.0-TD(1,1)^2);
gTE = gL + mY(2)*TD(2,3)*(1.0-TD(2,3)^2) + mE*N(2)*TD(2,2)*(1.0-TD(2,2)^2) + mI*N(1)*TD(2,1)*(1.0-TD(2,1)^2);

function [abcI,abcE] = get_coeff_sigma(N,mY,TD,mE,mI,vE,vI,gTE,gTI)
%%%% D = [DII,DIE,DIY;DEI,DEE,DEY];
aI = mY(1)*TD(1,3)^2*(1.0 + TD(1,3)) + mE*N(2)*TD(1,2)^2 *(1.0 + TD(1,2)) + mI*N(1)*TD(1,1)^2*(1.0 + TD(1,1));
bI = -2.0*mY(1)*TD(1,3)^2*(1.0+TD(1,3))*vE - 2.0*mE*N(2)*TD(1,2)^2*(1.0+TD(1,2))*vE - 2.0*mI*N(1)*TD(1,1)^2*(1.0+TD(1,1))*vI;
cI =  mY(1)*TD(1,3)^2*(1.0+TD(1,3))*vE^2 + mE*N(2)*TD(1,2)^2*(1.0+TD(1,2))*vE^2 + mI*N(1)*TD(1,1)^2*(1.0+TD(1,1))*vI^2;
abcI = [aI,bI,cI]/gTI;

aE = mY(2)*TD(2,3)^2*(1.0+TD(2,3)) + mE*N(2)*TD(2,2)*TD(2,2)*(1.0+TD(2,2)) + mI*N(1)*TD(2,1)^2*(1.0+TD(2,1));
bE = -2.0*mY(2)*TD(2,3)^2*(1.0+TD(2,3))*vE - 2.0*mE*N(2)*TD(2,2)^2*(1.0+TD(2,2))*vE - 2.0*mI*N(1)*TD(2,1)^2*(1.0+TD(2,1))*vI;
cE =  mY(2)*TD(2,3)^2*(1.0+TD(2,3))*vE^2 + mE*N(2)*TD(2,2)^2*(1.0+TD(2,2))*vE^2 + mI*N(1)*TD(2,1)^2*(1.0+TD(2,1))*vI^2;
abcE = [aE,bE,cE]/gTE;



function D1 = Tanslate_S_to_s(D);
%%%% D = [DII,DIE,DIY;DEI,DEE,DEY];
D = abs(D);
D1 = [exp(D(1,1))-1,exp(D(1,2))-1,exp(D(1,3))-1;exp(D(2,1))-1,exp(D(2,2))-1,exp(D(2,3))-1];



function [rhoI,rhoE,sumI,sumE] = get_density(v,abcE,abcI,muE,muI,vR,vT,gammaI,gammaE)
K = 10;
aE = abcE(1);bE = abcE(2); cE = abcE(3);
aI = abcI(1);bI = abcI(2); cI = abcI(3);
VE = 14/3;
coe= 0;%% coe = b^2-4ac;
aEver = 1/aE;  coe1 = (2*bE)/aE +4*muE;
aIver = 1/aI; coeI1 = (2*bI)/aI + 4*muI;


ind = find(v<vR);  J0= ind(end);
ind_I = find(v<-0.4);  I_idx = ind_I(end);

a =0; c =1;
[L,l] = mateleg(K);L=L(1:K,1:K);
Lv = makeleg(K);Lv=Lv(1:K,2:K+1);
[lv,ln] = legintmat(K,a,c);

for jj=1:length(ln)
    fvals(jj) = quad(@(x)sfn(x,coe1,coe,aE,bE,cE,aEver,ln(jj),gammaE),ln(jj),vT);
end;
coefs = inv(transpose(L))*(fvals(:));
p = (Lv'*coefs(:))';
pvals01=polyval(p,(v(J0:end)-(v(J0)+v(end))/2)/((v(end)-v(J0))/2));

a =-1; c =0;
[L,l] = mateleg(K);L=L(1:K,1:K);
Lv = makeleg(K);Lv=Lv(1:K,2:K+1);
[lv,ln] = legintmat(K,a,c);

for jj=1:length(ln)
    fvals(jj) = quad(@(x)sfn(x,coe1,coe,aE,bE,cE,aEver,ln(jj),gammaE),vR,vT);
end;

coefs = inv(transpose(L))*(fvals(:));
p = (Lv'*coefs(:))';
pvals00=polyval(p,(v(1:J0-1)-(v(1)+v(J0-1))/2)/((v(J0-1)-v(1))/2));
pvals = [pvals00,pvals01];
pvals(find(pvals<0)) = 0;
pvals(1:I_idx) = 0;
sumE = (v(2)-v(1))*sum(pvals);
rhoE = pvals/sumE;

a =0; c =1;
[L,l] = mateleg(K);L=L(1:K,1:K);
Lv = makeleg(K);Lv=Lv(1:K,2:K+1);
[lv,ln] = legintmat(K,a,c);

for jj=1:length(ln)
    fvals(jj) = quad(@(x)sfn(x,coeI1,coe,aI,bI,cI,aIver,ln(jj),gammaI),ln(jj),vT);
end;
coefs = inv(transpose(L))*(fvals(:));
p = (Lv'*coefs(:))';
pvals01=polyval(p,(v(J0:end)-(v(J0)+v(end))/2)/((v(end)-v(J0))/2));

a =-1; c =0;
[L,l] = mateleg(K);L=L(1:K,1:K);
Lv = makeleg(K);Lv=Lv(1:K,2:K+1);
[lv,ln] = legintmat(K,a,c);

for jj=1:length(ln)
    fvals(jj) = quad(@(x)sfn(x,coeI1,coe,aI,bI,cI,aIver,ln(jj),gammaI),vR,vT);
end;

coefs = inv(transpose(L))*(fvals(:));
p = (Lv'*coefs(:))';
pvals00=polyval(p,(v(1:J0-1)-(v(1)+v(J0-1))/2)/((v(J0-1)-v(1))/2));
pvals = [pvals00,pvals01];
pvals(find(pvals<0)) = 0;
pvals(1:I_idx) = 0;
sumI = (v(2)-v(1))*sum(pvals);
rhoI = pvals/sumI;

rhoE = rhoE'; rhoI = rhoI';
%     figure(1);hold on;
% plot(v,rhoE,'r',v,rhoI,'b');
%
% %     plot(ln,fvals,'bx');
% %     plot(ln,0,'bx');
%     xlabel('x');
%     ylabel('function value');
%     title('function in red, polynomial in blue, nodes at *');
%     hold off;
%     disp('the calculated integral of your function is');
%




function Legpoly_vec = makeleg(K);
% This function generates a matrix Legpoly_vec
% such that Legpoly_vec(k,:) is the coefficients of the kth legendre polynomial
% Warning: the coefficients are listed in "polynomial order" for use in matlab poly class

L{1}=[1];
L{2}=[1 0];
for index=1:K-1
    L{index+2} = ((2*index+1)*conv([1 0],L{index+1}) - index*[0 0 L{index}])/(index+1);
end;
Legpoly_vec=zeros(K+1);
for index=1:K+1
    Legpoly_vec(index,:)=[zeros(1,K+1-index) L{index}];
end;

function [L,l] = mateleg(K)

% L = matrix whose components L(j,k) are jth Legendre polynomial evaluated at kth legendre node
% l = vector of legendre nodes

Legpoly_vec = makeleg(K);
l=roots(Legpoly_vec(K+1,:));l=sort(transpose(l(:)));
for index1=1:K
    for index2=1:K
        L(index1,index2) = polyval(Legpoly_vec(index1,:),l(index2));
    end;
end;

function [leg_vector,leg_nodes] = legintmat(K,a,c)

% This function calculates the weights (leg_vector) and nodes (leg_nodes)
% for legendre integration of degree K on interval [a,c]

Legpoly_vec = makeleg(K);
Legpoly_int = zeros(1,K);
for index=1:K
    tempoly = polyint(Legpoly_vec(index,:));
    Legpoly_int(index) = polyval(tempoly,1)-polyval(tempoly,-1);
end;
[L,l]=mateleg(K);
L_inv = L\eye(K);
leg_vector = ((c-a)/2) * Legpoly_int*transpose(L_inv);
leg_nodes = l*(c-a)/2 + (c+a)/2;

function [T,t] = matetsch(K)

% K = number of tschebyscheff polynomials to construct
% T = matrix of values T(i,j) = Ti(tj)
% where Ti = ith tschebyscheff polynomial,
% tj = jth root of TK

t=cos((2*K-2*[1:K]+1)*pi/(2*K));
T(1,:)=linspace(1,1,length(t));
T(2,:)=t;
for j1=2:K
    for j2=1:length(t)
        T(j1+1,j2)=2*t(j2)*T(j1,j2)-T(j1-1,j2);
    end;
end;

function Tschpoly_vec = maketsch(K);
% this function produces a matrix such that
% Tschpoly_vec(k,:) = coefficients of the kth tschebyscheff polynomial
% Warning: The coefficients are listed in "polynomial order" for use as matlab poly class

Tschpoly{1}=[1];
Tschpoly{2}=[1 0];
for index=1:K+1-2
    Tschpoly{index+2} = conv([2 0],Tschpoly{index+1}) - [0 0 Tschpoly{index}];
end;
Tschpoly_vec=zeros(K+1);
for index=1:K+1
    Tschpoly_vec(index,K+1-index+1:K+1)=Tschpoly{index};
end;

function [tsch_vector,tsch_nodes] = tschintmat(K,a,c)

% This function establishes the tschebysheff nodes of integration as well as the corresponding integration vector
% for degree K tschebysheff interpolation/integration on the interval [a,c]

tsch_nodes=cos((2*K-2*[1:K]+1)*pi/(2*K));
T(1,:)=linspace(1,1,K);
T(2,:)=tsch_nodes;
for j1=2:K-1
    for j2=1:K
        T(j1+1,j2)=2*tsch_nodes(j2)*T(j1,j2)-T(j1-1,j2);
    end;
end;
T_int = ~isint((1:K)./2)./((1:K).*((1:K)-2));T_int(2)=0;
T_eye=2*eye(K); T_eye(1,1)=1;
tsch_vector = ((a-c)/K)*T_int*T_eye*T;
tsch_nodes = (c-a)/2 * tsch_nodes + (c+a)/2;


function output = polyint(input)

% this function finds the indefinite integral of a polynomial

input=transpose(input(:));
for index=1:length(input);
    output(index) = input(index)/(length(input)-index+1);
end;
output = [output 0];

function output = isint(input)

% this is just a lame function that tests whether or not the input is an integer

output = floor(input)==input;





function val = sfn(v,coe1,coe,aE,bE,cE,aEver,v0,gamma);
% if coe < 10^(-10)
val = exp(gamma*(1-v)).*power((aE*v.^2+bE*v+cE)/(aE*v0^2+bE*v0+cE),aEver) .* exp(-coe1./(2.0*aE*v0+bE) + coe1./((2*aE*v + bE))) ./(aE*v.^2+bE*v+cE);
% else
% val = exp(gamma*(1-v)).*power((aE*v.^2+bE*v+cE)/(aE*v0^2+bE*v0+cE),aEver) .* exp(-coe1*atan((2*aE*v + bE)/coe) + coe1*atan((2*aE*v0 + bE)/coe))./(aE*v.^2+bE*v+cE);
% end



