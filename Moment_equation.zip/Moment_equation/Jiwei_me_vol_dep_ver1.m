function [rE,rI,nbins,dV,Vedges,Vbins,t_ra,mE_ra,mI_ra,P_MFE_ra,rE_ra,rI_ra,Lt_ra,LE_ra,LI_ra,tbin_ra,mEbin_ra,mIbin_ra,xEbin_ra,...
    xIbin_ra,P_MFEbin_ra,rEbin_ra,rIbin_ra,VEavgbin_ra,VEstdbin_ra,VIavgbin_ra,VIstdbin_ra] ...
    = Jiwei_me_vol_dep_ver1(N,mY,D,TMAX,dt,VE_Value, VI_Value);
% conditioned to not produce mfes during fB, with MFEs added as required. ;
% run with: ;
%{
  [nbins,dV,Vedges,Vbins,t_ra,mE_ra,mI_ra,P_MFE_ra,rE_ra,rI_ra,Lt_ra,LE_ra,LI_ra,tbin_ra,mEbin_ra,mIbin_ra,xEbin_ra,xIbin_ra,P_MFEbin_ra,rEbin_ra,rIbin_ra,VEavgbin_ra,VEstdbin_ra,VIavgbin_ra,VIstdbin_ra] = Jiwei_me_ver3([24 32]*1,[1.8 2.4],[0.25 0.30 0.05 ; 0.55 0.50 0.05],1024,0.01);
 %}

TAU_V=20;VT=1;VR=0;%VE_Value = 14.0/3.0; VI_Value = -2/3;
if isempty(TMAX); TMAX = 1024; end;
if isempty(dt); dt = 0.01; end;

if isempty(N); N = [24 32]*1; end;
NI = N(1); NE = N(2);

if isempty(mY); mY = [1.8 2.4]; end;
mIY = mY(1); mEY = mY(2);

% DQR are coupling strengths from R to Q;
if isempty(D); D = [0.25 0.30 0.05 ; 0.55 0.50 0.05 ]; end;
DII = D(1,1); DIE = D(1,2); DIY = D(1,3); DEI = D(2,1); DEE = D(2,2); DEY = D(2,3);
% tagline = sprintf('N_%.3d_%.3d_mY_%.2d_%.2d_D_%.2d_%.2d_%.2d_%.2d_T%.3d_dt%.3d',NI,NE,round(10*mIY),round(10*mEY),round(100*DII),round(100*DIE),round(100*DEI),round(100*DEE),round(TMAX/1024),round(dt*1000));
% tagline = sprintf('N_%.3d_%.3d_mY_%.2d_%.2d_D_%.2d_%.2d_%.2d_%.2d_T%.3d_dt%.3d',NI,NE,round(1000*mIY),round(1000*mEY),round(1000*DII),round(1000*DIE),round(1000*DEI),round(1000*DEE),round(TMAX/1024),round(dt*1000));
tagline = sprintf('N_%.3d_%.3d_mY_%.2d_%.2d_D_%.2d_%.2d_%.2d_%.2d_T%.3d_dt%.3d_VE%.3d_VI%.3d',...
    NI,NE,round(10000*mIY),round(10000*mEY),round(10000*DII),round(10000*DIE),round(10000*DEI),round(10000*DEE),round(TMAX/1024),round(dt*1000),round(10000*VE_Value),round(10000*VI_Value));
D(:,1:2) = inv(diag(N))*D(:,1:2);
DII = D(1,1); DIE = D(1,2); DIY = D(1,3); DEI = D(2,1); DEE = D(2,2); DEY = D(2,3);

filename_base = sprintf('me3_%s',tagline); disp(filename_base);

nbins =1025; nbinp = nbins+1; dV = (VT-(VR-VT))/nbins; Vedges = linspace(VR-VT,VT,nbinp); Vbins = (Vedges(1:end-1)+Vedges(2:end))/2;
j_source = (nbins+1)/2; rho_source = zeros(nbins,1); rho_source(j_source)=1; 
L_flow = get_L_flow(dt,Vedges);
LEY_kick = get_L_kick(DEY,Vedges,VE_Value); lEY_fire = 1-transpose(sum(LEY_kick,1)); lEY_undr = transpose(sum(LEY_kick,1));
LEE_kick = get_L_kick(DEE,Vedges,VE_Value); lEE_fire = 1-transpose(sum(LEE_kick,1)); lEE_undr = transpose(sum(LEE_kick,1));
LEI_kick = get_L_kick(DEI,Vedges,VI_Value); lEI_fire = 1-transpose(sum(LEI_kick,1)); lEI_undr = transpose(sum(LEI_kick,1));
LIY_kick = get_L_kick(DIY,Vedges,VE_Value); lIY_fire = 1-transpose(sum(LIY_kick,1)); lIY_undr = transpose(sum(LIY_kick,1));
LIE_kick = get_L_kick(DIE,Vedges,VE_Value); lIE_fire = 1-transpose(sum(LIE_kick,1)); lIE_undr = transpose(sum(LIE_kick,1));
LII_kick = get_L_kick(DII,Vedges,VI_Value); lII_fire = 1-transpose(sum(LII_kick,1)); lII_undr = transpose(sum(LII_kick,1));
rE = rho_source; mEE_net = 0; mEI_net=0;
rI = rho_source; mIE_net = 0; mII_net=0;
% gamma_E = dot(lEE_undr,rE).^(NE-1);
gamma_E = dot(lEE_undr,rE).^(NE-1)*dot(lIE_undr,rI).^(NI);
gamma_I = 1;
mE_single=0;
P_MFE = dt*NE*mE_single*(1 - dot(lEE_undr,rE).^(NE-1)*dot(lIE_undr,rI).^(NI));

plot_flag=0; dt_record_flag=0; 
dtbin_record_flag=1; tbinsize = 1.0; dtperbin = floor(tbinsize/dt); tbinsize=dtperbin*dt;
iteration_max=dtperbin*TMAX/tbinsize; 
MFE_num=1; Lt_ra(1)=0; LE_ra(1)=0; LI_ra(1)=0;
t_sum=0; t_ra = zeros(iteration_max+1,1);
mE_ra = zeros(iteration_max+1,1);
mI_ra = zeros(iteration_max+1,1);

if dt_record_flag;
rE_ra = zeros(nbins,iteration_max);
rI_ra = zeros(nbins,iteration_max);
else;%if dt_record_flag;
rE_ra = [];
rI_ra = [];
end;%if dt_record_flag;

 rEbin_ra = [];
 rIbin_ra = [];

if dtbin_record_flag;
tbin_ra = zeros(iteration_max/dtperbin,1);
mEbin_ra = zeros(iteration_max/dtperbin,1);
mIbin_ra = zeros(iteration_max/dtperbin,1);
xEbin_ra = zeros(iteration_max/dtperbin,1);
xIbin_ra = zeros(iteration_max/dtperbin,1);
P_MFEbin_ra = zeros(iteration_max/dtperbin,1);
rEbin_ra = zeros(nbins,iteration_max/dtperbin);
rIbin_ra = zeros(nbins,iteration_max/dtperbin);
VEavgbin_ra = zeros(iteration_max/dtperbin,1);
VEstdbin_ra = zeros(iteration_max/dtperbin,1);
VIavgbin_ra = zeros(iteration_max/dtperbin,1);
VIstdbin_ra = zeros(iteration_max/dtperbin,1);
else;%if dtbin_record_flag;
tbin_ra = [];
mEbin_ra = [];
mIbin_ra = [];
xEbin_ra = [];
xIbin_ra = [];
P_MFEbin_ra = [];
rEbin_ra = [];
rIbin_ra = [];
VEavgbin_ra = []; 
VEstdbin_ra = [];
VIavgbin_ra = [];
VIstdbin_ra = [];
end;%;%if dtbin_record_flag;
sum_mE = 0; sum_mI = 0; counter_firing_step = 0;
var_fn = ['MFE_',filename_base,'.txt'];
fid = fopen(var_fn, 'wt');

for iteration=0:iteration_max-1;
   
t_ra(1+iteration) = t_sum;
% t_sum
[VEavg_ra(1+iteration),VEstd_ra(1+iteration)] = histstats(rE,Vbins);
[VIavg_ra(1+iteration),VIstd_ra(1+iteration)] = histstats(rI,Vbins);
if dt_record_flag; rE_ra(:,1+iteration) = rE; rI_ra(:,1+iteration) = rI; end;
if dtbin_record_flag; 
dtbin_ij = 1 + floor(iteration/dtperbin);
tbin_ra(dtbin_ij) = tbin_ra(dtbin_ij) + dt*t_ra(1+iteration);
rEbin_ra(:,dtbin_ij) = rEbin_ra(:,dtbin_ij) + dt*rE; 
rIbin_ra(:,dtbin_ij) = rIbin_ra(:,dtbin_ij) + dt*rI; 
VEavgbin_ra(dtbin_ij) = VEavgbin_ra(dtbin_ij) + dt*VEavg_ra(1+iteration);
VEstdbin_ra(dtbin_ij) = VEstdbin_ra(dtbin_ij) + dt*VEstd_ra(1+iteration);
VIavgbin_ra(dtbin_ij) = VIavgbin_ra(dtbin_ij) + dt*VIavg_ra(1+iteration);
VIstdbin_ra(dtbin_ij) = VIstdbin_ra(dtbin_ij) + dt*VIstd_ra(1+iteration);
end;% if dtbin_record_flag;

if (rand()>P_MFE);
MFE_flag=0;
rE = L_flow*rE;
rEY_fire = dt*mEY*gamma_E*dot(lEY_fire,rE);
rEI_fire = dt*mEI_net*dot(lEI_fire,rI);
mE_ra(1+iteration) = (rEY_fire + rEI_fire)/dt;

rE = (1-dt*(mEI_net))*rE ...
     - dt*mEY*(lEY_undr.*rE) - dt*mEY*gamma_E*(lEY_fire.*rE) - dt*mEE_net*(lEE_undr.*rE) ...
     + dt*(mEY*LEY_kick*rE + mEE_net*LEE_kick*rE + mEI_net*LEI_kick*rE);
rE(j_source) = rE(j_source) + rEY_fire + rEI_fire;
rI = L_flow*rI;
rIY_fire = dt*mIY*gamma_I*dot(lIY_fire,rI); 
rII_fire = dt*mII_net*dot(lII_fire,rI);
mI_ra(1+iteration) = (rIY_fire + rII_fire)/dt;
rI = (1-dt*(mII_net))*rI ...
     - dt*mIY*(lIY_undr.*rI) - dt*mIY*gamma_I*(lIY_fire.*rI) - dt*mIE_net*(lIE_undr.*rI) ...
     + dt*(mIY*LIY_kick*rI + mIE_net*LIE_kick*rI + mII_net*LII_kick*rI);
rI(j_source) = rI(j_source) + rIY_fire + rII_fire;
% gamma_E = dot(lEE_undr,rE).^(NE-1);
gamma_E = dot(lEE_undr,rE).^(NE-1)*dot(lIE_undr,rI).^(NI);
mEE_net = (NE-1)*(rEY_fire + rEI_fire)/dt;
mIE_net = (NE-0)*(rEY_fire + rEI_fire)/dt;
mEI_net = (NI-0)*(rIY_fire + rII_fire)/dt;
mII_net = (NI-1)*(rIY_fire + rII_fire)/dt;
mE_single = (rEY_fire + rEI_fire)/dt;
P_MFE = dt*NE*mE_single*(1 - dot(lEE_undr,rE).^(NE-1)*dot(lIE_undr,rI).^(NI))
% (1 - dot(lEE_undr,rE).^(NE-1)*dot(lIE_undr,rI).^(NI))
% (1 - dot(lEE_undr,rE).^(NE-1))
% P_MFE = dt*NE*mE_single*(1-dt*mE_single)^(NE-1)*(1 - dot(lEE_undr,rE).^(NE-1)*dot(lIE_undr,rI).^(NI));
P_MFE_ra(1+iteration) = P_MFE/dt;


else;%if not (rand()>P_MFE), then resolve MFE;
MFE_flag=1;
MFE_num = MFE_num+1;
VE = transpose(getsamples(Vedges,rE,NE)); 
VI = transpose(getsamples(Vedges,rI,NI));
% [E_fired,I_fired,VEpos,VIpos] = getMFE_ifdyn(0,VE,VI,D);
[LE, LI, ll_target,sp_order,E_fired,I_fired,VE_pre,VI_pre,VEpos,VIpos] = ...
                Micro_solver_MFE_from_IFMODEL(VE,VI,DEE,DIE,DEI,DII,VE_Value, VI_Value);
            Lt_ra(MFE_num) = dt*iteration; LE_ra(MFE_num) = length(E_fired); LI_ra(MFE_num) = length(I_fired);
          
Lt_ra(MFE_num) = dt*iteration; LE_ra(MFE_num) = length(E_fired); LI_ra(MFE_num) = length(I_fired);
            fprintf(fid,'%16.4e    %16.0e     %16.0e   %16.0e     %16.0e\n', t_sum,0,0,length(E_fired),length(I_fired));
disp(sprintf('resolving MFE %d at time %f, P_MFE %f, LE %d LI %d ',MFE_num,Lt_ra(MFE_num),P_MFE/dt,LE_ra(MFE_num),LI_ra(MFE_num)));
% VEpos(E_fired)=VR; VIpos(I_fired)=VR;
rE = transpose(histc(VEpos,Vedges)); rE = rE(1:end-1); rE = rE/sum(rE);
rI = transpose(histc(VIpos,Vedges)); rI = rI(1:end-1); rI = rI/sum(rI);
% gamma_E = dot(lEE_undr,rE).^(NE-1);
gamma_E = dot(lEE_undr,rE).^(NE-1)*dot(lIE_undr,rI).^(NI);
rEY_fire = dt*mEY*gamma_E*dot(lEY_fire,rE);
rEI_fire = dt*mEI_net*dot(lEI_fire,rI);
mE_ra(1+iteration) = (rEY_fire + rEI_fire)/dt;
rIY_fire = dt*mIY*gamma_I*dot(lIY_fire,rI); 
rII_fire = dt*mII_net*dot(lII_fire,rI);
mI_ra(1+iteration) = (rIY_fire + rII_fire)/dt;
mEE_net = (NE-1)*(rEY_fire + rEI_fire)/dt;
mIE_net = (NE-0)*(rEY_fire + rEI_fire)/dt;
mEI_net = (NI-0)*(rIY_fire + rII_fire)/dt;
mII_net = (NI-1)*(rIY_fire + rII_fire)/dt;
mE_single = (rEY_fire + rEI_fire)/dt;
P_MFE = dt*NE*mE_single*(1 - dot(lEE_undr,rE).^(NE-1)*dot(lIE_undr,rI).^(NI));
P_MFE_ra(1+iteration) = P_MFE/dt;
end;%if (rand()>P_MFE);

if dtbin_record_flag; 
dtbin_ij = 1 + floor(iteration/dtperbin);
mEbin_ra(dtbin_ij) = mEbin_ra(dtbin_ij) + (1-MFE_flag)*mE_ra(1+iteration)*NE*dt + MFE_flag*LE_ra(MFE_num);
mIbin_ra(dtbin_ij) = mIbin_ra(dtbin_ij) + (1-MFE_flag)*mI_ra(1+iteration)*NI*dt + MFE_flag*LI_ra(MFE_num);
xEbin_ra(dtbin_ij) = xEbin_ra(dtbin_ij) + (1-MFE_flag)*psample(mE_ra(1+iteration)*NE*dt) + MFE_flag*LE_ra(MFE_num);
xIbin_ra(dtbin_ij) = xIbin_ra(dtbin_ij) + (1-MFE_flag)*psample(mI_ra(1+iteration)*NI*dt) + MFE_flag*LI_ra(MFE_num);
P_MFEbin_ra(dtbin_ij) = P_MFEbin_ra(dtbin_ij) + P_MFE_ra(1+iteration)*dt;
end;% if dtbin_record_flag;

if plot_flag;
 if mod(iteration,20)==0; plot(Vbins,rE,'r-',Vbins,rI,'b-'); end; drawnow;
 end;%if plot_flag;


if plot_flag;
subplot(2,2,1); hold on; if mod(iteration,512)==0; plot(Vbins,rE,'r-',Vbins,rI,'b-'); end; hold off;
end;%if plot_flag;

  counter_firing_step = 1+counter_firing_step;
    sum_mE = mE_ra(1+iteration) + sum_mE;sum_mI = mI_ra(1+iteration) + sum_mI;

t_sum = t_sum+dt;
   if(counter_firing_step*dt >= 1.0)
        mE_pn1 = sum_mE/counter_firing_step; mI_ln1 = sum_mI/counter_firing_step;
        fprintf(fid,'%16.4e    %16.4e     %16.4e   %16.0e     %16.0e\n', t_sum, mE_pn1,mI_ln1,0,0);
        sum_mE = 0; sum_mI = 0.0; counter_firing_step = 0;
    end
end;%for iteration=0:iteration_max-1;
fclose(fid);
if plot_flag;
xlim([Vedges(1) Vedges(end)]);
subplot(2,2,2); plot(Vbins,rE,'r.-',Vbins,rI,'b.-');
subplot(2,2,[3 4]); plot(t_ra,mE_ra,'r.-',t_ra,mI_ra,'b.-',t_ra,P_MFE_ra,'g.-');
%if plot_flag; print('-depsc',sprintf('%s_FIG_A.eps',filename_base)); end;
end;%if plot_flag;

plot_flag=0;
if plot_flag;
figure;
plot(Vbins,rE,'r-',Vbins,rI,'b-');
xlim([Vedges(j_source) Vedges(end)]);
%if plot_flag; print('-depsc',sprintf('%s_FIG_B.eps',filename_base)); end;
end;%if plot_flag;

plot_flag=0;
if plot_flag & dt_record_flag;
[rtmp,ctmp] = size(rE_ra); j_source = (rtmp+1)/2;
subplot(4,1,1);imagesc(rE_ra(end:-1:j_source,:)*sparse(1:ctmp,1:ctmp,1./sum(rE_ra,1)),[0 4/1024]);
[rtmp,ctmp] = size(rI_ra); j_source = (rtmp+1)/2;
subplot(4,1,2);imagesc(rI_ra(end:-1:j_source,:)*sparse(1:ctmp,1:ctmp,1./sum(rI_ra,1)),[0 4/1024]);
subplot(4,1,3); plot(t_ra,P_MFE_ra,'g-'); xlim([min(t_ra) max(t_ra)]);
subplot(4,1,4); 
hold on; 
plot(t_ra,mE_ra,'r-',t_ra,mI_ra,'b-');
l = line([Lt_ra;Lt_ra],[zeros(size(LE_ra));LE_ra]/NE); set(l,'LineWidth',1,'Color',[1 0 0]);
l = line([Lt_ra;Lt_ra],[zeros(size(LI_ra));LI_ra]/NI); set(l,'LineWidth',3,'Color',[0 0 1]);
xlim([min(t_ra) max(t_ra)]);
hold off;
end;%if plot_flag & dt_record_flag;

plot_flag=1;
nsec_to_plot=1.0;
if plot_flag & dtbin_record_flag;
figure;
tij=max(1,(TMAX-1024*nsec_to_plot)/tbinsize):TMAX/tbinsize;
[rtmp,ctmp] = size(rEbin_ra); j_source = (rtmp+1)/2;
subplot(5,1,1);imagesc(rEbin_ra(end:-1:j_source,tij)*sparse(1:length(tij),1:length(tij),1./sum(rEbin_ra(end:-1:j_source,tij),1)),[0 4/1024]); ylabel('VE');
set(gca,'YTick',[1 j_source]);set(gca,'YTickLabel',{'VT','VR'});
[rtmp,ctmp] = size(rIbin_ra); j_source = (rtmp+1)/2;
subplot(5,1,2);imagesc(rIbin_ra(end:-1:j_source,tij)*sparse(1:length(tij),1:length(tij),1./sum(rIbin_ra(end:-1:j_source,tij),1)),[0 4/1024]); ylabel('VI');
set(gca,'YTick',[1 j_source]);set(gca,'YTickLabel',{'VT','VR'});
subplot(5,1,3);
hold on;
l=stairs(tbin_ra(tij),VEavgbin_ra(tij),'r-'); set(l,'LineWidth',2);
l=stairs(tbin_ra(tij),VEavgbin_ra(tij)+VEstdbin_ra(tij),'r:'); set(l,'LineWidth',1);
l=stairs(tbin_ra(tij),VEavgbin_ra(tij)-VEstdbin_ra(tij),'r:'); set(l,'LineWidth',1);
l=stairs(tbin_ra(tij),VIavgbin_ra(tij),'b-'); set(l,'LineWidth',2);
l=stairs(tbin_ra(tij),VIavgbin_ra(tij)+VIstdbin_ra(tij),'b:'); set(l,'LineWidth',1);
l=stairs(tbin_ra(tij),VIavgbin_ra(tij)-VIstdbin_ra(tij),'b:'); set(l,'LineWidth',1);
xlim([min(tbin_ra(tij)) max(tbin_ra(tij))]);
ylim([VR VT]); ylabel('Vavg');
set(gca,'YTick',[0 1]);set(gca,'YTickLabel',{'VR','VT'});
hold off;
subplot(5,1,4); stairs(tbin_ra(tij),P_MFEbin_ra(tij),'g-'); xlim([min(tbin_ra(tij)) max(tbin_ra(tij))]); ylabel('P/dt');
subplot(5,1,5); hold on; stairs(tbin_ra(tij),xEbin_ra(tij),'r-'); stairs(tbin_ra(tij),xIbin_ra(tij),'b-'); xlim([min(tbin_ra(tij)) max(tbin_ra(tij))]); ylabel('#spk'); hold off; 
% print('-depsc',sprintf('%s_FIG_A.eps',filename_base));
% print('-djpeg',sprintf('%s_FIG_A.jpg',filename_base));
end;%if plot_flag & dtbin_record_flag;

plot_flag=1;
if plot_flag & dtbin_record_flag;
figure;
subplot(2,2,1); 
hold on;
rEtmp = mean(rEbin_ra,2); l=stairs(Vbins,rEtmp,'r-'); set(l,'LineWidth',2);
rItmp = mean(rIbin_ra,2); l=stairs(Vbins,rItmp,'b-'); set(l,'LineWidth',2);
% xlim([Vbins(j_source) Vbins(end)]); ylim([0 0.005]);
xlim([Vbins(j_source) Vbins(end)]); ylim([0 1.1*max(max(rEtmp),max(rItmp))]);
hold off;
subplot(2,2,2);
hold on;
hEtmp = hist(mEbin_ra,[1:1.5*NE]); l=plot(log2([1:1.5*NE]),log2(1+hEtmp),'r-'); set(l,'LineWidth',2);
hItmp = hist(mIbin_ra,[1:1.5*NI]); l=plot(log2([1:1.5*NI]),log2(1+hItmp),'b-'); set(l,'LineWidth',2);
%hEtmp = hist(mEbin_ra,[1:1.5*NE]); l=loglog(([1:1.5*NE]),(1+hEtmp),'r-'); set(l,'LineWidth',2);
%hItmp = hist(mIbin_ra,[1:1.5*NI]); l=loglog(([1:1.5*NI]),(1+hItmp),'b-'); set(l,'LineWidth',2);
hold off;
subplot(2,2,[3,4]);
h = spectrum.mtm; Fs = 1000*1/tbinsize; hpsd = psd(h,(VEavgbin_ra*NE + VIavgbin_ra*NI)/(NE+NI),'Fs',Fs); plot(hpsd);
% print('-depsc',sprintf('%s_FIG_B.eps',filename_base));
% print('-djpeg',sprintf('%s_FIG_B.jpg',filename_base));
end;%if plot_flag & dtbin_record_flag;

% save(sprintf('%s_data.mat',filename_base));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% test to see if mEbin_ra is calculated correctly ;
plot_flag=0;
if plot_flag & dtbin_record_flag;
figure;
subplot(2,1,1);
hold on;
plot(tbin_ra,mEbin_ra,'r-',tbin_ra,mIbin_ra,'b-');
xlim([min(t_ra) max(t_ra)]);
hold off;
subplot(2,1,2); 
hold on; 
dtperbinB = 1.0/dt;
t_ra = 0:dt:iteration_max*dt;
tbinB_ra = t_ra(1:dtperbinB*floor(length(t_ra)/dtperbinB));
tbinB_ra = reshape(tbinB_ra,dtperbinB,length(tbinB_ra)/dtperbinB);
tbinB_ra = mean(tbinB_ra,1);
mEbinB_ra = mE_ra(1:dtperbinB*floor(length(mE_ra)/dtperbinB));
mEbinB_ra = reshape(mEbinB_ra,dtperbinB,length(mEbinB_ra)/dtperbinB);
mEbinB_ra = mean(mEbinB_ra,1);
mIbinB_ra = mI_ra(1:dtperbinB*floor(length(mI_ra)/dtperbinB));
mIbinB_ra = reshape(mIbinB_ra,dtperbinB,length(mIbinB_ra)/dtperbinB);
mIbinB_ra = mean(mIbinB_ra,1);
mEbinB_ra = NE*mEbinB_ra;
mIbinB_ra = NI*mIbinB_ra;
for ij=1:length(Lt_ra);
mEbinB_ra(1+floor(Lt_ra(ij))) = mEbinB_ra(1+floor(Lt_ra(ij))) + LE_ra(ij);
mIbinB_ra(1+floor(Lt_ra(ij))) = mIbinB_ra(1+floor(Lt_ra(ij))) + LI_ra(ij);
end;%for ij=1:length(Lt_ra);
plot(tbinB_ra,mEbinB_ra,'r-',tbinB_ra,mIbinB_ra,'b-');
xlim([min(t_ra) max(t_ra)]);
hold off;
end;%if plot_flag & dtbin_record_flag;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function L_flow = get_L_flow(dt,Vedges);
%get L_flow -- the streaming term ;
TAU_V=20;VT=1;VR=0;
nbins = length(Vedges)-1; nbinp = nbins+1;
dV = (VT-(VR-VT))/nbins;
edt = exp(-dt/TAU_V); egt = exp(dt/TAU_V); 
row_ra=[];col_ra=[];val_ra=[];
for (j=1:nbins);
% bin edge j is at VR-VT + dV*(j-1); bin center j is at VR-VT + dV*(j-0.5) ;
% the edge index of V is j = (V-(VR-VT))/dV + 1 ;
% the edge center of V is j = (V-(VR-VT))/dV + 0.5 ;
% bin j with center Vbin(j) has edges [Vedges(j),Vedges(j+1)] ;
% over a timestep of length dt the mass in [Vpre Vpos] flows to lie in bin j, where ;
Vpre = Vedges(j)*egt;
Vpos = Vedges(j+1)*egt;
% The interval [Vpre Vpos] correponds to edges ;
jpre = (Vpre - (VR-VT))/dV + 1;
jpos = (Vpos - (VR-VT))/dV + 1;
% The interval [Vpre Vpos] sits within edge indices ;
jmin = floor(jpre);
jmax = ceil(jpos);
% and bin indices ;
bmin = jmin;
bmax = jmax-1;
% Because egt>1, jpos-jpre > dV, and so jmax-jmin>1 and bmax>bmin. ;
bvec = transpose(bmin:bmax);
% The weights associated with jmin and jmax are ;
wmin = (jmin+1)-jpre;
wmax = jpos-(jmax-1);
wvec = [wmin;ones(length(bvec)-2,1);wmax];
rvec = j*ones(length(bvec),1);
vij = find(bvec>0 & bvec<=nbins);
row_ra = [row_ra;rvec(vij)];
col_ra = [col_ra;bvec(vij)];
val_ra = [val_ra;wvec(vij)];
%if j==(nbins+1)/2; disp(sprintf('dV %0.6f Vpre %0.6f Vpos %0.6f jpre %0.6f jpos %0.6f jmin %d jmax %d bmin %d bmax %d ',dV,Vpre,Vpos,jpre,jpos,jmin,jmax,bmin,bmax)); end;
end;%for (j=1:nbins);
L_flow = sparse(row_ra,col_ra,val_ra,nbins,nbins);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function L_kick = get_L_kick(kick_val,Vedges,VD);
% get L_kick -- the kick term ;
TAU_V=20;VT=1;VR=0;
nbins = length(Vedges)-1; nbinp = nbins+1;
dV = (VT-(VR-VT))/nbins; egd = exp(kick_val);
row_ra=[];col_ra=[];val_ra=[];
for (j=1:nbins);
% bin edge j is at VR-VT + dV*(j-1); bin center j is at VR-VT + dV*(j-0.5) ;
% the edge index of V is j = (V-(VR-VT))/dV + 1 ;
% the edge center of V is j = (V-(VR-VT))/dV + 0.5 ;
% bin j with center Vbin(j) has edges [Vedges(j),Vedges(j+1)] ;
% over a timestep of length dt the mass in [Vpre Vpos] is kicked to lie in bin j, where ;
Vpre = VD + (Vedges(j)-VD)*egd;
Vpos = VD + (Vedges(j+1)-VD)*egd;
% The interval [Vpre Vpos] correponds to edges ;
jpre = (Vpre - (VR-VT))/dV + 1;
jpos = (Vpos - (VR-VT))/dV + 1;
% The interval [Vpre Vpos] sits within edge indices ;
jmin = floor(jpre);
jmax = ceil(jpos);
% and bin indices ;
bmin = jmin;
bmax = jmax-1;
% because kicks do not compress, it is possible that jmax-jmin==1 and bmax==bmin. ;
bvec = transpose(bmin:bmax);
if length(bvec)>1;
% The weights associated with jmin and jmax are ;
wmin = (jmin+1)-jpre;
wmax = jpos-(jmax-1);
wvec = [wmin;ones(length(bvec)-2,1);wmax];
rvec = j*ones(length(bvec),1);
elseif length(bvec)==1;
% The weights associated with jmin and jmax are ;
wvec = [1];
rvec = j*ones(length(bvec),1);
end;%if length(bvec)>1;
vij = find(bvec>0 & bvec<=nbins);
row_ra = [row_ra;rvec(vij)];
col_ra = [col_ra;bvec(vij)];
val_ra = [val_ra;wvec(vij)];
end;%for (j=1:nbins);
L_kick = sparse(row_ra,col_ra,val_ra,nbins,nbins);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [X_bar,Y_bar,Vmin,X_hat,Y_hat] = V_transform(X,Y,D);
TAU_V=20;VT=1;VR=0;
DII = D(1,1); DIE = D(1,2); DIY = D(1,3);
DEI = D(2,1); DEE = D(2,2); DEY = D(2,3);
X=sort(X(:));
Y=sort(Y(:));
NE = length(X); NI = length(Y);
X_hat = X; X_bar = X_hat;
Y_hat = VT - (VT - Y)*DEE/DIE; Y_bar = Y_hat;
if (DEI > DII*DEE/DIE);
for ni=NI:-1:1; 
ij = find(X_bar < Y_bar(ni));
X_bar(ij) = X_bar(ij) - max(0,DEI - DII*DEE/DIE);
end;%for ni=NI:-1:1; 
elseif (DEI < DII*DEE/DIE);
for ni=1:NI; Y_bar(ni) = Y_hat(ni) - max(0,DII*DEE/DIE - DEI)*length(find(Y_hat>Y_hat(ni))); end;%for ni=1:NI;
end;%if;
X_bar = reshape(X_bar,1,NE);
Y_bar = reshape(Y_bar,1,NI);
Vmin = VR + min(0,-NI*abs(DII*DEE/DIE - DEI));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [E_fired,I_fired,VE,VI] = getMFE_ifdyn(verbose,VE,VI,D);
% assumes all the voltages are distinct;
TAU_V=20;VT=1;VR=0;
NE = length(VE); NI = length(VI);
if (verbose); [VE_bar,VI_bar] = V_transform(VE,VI,D); end;
DII = D(1,1); DIE = D(1,2); DIY = D(1,3);
DEI = D(2,1); DEE = D(2,2); DEY = D(2,3);
if (verbose); disp(sprintf(' DII %0.2f DIE %0.2f DEI %0.2f DEE %0.2f',DII,DIE,DEI,DEE)); end;
[VE,VEj] = sort(VE); [VI,VIj] = sort(VI); [VEjs,VEr] = sort(VEj); [VIjs,VIr] = sort(VIj); 
VE_orig = VE; VI_orig = VI;
I_fired = find(VI>=VT);
LI = length(I_fired);
I_remaining = find(VI<VT);
accumulated_DII=0; accumulated_DEI=0;
if LI>0;
if (verbose); disp(sprintf('LI %d, shifting VE',LI)); end;
VE = VE - DEI*LI; accumulated_DEI = accumulated_DEI + DEI*LI;
if (verbose); disp(sprintf('LI %d, shifting VI',LI)); end;
VI(I_remaining) = VI(I_remaining) - DII*LI; accumulated_DII = accumulated_DII + DII*LI;
end;%if LI>0;
E_fired = find(VE>=VT);
LE = length(E_fired);
if (verbose); disp(sprintf('LE %d',LE)); end;
E_remaining = find(VE<VT);
total_V_to_add_to_E = DEE*LE; 
total_V_to_add_to_I = DIE*LE;
if (verbose); disp(sprintf('')); end;
while (total_V_to_add_to_E>0 | total_V_to_add_to_I>0);
if (verbose); disp(sprintf('total_V_to_add_to_I %0.2f, I_remaining %d total_V_to_add_to_E %0.2f E_remaining %d',total_V_to_add_to_I,length(I_remaining),total_V_to_add_to_E,length(E_remaining))); end;
% possible_E_spikes = find(VE(E_remaining)>=VT-total_V_to_add_to_E);
% [max_E,ind_E] = max(VE(E_remaining));
% possible_I_spikes = find(VI(I_remaining)>=VT-total_V_to_add_to_I);
% [max_I,ind_I] = max(VI(I_remaining));
possible_E_spikes = find(VE(E_remaining)>=VT-total_V_to_add_to_E);
[max_E,ind_E] = max(VE(E_remaining)); ind_E = E_remaining(ind_E);
possible_I_spikes = find(VI(I_remaining)>=VT-total_V_to_add_to_I);
[max_I,ind_I] = max(VI(I_remaining)); ind_I = I_remaining(ind_I);
if (verbose); disp(sprintf('possible_E_spikes %d possible_I_spikes %d',length(possible_E_spikes),length(possible_I_spikes))); end;
if (isempty(possible_E_spikes) & isempty(possible_I_spikes)); 
  if (verbose); disp(sprintf('none can fire')); end;
  V_to_add_to_E = total_V_to_add_to_E;
  V_to_add_to_I = total_V_to_add_to_I;
  if (verbose); disp(sprintf(' VtoI %0.2f VtoE %0.2f',V_to_add_to_I,V_to_add_to_E)); end;
  VE(E_remaining) = VE(E_remaining) + V_to_add_to_E; 
  VI(I_remaining) = VI(I_remaining) + V_to_add_to_I;
  total_V_to_add_to_E = 0;
  total_V_to_add_to_I = 0;
elseif (~isempty(possible_E_spikes) & isempty(possible_I_spikes)); 
  if (verbose); disp(sprintf('only E can fire')); end;
  V_to_add_to_E = VT - max_E; 
  V_to_add_to_I = min(total_V_to_add_to_I,VT - max_E);
  if (verbose); disp(sprintf(' VtoI %0.2f VtoE %0.2f',V_to_add_to_I,V_to_add_to_E)); end;
  E_fired = [E_fired(:);ind_E]; E_remaining = setdiff(E_remaining,ind_E); LE = LE+1; if (verbose>1);hold on;; plot(VE_bar(ind_E),1-(LE+LI)/(NE+NI),'ro'); hold off; end;
  VE(E_remaining) = VE(E_remaining) + V_to_add_to_E; 
  VI(I_remaining) = VI(I_remaining) + V_to_add_to_I;
  total_V_to_add_to_E = total_V_to_add_to_E - V_to_add_to_E + DEE; 
  total_V_to_add_to_I = total_V_to_add_to_I - V_to_add_to_I + DIE;
elseif (isempty(possible_E_spikes) & ~isempty(possible_I_spikes)); 
  if (verbose); disp(sprintf('only I can fire')); end;
  V_to_add_to_I = VT - max_I; 
  V_to_add_to_E = min(total_V_to_add_to_E,VT - max_I);
  if (verbose); disp(sprintf(' VtoI %0.2f VtoE %0.2f',V_to_add_to_I,V_to_add_to_E)); end;
  VE(E_remaining) = VE(E_remaining) - DEI + V_to_add_to_E; accumulated_DEI = accumulated_DEI + DEI;
  I_fired = [I_fired(:);ind_I]; I_remaining = setdiff(I_remaining,ind_I); LI=LI+1; if (verbose>1);hold on;; plot(VI_bar(ind_I),1-(LE+LI)/(NE+NI),'bo'); hold off; end;
  VI(I_remaining) = VI(I_remaining) - DII + V_to_add_to_I; accumulated_DII = accumulated_DII + DII;
  total_V_to_add_to_E = total_V_to_add_to_E - V_to_add_to_E;
  total_V_to_add_to_I = total_V_to_add_to_I - V_to_add_to_I;
elseif (~isempty(possible_E_spikes) & ~isempty(possible_I_spikes)); 
% disp('We assume that E and I increase in voltage at a fixed rate');
% disp('this is tantamount to the impulse response of gE being a step function, with height proportional to DQE and constant width (e.g., 1)');
if ((VT-VI_orig(ind_I) + accumulated_DII)/DIE <= (VT-VE_orig(ind_E) + accumulated_DEI)/DEE);
  if (verbose); disp(sprintf('both E and I can fire, I closer')); end;
  V_to_add_to_I = VT - max_I; 
  V_to_add_to_E = min(total_V_to_add_to_E,VT - max_I);
  if (verbose); disp(sprintf(' VtoI %0.2f VtoE %0.2f',V_to_add_to_I,V_to_add_to_E)); end;
  VE(E_remaining) = VE(E_remaining) - DEI + V_to_add_to_E; accumulated_DEI = accumulated_DEI + DEI;
  I_fired = [I_fired(:);ind_I]; I_remaining = setdiff(I_remaining,ind_I); LI=LI+1; if (verbose>1);hold on;; plot(VI_bar(ind_I),1-(LE+LI)/(NE+NI),'bo'); hold off; end;
  VI(I_remaining) = VI(I_remaining) - DII + V_to_add_to_I; accumulated_DII = accumulated_DII + DII;
  total_V_to_add_to_E = total_V_to_add_to_E - V_to_add_to_E;
  total_V_to_add_to_I = total_V_to_add_to_I - V_to_add_to_I;
elseif ((VT-VI_orig(ind_I) + accumulated_DII)/DIE >  (VT-VE_orig(ind_E) + accumulated_DEI)/DEE);
  if (verbose); disp(sprintf('both E and I can fire, E closer')); end;
  V_to_add_to_E = VT - max_E; 
  V_to_add_to_I = min(total_V_to_add_to_I,VT - max_E);
  if (verbose); disp(sprintf(' VtoI %0.2f VtoE %0.2f',V_to_add_to_I,V_to_add_to_E)); end;
  E_fired = [E_fired(:);ind_E]; E_remaining = setdiff(E_remaining,ind_E); LE = LE+1; if (verbose>1);hold on;; plot(VE_bar(ind_E),1-(LE+LI)/(NE+NI),'ro'); hold off; end;
  VE(E_remaining) = VE(E_remaining) + V_to_add_to_E; 
  VI(I_remaining) = VI(I_remaining) + V_to_add_to_I;
  total_V_to_add_to_E = total_V_to_add_to_E - V_to_add_to_E + DEE; 
  total_V_to_add_to_I = total_V_to_add_to_I - V_to_add_to_I + DIE;
end;%if max_E<>max_I;
end;%if any possible spikes;
end;%while (total_V_to_add>0);
VE = reshape(VE,1,NE);
VI = reshape(VI,1,NI);
E_fired = reshape(E_fired,1,length(E_fired));
I_fired = reshape(I_fired,1,length(I_fired));
if (verbose); disp(sprintf(' LE %d, LI %d',LE,LI)); end;
E_fired = VEj(E_fired);
I_fired = VIj(I_fired);
VE = VE(VEr);
VI = VI(VIr);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function plotcdf(V,C);
TAU_V=20;VT=1;VR=0;
hold on;
N = length(V);
V = sort([VR;V(:);VT]); V = V(:);
Y = linspace(0,1,N+1); Y = Y(:);
l = line([transpose(V(1:end-1));transpose(V(2:end))] , [transpose(Y(1:end)) ; transpose(Y(1:end))]); set(l,'Color',C);
l = line([transpose(V(2:end-1));transpose(V(2:end-1))] , [transpose(Y(1:end-1)) ; transpose(Y(2:end))]); set(l,'Color',C);
if N<=24;
l = plot(V(2:end-1),linspace(1/N,1,N),'o'); set(l,'Color',C);
l = plot(V(2:end-1),linspace(0/N,1-1/N,N),'o'); set(l,'Color',C);
end;%if N<=24;
hold off;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function p = staircase2(X,Y,D,Vlim,C);
% plots the cdf of X,Y,G as a staircase plot;
% D is organized as [DII DIE DEI DEE];
TAU_V=20;VT=1;VR=0;
DII = D(1,1); DIE = D(1,2); DIY = D(1,3);
DEI = D(2,1); DEE = D(2,2); DEY = D(2,3);
X = min(max(sort(X(:)),Vlim(1)),Vlim(2));
nx = length(X(:)); X = reshape(X,1,nx);
X_orig=X;
Y = min(max(sort(Y(:)),Vlim(1)),Vlim(2));
ny = length(Y); Y = reshape(Y,1,ny);
[X_bar,Y_bar,DVmin] = V_transform(X,Y,D);
Zx = [Vlim(1) transpose(reshape([X_bar;X_bar],2*nx,1)) Vlim(2) Vlim(2)];
Zy = [0 0 transpose(reshape([1:nx;1:nx]/nx,2*nx,1)) 0];
hold on; p = patch(Zx,Zy,C); set(p,'FaceColor','none','LineWidth',2,'LineStyle',':'); hold off;
Zx = [Vlim(1) transpose(reshape([Y_bar;Y_bar],2*ny,1)) Vlim(2) Vlim(2)];
Zy = [0 0 transpose(reshape([1:ny;1:ny]/ny,2*ny,1)) 0];
hold on; p = patch(Zx,Zy,C); set(p,'FaceColor','none','LineWidth',2,'LineStyle','--'); hold off;
Zv = [X_bar,Y_bar]; [Zv,Iz] = sort(Zv,'ascend');
Zj = [ones(1,nx)*-1/nx , ones(1,ny)*1/nx*min(DII*DEE/DIE,DEI)/DEE]; 
Zj = Zj(Iz);
Zs = cumsum(Zj(end:-1:1)); Zs = 1 + [Zs(end:-1:1)];
nz = length(Zs);
Zv = reshape(Zv(:),1,nz);
Zs = reshape(Zs(:),1,nz);
Zj = reshape(Zj(:),1,nz);
Zx = transpose(reshape([Zv;Zv],2*nz,1));
Zx = [Vlim(1) Vlim(1) Zx Vlim(2) Vlim(2)];
Zy = transpose(reshape([Zs;Zs],2*nz,1));
Zy = [0 Zy 1 1 0];
hold on; p = patch(Zx,Zy,C); set(p,'FaceColor','none','LineWidth',3); hold off;
axis([Vlim(1) Vlim(2) 0 max(max(Zs),1)]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function p = staircase(Z,Vlim,C);
% plots the cdf of Z as a staircase plot;
TAU_V=20;VT=1;VR=0;
Z = min(max(sort(Z),Vlim(1)),Vlim(2));
nz = length(Z);
Z = reshape(Z,1,nz);
Zx = transpose(reshape([Z;Z],2*nz,1));
Zx = [Vlim(1) Zx Vlim(2) Vlim(2)];
Zy = transpose(reshape([1:nz;1:nz]/nz,2*nz,1));
Zy = [0 0 Zy 0];
p = patch(Zx,Zy,C);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [fig1] = figpos()
set(0,'Units','pixels') ;
scnsize = get(0,'ScreenSize');
fig1 = figure;
position = get(fig1,'Position');
outerpos = get(fig1,'OuterPosition');
borders = outerpos - position;
edge = -borders(1)/2;
pos1 = [edge - 1800,  scnsize(4) * (2/3) - 500,  scnsize(3) - edge + 300,  scnsize(4) + 300];
set(fig1,'OuterPosition',pos1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function plotvarrho(dt_ra,V_ra,nbins);
% assumes t_ra is Nx1 and V_ra is NxM ;
TAU_V=20;VT=1;VR=0;
t_ra = cumsum(dt_ra);
[N,M] =  size(V_ra);
Vedges = [VR-(VT-VR)/10, linspace(VR,VT,nbins)];
Vh = histc(V_ra,Vedges,2);
for tij=1:N;
p=patch(repmat(t_ra(tij) - dt_ra(tij) + dt_ra(tij)*[0;1;1;0],1,nbins+1),[Vedges;Vedges;[Vedges(2:end) VT+0.1];[Vedges(2:end) VT+0.1]],Vh(tij,:)/max(Vh(tij,:)));
set(p,'LineStyle','none');
end;%for tij=1:N;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function output = getsamples(Vedges,rho,Nsamples)
rho = [0;rho(:)]/sum(rho);
L = length(rho);
F = cumsum(rho);
[Fv,Fi,Fj] = unique(F,'first');
output = interp1(F(Fi),Vedges(Fi),rand(Nsamples,1));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [mra,sra,ora] = histstats(hra,Vbins);
% assumes each column of hra is a histogram with bin centers Vbins;
[rows,cols] = size(hra);
mra = zeros(1,cols);
sra = zeros(1,cols);
ora = zeros(1,cols);
for nc=1:cols;
hra(:,nc) = hra(:,nc)/sum(hra(:,nc));
[tmp,ora(1,nc)] = max(hra(:,nc)); 
end;%for nc=1:cols;
mra = (1:rows)*hra; 
sra = ((1:rows).^2)*hra; 
sra = sqrt(sra - mra.^2);
mra = interp1(1:rows,Vbins,mra);
sra = sra / rows * (Vbins(end)-Vbins(1));
ora = Vbins(ora);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function output = psample(ldt);
% draws an event count from a Poisson process with rate lambda over time dt;
if ldt>5; output = max(0,round(ldt + sqrt(ldt)*randn())); 
else; 
kra = 0:14;
pra = [-1 , cumsum((ldt.^kra).*exp(-ldt)./factorial(kra)) , 2];
output = max(find(~(min(rand(),pra(end-1))<=pra)))-1;
end;% if ldt>7;
